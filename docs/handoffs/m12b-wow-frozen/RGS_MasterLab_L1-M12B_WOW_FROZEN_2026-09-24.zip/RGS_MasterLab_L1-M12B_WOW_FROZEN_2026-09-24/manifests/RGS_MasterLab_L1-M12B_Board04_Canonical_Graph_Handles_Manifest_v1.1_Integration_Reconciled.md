# RGS MasterLab — L1-M12B
# BOARD 04 — CANONICAL RESPONSE GRAPH & BAND HANDLES TOKEN MANIFEST v1.1 — INTEGRATION-RECONCILED

**Deliverable:** text-only technical companion to **Board 04 — Response Graph + Band Handles — Revised Candidate**, visually approved.  
**State:** **independent technical integration review PASS — SCOPED M12B BOARD 04 ACCEPTED**. Derived non-destructively from GUI Board 04 v1.0. This document does not freeze the entire L1-M12B Visual WOW Package, alter DSP or promote proposed tokens to the global design system.  
**Reference platform:** Qt 6 / Qt Quick, Windows 10; all dimensions below are **logical px (lp)**.  
**Color convention:** design tokens use **`#RRGGBBAA`**; Qt Quick/QML strings use **`#AARRGGBB`**. Never paste eight-digit design colors directly into QML.

## 1. Authorities, precedence and scope

1. **Board 01 — Composition + Dimensions (macro-geometry FROZEN):** EQ tool window 1040 × 660 lp default / 900 × 580 lp minimum; 24-lp effective content inset on every side; 12-lp inter-section gaps; Header 48 lp; Band Strip 40 lp; **Response Graph 324 lp default / 244 lp minimum**; two-tier Inspector 128 lp; Status/Validation 24 lp. The graph receives **992 lp** of width at default and **852 lp** at minimum. This document does not change these values.
2. **Board 02 — Canonical Material Token Manifest v1.1 QML-Safe:** authority for shared color references, all four EQ structural materials and state overlays. In particular the graph well remains `eq.graph.bg #081824FF`, vertical top `#0D2A3AFF` to bottom `#06141DFF`, border `#1A3E55FF` / 1 lp, radius 6 lp, highlight `#1AA0C61A`, inset shadow `#00000026`. This document adds **no** replacement material.
3. **Board 03 — Canonical Typography & Numeric Field Token Manifest v1.0:** authority for Segoe UI Windows typography and its fallback policy; it is **not** changed here. Graph-specific axis/handle text roles below are new local uses of that family, not global font revisions.
4. **Board 04 — Revised Candidate:** approved *visual direction* for the single selected-band curve, grid hierarchy, localized luminous treatment and six band handles. Where a printed Board 04 axis-text RGB conflicts with canonical Board 02 shared text tokens, the **textual Board 02/03 authority prevails**. An illustrative plotted coordinate is never a parameter or DSP authority.
5. **Runtime data authority:** response samples come **only** from the existing C++ `selectedBandResponsePoints`. Parameter values and individual handle positions come from the real M12B band/model state. No EQ transfer-function calculation is added to QML.

**Scope:** graph plot geometry, coordinate projection, ruler/grid, selected-band response presentation, handles, local color/interaction treatments and QML rendering feasibility. **Excluded:** Inspector layout/controls, A/B, DSP changes, combined response, analyzer/spectrum, new editing commands, new runtime states or QML implementation handoff.

## 2. Geometry and shared coordinate rectangle

### 2.1 Graph content and plot rectangle

The **graph content area** is the complete Board 01 Response Graph section: the inherited `eq.graph.*` well, occupying the section's assigned width **W** and height **H**. Its 1-lp structural border and 6-lp corner radius belong to Board 02; they are **not** additional deductions from W/H.

To make the Board 04 internal padding and the axis-label gutters unambiguous, use this **EQ-LOCAL — PROPOSED** graph-layout specification:

| Element / token | Exact lp | Role |
|---|---:|---|
| `eq.plot.outerLeft` | 12 | Inset to the beginning of the **gain-label gutter** |
| `eq.plot.gainGutter` | 40 | Reserved for signed gain tick values; optional explanatory vertical axis title belongs to the *documentation board*, not a new runtime label |
| `eq.plot.outerRight` | 12 | Plot-to-well right inset |
| `eq.plot.outerTop` | 10 | Plot-to-well top inset |
| `eq.plot.frequencyGutter` | 22 | Plot-to-well bottom inset, reserved for frequency tick labels; no second runtime title row |
| `eq.plot.border` | inherited **1** | The graph well border `eq.graph.border`; do not draw a second graph-frame border |

Let `(0,0)` be the graph section's top-left and let W/H be **its own assigned dimensions**, not the whole window's:

- `plotLeft = 12 + 40 = 52 lp`.
- `plotTop = 10 lp`.
- `plotWidth = W − 52 − 12 = W − 64 lp`.
- `plotHeight = H − 10 − 22 = H − 32 lp`.
- `plotRight = plotLeft + plotWidth = W − 12 lp`.
- `plotBottom = plotTop + plotHeight = H − 22 lp`.

| Board 01 size | Graph W × H | Plot x, y | Plot width × height | Graph remains independently sized |
|---|---|---|---|---|
| Default 1040 × 660 window | **992 × 324 lp** | **52, 10 lp** | **928 × 292 lp** | Yes |
| Minimum 900 × 580 window | **852 × 244 lp** | **52, 10 lp** | **788 × 212 lp** | Yes |

These plots are derived **within** the 324/244-lp graph: they do not reserve additional window or Inspector space. Labels occupy the designated gutters outside the plot, not the waveform/response drawing surface.

**Shared geometry rule:** response points, grid lines, 0-dB baseline, frequency landmarks and handle centers are projected into **the same `plotRect`**. Never map a handle against the full well while mapping the curve against the inset plot. All response/grid/fill painting is clipped to `plotRect`; numeric axis labels are painted in their dedicated gutters. The handle-interaction overlay is painted **after** and **outside** the `plotRect` clip, so the visible 24-lp selected disc, 28-lp hover ring and up-to-8-lp selection halo are not cut off at extreme parameter values. **QML implementation constraint:** the inherited current `ParametricEqGraph.qml` has `root.clip: true`; in the WOW implementation move the plot clipping to an inner plot-only child and place the handle/interaction overlay as an unclipped sibling above it (the graph host must not clip the overlay). At the extreme +18 dB / fMax, the 24-lp selected disc plus 8-lp halo can reach **10 lp above** the 10-lp plotTop and **8 lp right** of the well at the 12-lp right inset. That overflow may use the already frozen **12-lp preceding section gap** and **24-lp right content inset**; no new Board 01 gap or margin is authorized. Place overlays above the graph-well stroke without occluding interactive controls in adjacent sections. Real staged Windows screenshots at 900×580 must verify that the halo and pointer target remain visible and functional at all extrema. If the host hierarchy cannot support this safely, treat it as a visual implementation reconciliation gate, never silently clip or change the data coordinate mapping.

### 2.2 Tick and axis-label positioning

- **Y labels:** Segoe UI 12 lp / weight 400 / 16-lp line box, color `rgs.neutral.300` at full token opacity. Right-aligned inside `x = [12, 48]`; leave **4 lp** between label end (`x = 48`) and plot start (`x = 52`). Position the text line vertically at its gain-projected Y, with 16-lp line box centered on the grid line. Values **+18, +12, +6, 0, −6, −12, −18**; units `dB` are contextual, not appended to every tick.
- **X labels:** the same font/color/line box, in the 22-lp bottom gutter; upper edge **`plotBottom + 3 lp`**, with 3 lp nominal space below the 16-lp label. Anchor interior labels horizontally on the associated frequency x-coordinate; **left-align** the first and **right-align** the terminal endpoint label. Collision policy in §4.
- The phrases “Output Level (dB)” and “Frequency (Hz)” appearing as **technical board annotations** do not require additional user-facing runtime rows. Do not spend the 22-lp X gutter on a second caption line.
- Axis labels do not affect input mapping and do not move the plot when their text changes (e.g., when `Fs` changes).

### 2.3 Clipping and minimum-size acceptance

At the **900 × 580** tool-window minimum, the inherited graph well is **852 × 244 lp** and the plot remains **788 × 212 lp**. Curve/fill/grid paths are clipped to the plot. Axis text stays inside its gutters. Handles retain approved visual diameters and an independent interaction layer; do not shrink all handles just to fit the plot. No scroll, overlapping axis label, hidden parameter, side inspector or alternate graph topology is introduced by this specification.

## 3. Frequency/gain coordinate system — projection only

Let `Fs` be the authoritative Source sampling rate and let `fMax = min(20000, 0.45 × Fs)` **in Hz**. The valid horizontal domain is `[20, fMax]` provided the runtime supplies a valid source and a domain greater than 20 Hz; no substitute sampling rate is invented by the graph.

For any existing C++ response point `(f, g)` and any existing band-position point supplied by the M12B model:

- `u = ln(f / 20) / ln(fMax / 20)`.
- `x = plotLeft + u × plotWidth`.
- `v = (18 − g) / 36`.
- `y = plotTop + v × plotHeight`.

The inverse *display-coordinate* projection is `f = 20 × exp(((x − plotLeft) / plotWidth) × ln(fMax / 20))`; gain projection inverse is `g = 18 − ((y − plotTop) / plotHeight) × 36`. These are **geometric mappings**, not new EQ/DSP calculations, snapping or commit rules. Gain is shown on a symmetric **−18 to +18 dB** axis; `yZero = plotTop + plotHeight / 2`.

- `Fs = 44100 Hz` ⇒ `0.45 × Fs = 19845 Hz` ⇒ **`fMax = 19845 Hz`**.
- `Fs = 48000 Hz` ⇒ `0.45 × Fs = 21600 Hz` ⇒ **`fMax = 20000 Hz`**.
- Never display or plot a **20-kHz endpoint** when the effective `fMax` is lower.
- The projection does **not** license an independent QML transfer-function calculation or recomputation of selected-band samples. Use C++-supplied response data as given. The numeric range governs the plot and viewport; actual draft/commit validation remains in existing M12B logic.

**Example precision:** Board 04 depicts selected **Band 4 / Bell / 2000 Hz / +6 dB / Q 0.707**. Its printed apex is visually slightly above the +6-dB guide. That is an illustration error: **do not sample the image for either response points or handle coordinates**. Project the **actual** C++ response points and actual selected-band parameters. If the C++ sample at the Bell center is +6 dB, place it **on** the +6-dB grid line, not above it.

## 4. Grid hierarchy, landmarks and axis rendering

The following proposed **MASTERING MODULE FAMILY** grid treatments reproduce Board 04's intended restrained hierarchy. These are **line tokens**, not new graph-well structural materials. All alpha values reside in the color itself; do not multiply them by a second QML `opacity`.

| Token | Design `#RRGGBBAA` | QML `#AARRGGBB` | Thickness | Rendering and visibility | Z |
|---|---|---|---:|---|---:|
| `mastering.graph.grid.major` | `#40546666` | `#66405466` | **1 lp** | Full major frequencies and ±6-dB gain steps; **40% alpha** | 22 |
| `mastering.graph.grid.minor` | `#2A3A492E` | `#2E2A3A49` | **1 lp** | Secondary frequency/gain divisions where distinct from major; **18% alpha** | 21 |
| `mastering.graph.grid.micro` | `#1C28361A` | `#1A1C2836` | **1 lp** | Optional tertiary subdivisions at the visibility threshold below; **10% alpha** | 20 |
| `mastering.graph.zero` | `#6B7C8F99` | `#996B7C8F` | **1 lp** | The **single** 0-dB line; **60% alpha**; never also draw its major-grid duplicate | 45 |

**Major gain landmarks:** −18, −12, −6, **0**, +6, +12, +18 dB. Draw the 0-dB baseline via `mastering.graph.zero`, not via `major`. **Minor gain guides:** ±3, ±9, ±15 dB, 1 lp/18%; micro gain guides are omitted to avoid dense horizontal stripes.

**Major frequency landmarks:** candidates `[20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000]` Hz. Include only candidates `≤ fMax`. If `fMax` is not one of these candidates, draw the **actual endpoint** at `fMax` and label it; do **not** draw the out-of-range 20-kHz candidate. For `Fs = 44100 Hz`, the terminal label is **`19.845k`** (actual value 19845 Hz), replacing `20k`; for `Fs = 48000 Hz`, it is **`20k`**. Use compact labels for thousands (`1k`, `2k`, `5k`, `10k`) and unambiguous endpoint precision rather than pretending 19.845 kHz is 20 kHz.

**Minor frequency guides:** 1-lp/18% lines at the remaining integer subdivisions within each plotted decade after removing already-drawn major positions, clipped to `[20, fMax]`. **Micro frequency guides:** halfway on the **logarithmic coordinate** between adjacent major/minor guide lines, drawn only when `plotWidth ≥ 900 lp` **and** adjacent computed micro guides are at least **7 lp** apart; otherwise omit the entire micro frequency layer. Micro lines never receive numeric labels. The major grid, all seven gain labels and legible terminal frequency label remain visible at the minimum **788-lp** plot width.

**X-label collision policy (deterministic):** the first and endpoint labels have priority; interior major labels retain frequency order and are suppressed only when their Segoe UI 12-lp text bounding rectangles, including a **4-lp** separation, would intersect a higher-priority label. Suppressing a tick **label** does not suppress its grid line. At the default and minimum widths specified by Board 01, the standard major labels should remain present; test rendered glyph metrics rather than hard-coding character counts.

**Grid z-order note:** z-indices and compositing order are now consistent: *background → micro (Z20) → minor (Z21) → major (Z22) → selected-band fill → zero → response strokes → handles* (zero is one line). All grid layers appear **behind** the selected response fill, selected response stroke and band handles. Do not draw extra spectrum, energy-scale, analyzer traces or an additional “mixed” guide.

## 5. Selected-band response curve and fill

**One selected-band curve only.** Data source: existing C++ **`selectedBandResponsePoints`** for the currently selected band. The curve is neither a summation nor a visual interpolation between independent band-handle positions. In mixed routing it still depicts **only the selected band**. Other bands' handles remain visible independently, even where they lie off that curve.

Board 04 proposes an EQ-local curve cyan **`#2ED3FF`**, visually distinct from but close to inherited RAW/interaction cyan `rgs.raw.cyan #00C8FF`. Its purpose is the **local selected-band response trace**, **not** a reassignment of RAW, PREPARED, PROCESSED or GOLD semantics. The existing QML violet `#8B42C0` remains the inherited **PROCESSED** semantic reference and is **not silently overwritten** as a global token. Adoption of this local curve color is subject to this manifest's integration review.

| Token | Class | Design `#RRGGBBAA` | QML `#AARRGGBB` | Use |
|---|---|---|---|---|
| `eq.graph.curve.line` | **EQ-LOCAL — PROPOSED** | `#2ED3FFFF` | `#FF2ED3FF` | **2.0-lp** continuous selected-band stroke |
| `eq.graph.curve.localHalo` | **EQ-LOCAL — PROPOSED** | `#2ED3FF59` | `#592ED3FF` | Secondary **6-lp** soft-looking geometry at **35% alpha** (no blur required) |
| `eq.graph.curve.fillAtContour` | **EQ-LOCAL — PROPOSED** | `#2ED3FF24` | `#242ED3FF` | **14% alpha** beside the selected curve |
| `eq.graph.curve.fillAtZero` | **EQ-LOCAL — PROPOSED** | `#2ED3FF00` | `#002ED3FF` | **0% alpha** at the 0-dB baseline |

**Stroke:** 2.0 lp, continuous anti-aliased line, round optical joins; do not draw smoothed control curves derived from band handles. Connect the C++ selected-band samples in their supplied order; any geometry-only interpolation is limited to stable path rendering and must not invent frequencies, gain peaks or DSP values. All response painting is clipped to `plotRect`.

**Local luminous treatment:** first paint the same curve with a **6-lp, 35%-alpha** wide under-stroke (static vector geometry); then paint the sharp 2-lp full-color line. This reproduces a controlled 6-lp visual spread **without** a shader, filter or frame-by-frame blur. Never expand this into broad whole-panel glow. Only repaint when C++ response points, plot geometry or display state actually change.

**Fill:** paint only the area **between the selected-band response and 0 dB**. For positive segments, start with 14%-alpha curve cyan at the curve and fade to transparent at zero. For negative segments, reverse that vertical interpolation so 14% is still adjacent to the curve and **0% at zero**. If the path crosses 0 dB, split the **rendered area polygon** at its geometric crossing to avoid filling across the baseline; this is display geometry only, not a new transfer function. No plot-to-bottom gradient and no fake frequency spectrum. The fill is behind the sharp curve and behind the zero line; it is clipped to `plotRect`.

**Example:** Band 4 / Bell / 2000 Hz / +6 dB / Q 0.707 is illustrative content, not a new default, combined response, rounding authority or fixed curve geometry.

## 6. Six EQ-local band identity colors

These **EQ-LOCAL — PROPOSED** colors identify band **numbers**, not runtime statuses. An identity color does not mean Error, Warning, GOLD or PROCESSED. They are independent from the shared tokens in Board 02:

| Band | Color token | Design `#RRGGBBAA` | QML `#AARRGGBB` | Role |
|---:|---|---|---|---|
| 1 | `eq.band.1.identity` | `#2ED3FFFF` | `#FF2ED3FF` | Cyan-blue band identity |
| 2 | `eq.band.2.identity` | `#2FD98FFF` | `#FF2FD98F` | Green-teal band identity |
| 3 | `eq.band.3.identity` | `#C8D94AFF` | `#FFC8D94A` | Yellow-green band identity, **not Warning/Gold** |
| 4 | `eq.band.4.identity` | `#FF7A9AFF` | `#FFFF7A9A` | Pink band identity, **not Error Coral** |
| 5 | `eq.band.5.identity` | `#B56CFFFF` | `#FFB56CFF` | Lavender band identity, **not PROCESSED purple** |
| 6 | `eq.band.6.identity` | `#6FC8FFFF` | `#FF6FC8FF` | Pale azure band identity |

Each band receives the same visual anatomy. The selected band gains **size and edge emphasis**, not an exclusive color privilege. When band 4 is selected its pink edge remains identifiable by its **number, 24-lp size, 2-lp opaque outline and selected-state treatment**; an error, by contrast, uses the inherited `rgs.error.coral #F27683FF` and field/validation semantics. Likewise, band 3's yellow-green and band 5's lavender are not aliases of warning, GOLD or PROCESSED.

**Derived state colors (deterministic):** let `RGB` be the first six hex digits of the band's identity color. Normal outline = `#RGBE6` (**90% alpha**), selected outline = `#RGBFF` (**100%**), hover ring = `#RGB66` (**40%**), selection halo = `#RGB73` (**45%**), pressed local glow = `#RGB80` (**50%**). In Qt/QML, use `#E6RGB`, `#FFRGB`, `#66RGB`, `#73RGB` and `#80RGB` respectively. These suffixes are alpha bytes and are **not** extra globally defined semantic colors. All states retain their numeric badges.

## 7. Band-handle anatomy and measurable states

Band count is dynamic from **1 to 6**. Each existing band has **one** independent handle at the actual position supplied by the M12B band state. The selected-band curve need not pass through unselected handles. Draw **only existing** handles; do not draw placeholders for missing bands.

### 7.1 Base anatomy and local tokens

| Property / token | Exact proposed value | Notes |
|---|---|---|
| `eq.handle.unselectedDiameter` | **20 lp** | Normal visual disc of an unselected band |
| `eq.handle.selectedDiameter` | **24 lp** | Selected visual disc |
| `eq.handle.strokeWidth` | **2 lp** | Identity-color ring; normal alpha 90%, selected 100% |
| `eq.handle.defaultFillCenter` | `#0E2233FF` → QML `#FF0E2233` | Radial-gradient center, dark inner disc |
| `eq.handle.defaultFillEdge` | `#0A1A27FF` → QML `#FF0A1A27` | Radial-gradient outer disc |
| `eq.handle.selectedFillBand4Center` | `#2A0F12FF` → QML `#FF2A0F12` | **Board 04 Band-4 selected reference**; tinted dark-red center, not error treatment |
| `eq.handle.selectedFillBand4Edge` | `#3A0F1FFF` → QML `#FF3A0F1F` | **Board 04 Band-4 selected reference**; palette-specific specimen, not a mandated tint for other bands |
| `eq.handle.numberFont` | **Segoe UI 12 lp, weight 600, line-height 16 lp** | Local badge typography consistent with Board 03's Windows family |
| `eq.handle.numberNormal` | `#FFFFFFE6` → QML `#E6FFFFFF` | Numeric badge, 90% alpha |
| `eq.handle.numberSelected` | `#FFFFFFFF` → QML `#FFFFFFFF` | Numeric badge, 100% alpha |
| `eq.handle.hoverRingDiameter` | **28 lp** | Centered on handle's same parameter position |
| `eq.handle.hoverRingWidth` | **1 lp** | Band-identity RGB at 40% alpha |
| `eq.handle.selectionHalo` | **0–8 lp**, band RGB at **45% alpha** | Concentric, localized vector rings; no blur or persistent large bloom |
| `eq.handle.pressedScale` | **1.10** | Scale visual handle about its center, **not** its data coordinates |
| `eq.handle.disabledFill` | `#2A3A4999` → QML `#992A3A49` | 60% alpha (conditional disabled visual treatment only) |
| `eq.handle.disabledStroke` | `#56667699` → QML `#99566676` | 60% alpha |
| `eq.handle.disabledText` | `#A6B2BF99` → QML `#99A6B2BF` | 60% alpha; keep band number legible |
| `eq.handle.visualHitTarget` | **at least 28 × 28 lp** | Transparent mouse hit region over disc; no visible additional control |

For bands other than the illustrated selected band 4, keep the approved **dark-base radial fill** (`defaultFillCenter` → `defaultFillEdge`) and draw the band's own full-opacity selected outline plus its localized identity-color selection halo. **Do not reuse band 4's red/pink dark fill for other identities.** This is an **EQ-local proposed normalization** where Board 04 supplied exact tinted fill values only for the selected band-4 specimen; it does not change the six identity colors or selected-state geometry.

### 7.2 State table

| State | Diameter / outline | Fill / text | Extra treatment | Interaction note |
|---|---|---|---|---|
| **UNSELECTED — NORMAL** | **20 lp**, 2-lp band RGB at 90% | Dark radial fill; Segoe UI 12/600 badge at 90% white | No outer halo required | Independent band position, not forced onto selected curve |
| **SELECTED — NORMAL** | **24 lp**, 2-lp band RGB at 100% | Dark fill (band-4 tinted specimen above); 100% white badge | 0–8-lp local identity-color halo at 45%; always distinguishable by diameter/ring | Selected band's parameters and C++ response are displayed |
| **HOVER — UNSELECTED** | Base **20 lp** unchanged | Default fill/text | **28-lp**, 1-lp ring at 40% band color; local edge accent only | Does not select by merely hovering |
| **HOVER — SELECTED** | Base **24 lp** unchanged | Selected fill/text | Same centered **28-lp** hover ring, distinguishable from 24-lp selected edge; halo spread must **not** expand beyond selected limit | Preserve selected identity |
| **PRESSED / DRAGGING — UNSELECTED** | **22 lp** = 20 × 1.1 | Default fill/text retained | Band-color local glow 0–10 lp / 50%; no disabled appearance | Visual scale only; no snapping or auto-reordering |
| **PRESSED / DRAGGING — SELECTED** | **26.4 lp** = 24 × 1.1 | Selected fill/text retained | Band-color local glow 0–10 lp / 50%; preserve selected hierarchy | Visual scale only; no per-move render preview |
| **DISABLED (conditional)** | Base 20/24-lp disc geometry unchanged; muted stroke | `disabledFill` / `disabledStroke` / `disabledText` | No hover halo, no drag feedback | **Visual treatment only**; this manifest does not define when M12B disables a handle |

**Explicit numerical correction:** the 22-lp pressed example in the approved artwork applies to a **20-lp unselected** disc. A **24-lp selected** disc becomes **26.4 lp** when pressed, not 22 lp. Scale stroke/ring treatment optically about the same center; do not shift parameter coordinates or rewrite DSP state.

**State priority:** a selected band remains selected while hovered or dragged; hover adds a discrete ring, dragging adds a mechanical scale and localized luminance. Disabled graphics, where a real runtime rule establishes disability, suppress interactive emphasis. Neither band identity color nor halo is a semantic error/warning signal.

## 8. Per-band positions, interaction and z-order

### 8.1 Existing M12B interaction contract

- Selecting a band changes **selection**, not the committed DSP parameter values by itself.
- **Bell / Low Shelf / High Shelf:** when dragging the **selected** handle, horizontal motion edits draft **Frequency** and vertical motion edits draft **Gain**, using the shared plot projection.
- **Notch / High Pass / Low Pass:** horizontal motion edits draft **Frequency** only; vertical drag **does not** change Gain. For any filter lacking an applicable Gain value, preserve the real M12B handle-Y presentation from its band/model authority; do **not** invent a Y-based gain edit or place an unrelated handle on the selected response curve.
- Existing draft graphics are updated during motion; **valid commit occurs on release**. No `Render Preview` invocation is needed for each pointer move. Preview scheduling/commit logic remains in the existing C++/application workflow, not this visual manifest.
- No new snapping, band reorder, mode switch, spectrum, whole-EQ response curve or extra handle is introduced.

### 8.2 Deterministic compositing and z-order (back → front)

| Z | Layer | Draw order / clipping |
|---:|---|---|
| 0 | **Inherited** `eq.graph.*` well | Board 02 fill, border, inset edge/shadow; structural geometry unchanged |
| 10 | Graph plot background | The inherited graph well shows through; no fifth structural material |
| 20–22 | Micro, minor and major grid | Clip all grid paths to `plotRect`; paint micro then minor then major |
| 40 | Selected-band fill | Curve-to-zero signed fill only; clip to plot |
| 45 | 0-dB zero line | Single zero line; above translucent fill and below response strokes |
| 50 | Selected-band 6-lp local luminous under-stroke | Clip to plot; no off-plot bloom |
| 60 | Selected-band 2-lp response line | Clip to plot |
| 70 | Other-band visual discs | Positions independently projected, not curve-snapped |
| 80 | Selected-band visual disc | Draw above other discs when overlap occurs |
| 90 | Badges and active interaction rings/halo | Draw selected badge and active rings above discs; handle overlay not clipped to plot |
| 100 | Axis labels in dedicated gutters | Place with established anchoring; do not cover handles or response within plot |

For geometry, **one plot coordinate system** serves all layers even when their clipping differs. A lower-priority unselected band must not hide the selected handle when their values coincide. Badge values are band indices **1–6** only, not new status labels.

**Z-order and translucency:** paint the fill at alpha 14% and the zero line as its own 60%-alpha line. No generic additive blend mode; use normal **Source-over** for every translucent graph/handle treatment.

## 9. Rendering feasibility in Qt 6 / QML

- **Surface:** keep Board 02 `Rectangle` + two-stop vertical `Gradient`, 1-lp border, 6-lp radius and static lightweight inset treatment exactly as inherited. Nothing from this manifest overrides those tokens. Apply `clip: true` only to the inset plot-painting child; the host/overlaid handles must remain unclipped to prevent clipped halos and hit targets at the actual parameter extrema.
- **Grid:** cache or draw static `Shape`/`Canvas` lines calculated from the same `plotRect`; refresh only when plot size or effective `fMax` changes. For a crisp 1-lp Windows 10 line, snap geometric strokes to half-pixel centers as appropriate for the actual device-pixel ratio, without rounding the mathematical frequency/gain coordinates themselves.
- **Curve:** use `Shape`/`Path` or `Canvas` with source points from C++ `selectedBandResponsePoints`. A 6-lp translucent under-stroke followed by a 2-lp anti-aliased line replaces expensive continuous blur. Only redraw on data/geometry/state changes.
- **Fill:** use Canvas or Shape geometry closing the **selected** response to the 0-dB baseline; at zero crossings, split the display polygon into positive/negative areas for the correct 14%→0% direction. Normal Source-over; no analyzer texture or raster layer.
- **Handles:** vector circles/`Rectangle` with `radius = diameter / 2`, radial-fill approximation with static nested discs if needed, 2-lp colored outlines, text badges, and 1–3 low-alpha concentric rings for hover/selection/drag glow. Hit targets remain transparent and centered. Do not make shader-based blur mandatory.
- **Performance:** plotting and handles must remain responsive at the minimum window size during dragging. Visual drafts may change each interaction frame; no new DSP calculation, Preview render, animated blur or shader recompilation is permitted as a consequence of the visual treatment.
- **Color serialization:** **always** use the QML column `#AARRGGBB` for eight-digit hex in Qt Quick, or perform the verified one-time byte permutation from design tokens. Do not write design `#RRGGBBAA` strings directly to `color`, `border.color` or `GradientStop.color`.

## 10. Token reuse and explicit precedence

| Classification | Tokens / roles | Authority and promotion rule |
|---|---|---|
| **SHARED RGS — INHERITED** | `rgs.raw.cyan`, `rgs.prepared.teal`, `rgs.processed.purple`, `rgs.gold.amber`, `rgs.error.coral`, `rgs.warning.yellow`, `rgs.neutral.*`; Segoe UI / font fallback references | **Board 02 v1.1 / Board 03 v1.0**, subject to prior GUI-01 authority. No global color/font amendment here |
| **EQ structural — INHERITED** | `eq.graph.bg`, `gradTop`, `gradBottom`, `border`, `radius`, `highlightTop`, `shadow` | **Board 02 v1.1**, not newly proposed Board 04 materials |
| **MASTERING MODULE FAMILY — PROPOSED** | `mastering.graph.grid.major/minor/micro`, `mastering.graph.zero`; restrained grid hierarchy and common plot-label practice | May inform later editor designs only after separate adoption; does not create new global `rgs.*` tokens |
| **EQ-LOCAL — PROPOSED** | `eq.plot.*`, `eq.graph.curve.*`, `eq.band.1…6.identity`, `eq.handle.*`, axis/handle local projection and presentation | Applies to M12B graph/handles only pending integration review |

**Reconciliation notices:**

- The Board 04 picture prints a graph-border color matching canonical `eq.graph.border` but a separate apparent axis-text RGB (`#9FB4C9`). **Board 02/03 `rgs.neutral.300 #A1B5C9` wins** for axis labels. There is no new shared text token.
- The Board 04 picture's faint grid colors, curve cyan and six band identities are **new proposals** local to this graph/handling family. They cannot replace Board 02 structural tokens or redefine processing semantics.
- The Board 04 illustration's selected band-4 curve summit and any other pixel-derived coordinates are **not** valid geometry data. C++ samples and current band parameters are authoritative.
- The selected band-4 **tinted radial-fill specimen** is the only exact selected-fill color pair shown in Board 04. The common neutral fallback for other selected identities is stated explicitly in §7 rather than fabricated as unseen per-band swatches.

## 11. Integration-review acceptance checklist

- [ ] **Macro size:** graph 992 × 324 lp at 1040 × 660; 852 × 244 lp at 900 × 580. Plot 928 × 292 / 788 × 212 lp with no clipping of axis text or handles.
- [ ] **Projection:** all response samples and band handles share one frequency-log / gain-linear `plotRect` and the effective C++/Source `fMax`. At 44.1 kHz the right boundary is **19845 Hz**, **not** 20 kHz.
- [ ] **Content truthfulness:** exactly **one selected-band curve**, obtained only from C++ `selectedBandResponsePoints`; all existing independent band handles visible. No combined EQ curve or analyzer, including when MIXED ROUTING ACTIVE is true.
- [ ] **Selected-band sample:** Band 4 Bell at 2 kHz / +6 dB / Q 0.707 uses **actual** C++ response and parameter positions; do not inherit any peak overshoot from the image.
- [ ] **Line hierarchy:** major/minor/micro grid 1 lp with their exact alpha, one visually stronger 0-dB line, legible Segoe UI axes at both graph heights; tick labels never exceed `fMax`.
- [ ] **Response:** 2-lp sharp local-cyan line, 6-lp restrained 35%-alpha under-stroke, selected-curve-to-zero fill at 14%→0%; no panel-wide decorative glow, no out-of-plot curve rendering.
- [ ] **Handles:** default **20 lp**, selected **24 lp**, hover ring **28 lp**/1 lp/40%, stroke **2 lp**; 1.1 pressed scale yields **22 lp unselected** and **26.4 lp selected**; badge legible and selection recognizable without relying solely on color.
- [ ] **Semantics:** Band 4 pink is not `rgs.error.coral`; band 3 is not warning/GOLD; band 5 is not PROCESSED purple. The six exact identity RGB values remain EQ-local.
- [ ] **Interaction:** drag axes and commit-on-release unchanged; no per-move Render Preview, snapping, reordering or DSP logic in QML.
- [ ] **Scope:** MIXED ROUTING ACTIVE only in the Inspector. Board 01–03 are unchanged. No new control, system-wide palette change, shader dependency, QML implementation handoff or premature package-wide freeze.

**Gate:** submit this **Board 04 Manifest v1.0** together with visually approved Board 04 Revised Candidate for **Product Owner / integration review** before drafting or freezing later boards.


## APPENDIX — v1.1 independent technical reconciliation (23 September 2026)

- This v1.1 is a deterministic correction of the supplied 259-line GUI v1.0; all Board 04 material, typography, color, curve, handle diameter, coordinate projection and interaction tokens remain unchanged.
- **Correction A:** grid Z table now agrees with the mandatory draw order: micro Z20, minor Z21, major Z22. The source v1.0 reversed these ordinal Z values despite correctly stating the intended compositing order in prose.
- **Correction B:** the existing implementation currently clips the entire graph QML root; an inset plot-only clipped child plus unclipped handle overlay is explicitly required to implement v1.0’s requested full-size extreme-position hover/halo without silently changing the mathematical plot or Board 01 macro geometry. At maximum frequency and +18 dB, selected halo may extend 8 lp outside the well on the right and 10 lp above it; the approved 24-lp content inset and 12-lp section gap can accommodate that. Minimum-size staged visual and pointer-hit testing remains a future implementation gate.
- Source 8-digit design RGBA and Qt ARGB rows have been mechanically verified. Any subsequent QML code must use the Qt column rather than original design strings.
- This document freezes **only the scoped M12B Board 04 visual/numeric design specification after independent integration review**, not the implementation, global design-system promotion, the complete WOW package, Windows Full qualification or PO visual/listening gates.
