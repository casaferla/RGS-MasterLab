# RGS MasterLab — L1-M12B — VISUAL WOW QML IMPLEMENTATION HANDOFF v1.0

**TASK STATE:** READY FOR IMPLEMENTATION, PO-FROZEN VISUAL TARGET.  
**Recommended Jules reasoning:** MEDIUM FIRST; escalate to HIGH only on measured geometry, Qt runtime or test contradictions; do not spend retries guessing.  
**Agent-neutral:** instructions apply to Jules or any coding agent with the checked-out authorized PR branch.  
**Product:** RGS MasterLab — Reference Guided Sound — Gold Reference Mastering Environment. Windows 10/11 x64 primary, Android not in this M12B visual task.  
**Operating rule:** implement, test and push to the SAME Draft PR #8; do not merge or start M13.

## 0. Exact authority and supplied files — read first

The Product Owner has **explicitly frozen all eight L1-M12B WOW design boards**. This is a visual-target freeze, NOT runtime certification. You are implementing an already-decided design, not producing a new visual concept. Read this file and ALL eight files in the accompanying `manifests/` directory, the root repository `AGENTS.md`, and current code BEFORE editing. The zipped distribution may be extracted and supplied as a folder to the coding agent. Do not assume access to the owner's private Google Drive unless the files are explicitly present.

| Board | Frozen source filename suffix | Scope | Drive ID (continuity only) |
|---|---|---|---|
| 01 | `Board01_Canonical_Macro_Geometry_Manifest_v1.0.md` | Windows tool window geometry | `1fvmY4lwh3XurzDy2Jcxnx73EniJ3-tY8Jeo68Vw-Beg` |
| 02 | `Board02_Canonical_Material_Token_Manifest_v1.1_QML_Safe.md` | Studio Slate materials/ARGB-safe pigments | `1VrGCJgVRx_vPdlFvqCxwUck08YeDW69A` |
| 03 | `Board03_Canonical_Typography_Numeric_Manifest_v1.0.md` | Segoe UI/Consolas and numeric field anatomy | `19ilTo0KuiYguN7cGBN-T83NPM7yfHcWQ` |
| 04 | `Board04_Canonical_Graph_Handles_Manifest_v1.1_Integration_Reconciled.md` | selected-band-only curve and independent handles | `1qJW-hRyw4M67EpZ49zKryDcuB9W_g0zx` |
| 05 | `Board05_Canonical_BandSelector_Preview_AB_Manifest_v1.1_Integration_Reconciled.md` | band selector, responsive actions, preview and A/B | `13N8VgTWLawJm2aadAI7KBKc-OTIQLNDA` |
| 06 | `Board06_Canonical_Inspector_Controls_Manifest_v1.1_Integration_Reconciled.md` | Inspector filter/routing/toggle/fields | `1HbNBx1SKCVHdq-gQDiDmC6yp7LdUYOya` |
| 07 | `Board07_Canonical_MixedRouting_Validation_GlobalStates_Motion_Manifest_v1.1_Integration_Reconciled.md` | Mixed, validation, statuses, animation | `1IBiXJFUvNxGV17UyaquAlCkF0Zda2Pdo` |
| 08 | `Board08_Canonical_Integrated_EQ_Editor_Composition_Manifest_v1.1_Integration_Reconciled.md` | final composition and integration gates | `1G0sfoqw-wkhfWqf8w7tRmSU6cZwp5oCb` |

Precedence: latest explicit PO frozen choice / accepted functional contract > latest accepted scoped manifest for the component > accepted implementation > visual specimen. Board08 composes but never silently replaces 01–07. `visual_refs/Board01_*` and `visual_refs/Board08_*` are aesthetics/proportion ONLY, including Board08 miniature with LEFT erroneously missing; their microtext is not authoritative. `visual_refs/M12B_PreWOW_Real_Windows_*` is the current code's visual baseline, not the desired final state. When sources disagree, do not improvise; report a bounded `VISUAL_BASELINE_CONFLICT_DISCOVERED`.

The eight-board consolidated authority index, PO freeze decision and historical task are project continuity, not permission to reopen M12A DSP architecture or the main-shell GUI-01 freeze.

## 1. GitHub continuity / BEFORE ANY EDIT

- Repository: `casaferla/RGS-MasterLab`.
- Existing Draft PR **#8**: `L1-M12B: Parametric EQ Visible Editor and Windows Gate Preparation`.
- Same Jules session/task: **9003884410820853273**.
- Existing PR branch: `draft/m12b-parametric-eq-editor-window-9003884410820853273`.
- Base `main` SHA observed `8f1b8d5f6ce2c2ba08b3c82eae6b3010cd50998b`, already accepted M11A/M11B/M12A.
- Latest independently audited current PR HEAD: **`5676505f586738d29349b3a2f4907ba011575141`**. Immediately re-fetch the live HEAD; do not hard-reset valid newer same-PR commits. If the PR has merged, wrong branch is checked out, scope changed or another agent has a conflicting active edit, STOP with a precise report.
- At audited HEAD: **PR Focused CI #48 (run 35820585028) GREEN on both Windows and Linux.** Windows actual Qt/UI smoke and visual-evidence artifact passed. This is a pre-WOW focused baseline, not the future WOW qualification.
- Confirm `git status`, root `AGENTS.md`, whether protected root file `RGS_MasterLab_CODEX_TASK_001-2.md` exists in the worktree, present QML APIs and existing tests. IF PRESENT, protected file expected SHA-256 `3669527CB6DD75E59254C6C73070647466E7C54F04321D17B011F743C15D0FFF`; do not open it for modification, stage, commit, delete, rename or reformat it.
- Show a concise file-by-file implementation plan and a *runtime-measurement plan* BEFORE coding, then proceed directly only if all inputs are present.

## 2. Strict bounded scope and file allow-list

**Production QML primary edit allow-list:**
- `ui/qml/ParametricEqEditorWindow.qml`
- `ui/qml/ParametricEqEditor.qml`
- `ui/qml/ParametricEqGraph.qml`
- `ui/qml/StudioNumericField.qml` (EQ-only current component; preserve real onTextEdited forwarding, Enter/valid focus-out/Escape behavior)

**Optional, only if required for maintainable EQ-local design:**
- New `ui/qml/EqVisualTokens.qml` (EQ-local references to frozen tokens) and/or `ui/qml/EqSegmentButton.qml` (EQ-local 28-lp segmented control adapter without global `StudioButton` changes).
- `ui/CMakeLists.txt` **only** to register those optional files in the existing Qt module, using current patterns.

**Test/evidence allow-list:**
- `tests/ui_smoke/test_source_metadata_panel.cpp` existing Windows smoke, extend in place.
- `tests/CMakeLists.txt` only if genuinely needed for existing smoke registration (justify).
- `.github/workflows/pr-focused.yml` only if a narrow artifact or measurement evidence upload adjustment is demonstrably necessary; it already uploads Windows visual evidence in CI #48. Do not needlessly churn workflow files.

**Do not edit:** all `app/src`, `app/include`, `dsp`, unrelated UI or shared `StudioButton.qml` / `StudioToggle.qml`, `ui/qml/Main.qml`, accepted DSP fixtures, protected root task file, main-shell geometry, or Windows Full Qualification workflow as part of this focused visual pass. If genuinely required to meet frozen scope, STOP and propose a separate explicit file allow-list delta with evidence. No new DSP math or C++ ViewModel properties. No Android scope in this task.

Avoid unrelated refactors, dependency installation, broad reformatting, new shortcuts, hidden alternative workflows, new panels or features.

## 3. Milestone A — measured runtime preflight (mandatory early gate)

Before expensive visual polish, establish whether real Windows Qt client and frame coordinates can realize the frozen dimensions. Jules may be running in a Linux VM: in that case make a first **minimal diagnostic test-only commit on the SAME Draft PR**, run the existing Windows Focused CI runner and inspect its measurement artifact before committing the extensive visual patch. Do not mistake offscreen Linux measurements for actual Windows frame behavior. Measure/log `Window.width`, `Window.height`, `frameGeometry` (if available), editor and each major child bounds in *logical pixels* at **1040×660** and **900×580**; measure the actual available client/content rectangle, padding and non-client native decoration. Native Windows frame extents must not be confused with the QML item's client size. If Board01's 'outer window' and the nominal 24-lp effective inset cannot simultaneously fit because of native decoration, STOP and present the observed client/frame values and ONE bounded host-specific reconciliation proposal for PO approval, rather than silently resizing the 900×580 minimum or hiding controls.

Also measure real current font glyph metrics, `StudioButton.implicitWidth/implicitHeight` (known pre-WOW implicitHeight ~32 lp), tooltip/focus outsets, and Inspector six-Filter/five-Routing/Mixed fit. The latter has only **7 lp** and **12 lp** nominal reserve, respectively. Report technical limits explicitly; never claim static visual art proves Qt fit. If a local QML adapter solves geometry without changing any frozen dimensions/typography/shared controls, proceed; otherwise STOP `M12B_WOW_MEASURED_LAYOUT_CONFLICT` with precise object coordinates and proposed narrow EQ-local delta.

## 4. Milestone B — exact window and five-section composition (Boards01,02,08)

Implement tool-window client/editor composition per the frozen Board01 and Board08 package, preserving native non-modal host and the existing Main View→Parametric EQ… wiring without editing Main. No internal fake titlebar controls, duplicated brand/logo, PREPARED/PROCESSED/GOLD selector, `BANDS` label, or extra controls. `1040×660` default and `900×580` minimum outer design target, **24 lp effective content inset** all four edges (documented 8+16), five full-width vertically stacked sections and four 12-lp gaps:

| Region | Default | Minimum |
|---|---:|---:|
| Header | 48 | 48 |
| Band Strip | 40 | 40 |
| Response Graph | **324** | **244** |
| Inspector, TWO TIER below graph | 128 | 128 |
| Status/Validation BELOW Inspector | 24 | 24 |
| Four inter-section gaps | 48 | 48 |
| Inner content height | **612** | **532** |
| Inner content width | **992** | **852** |

The graph is the ONLY height-flexible region. Do not reflow the Inspector beside the graph, add horizontal scrolling or reduce text to fake minimum-fit. Honor all frozen Studio Slate material tokens from Board02: distinct Window Frame, Editor Panel, shared Control Surfaces, recessed Graph Well and overlays. Every opaque gradient is a single vertical two-stop replacement for its base fallback, not an extra opaque layer. Apply approved border/radius, top highlight, subtle outer/inset shadows; avoid costly blur or heavy shaders. Qt/QML 8-digit colors MUST be `#AARRGGBB`, translated from design `#RRGGBBAA`; do not sample artwork or paste RGBA literal directly. Avoid generic dark-Qt fallback and arcade neon.

## 5. Milestone C — header, selector and A/B (Boards03,05,07)

Header48: `Parametric EQ` Segoe UI20/600/line24 and `Manual Mastering`12/400/line16 left; right: Preview Status immediately LEFT of mutually exclusive A EQ Active/B EQ Module Bypass. Four PUBLIC badges `NO PREVIEW`, `RENDERING`, `READY`, `ERROR`; raw ViewModel sentinel `IDLE` or `NO_PREPARED_REALIZATION` both display as neutral **NO PREVIEW**, no extra fifth state or new C++ enum. Other labels preserve truth, with tooltip/accessible text. A uses active cyan and B uses contextual bypass amber when selected (NOT global GOLD selection). A/B share the SAME EQ parameters and drive existing real `setBypass(false/true)`. A/B may trigger preview regeneration: do not keep stale READY after an actual ViewModel transition. Bypass does not disable editing. Preflight Header layout at the widest NO PREVIEW/ERROR string at min width.

BandStrip40: exactly 1..6 existing band selectors with ordinal + real filter abbreviation `BELL/NOTCH/LS/HS/HP/LP`, tooltip/Accessible full name. Selected vs processing-disabled must be distinct; processing-disabled bands remain SELECTABLE and EDITABLE. Buttons 90×32 lp radius8, interbutton gap8. Six-selector group `6×90+5×8=580`; postband gap12 + separator-inclusive 24 + Add128/96 + action gap12 + Remove128/96 + right margin20 = **904 default of992** / **840 compact of852**. Full actions128×32 if inner≥916; compact96×32 if inner852–915. Preserve nominal left empty reserve88/12 without leaking into uncounted spacers. At 6 bands Add disabled; at 1 band Remove disabled; availability always from EXISTING count, independent of Enabled. Add/Remove are MOMENTARY +/− icons in ALL states, not persistent selected buttons. No seventh button, ghost bands, reorder or obsolete `BANDS` text. Never modify global `StudioButton` to obtain local layout.

## 6. Milestone D — RESPONSE GRAPH / handles (Board04)

Graph background `eq.graph.*` from Board02 (recessed, not `eq.panel.*`). Use one common graph projection/plotRect for grid, curve, fill and handle centers. At default Graph992×324 → plot `(52,10,928,292)`; at minimum Graph852×244 → plot `(52,10,788,212)`: left52/top10/right12/bottom22. X logarithmic `[20, min(20000,0.45Fs)]`; Y linear symmetric ±18 dB, numeric markers +18/+12/+6/0/-6/-12/-18. `Fs=44100` right endpoint19845 Hz (NOT fake20k). `Fs=48000` right endpoint20000 Hz. Preserve actual C++ `selectedBandResponsePoints` as ONLY curve source; do not calculate filter transfer in QML, interpolate all six band handles into aggregate curve or invent analyzer data.

Selected cyan `#2ED3FF` (#FF2ED3FF in QML), 2-lp stroke, 6-lp contained halo at35%, fill 14% on actual selected line down/up to ZERO line, alpha0 at zero; fill handles curve crossing 0dB without painting to graph bottom. Preserve local grid hierarchy and overlay z-order, quiet background and accurate label collisions from Board04. Exactly one independently modeled handle per existing band, no duplicate ordinals; selected24 lp / others20 lp with the six Board04 identities; nonapplicable Gain filters do NOT acquire a fake gain edit. For BELL/shelves selected x frequency and y gain draft; for NOTCH/HP/LP x frequency only. Drag updates visual draft; `graphRelease()` commits ONCE; no preview request per pointer movement. QML presentation mapping is permitted, no DSP/filter math.

**Important current source mismatch:** `ParametricEqGraph.qml` currently has `root.clip: true`; this can cut off edge handles, focus rings and hover glows. Clip **grid+curve+fill to plot**, but render interactive handle overlay ABOVE the plot clip; verify both extremes with pixel evidence and hit testing. `mixedRouting` indicator must NOT remain inside graph; the single badge belongs to Inspector Routing.

## 7. Milestone E — Inspector and numeric inputs (Boards03,06,07)

Fixed Inspector128, horizontal inner padding16 each at minimum Inspector width852 → **usable820**. Vertical `top6 + Filter28 + upper gap4 + Routing28 + tier gap4 (divider contained) + complete numeric50 + bottom8 =128`. Band identity / Enabled column160 spans both upper rows. Filter row: `160+8+56+8+(6×96+5×1)=813` of820 reserve7. Routing row with Mixed: `160+8+56+8+(5×80+4×1)+8+164=808` of820 reserve12. All six Filter controls in original order Bell/Notch/Low Shelf/High Shelf/High Pass/Low Pass; all five routing options Stereo/Mid/Side/**Left**/Right and one contextual **164×28** Mixed badge when true. Do not hide LEFT, add a sixth Mixed mode, reduce font, stack labels or add horizontal scroll to fake minimum fit. Mono: Stereo available; other four visible but unavailable. Processing-disabled selected band remains inspectable and parameters editable. Filter/routing segment heights are EQ-local **28 lp**, despite pre-WOW shared StudioButton implicitHeight ~32; use an EQ-local size override/adapter, not a global component change.

Mixed = `viewModel.mixedRouting` only, derived from at least two ENABLED COMMITTED bands with DIFFERENT routing values. It is ONE NONINTERACTIVE badge in Inspector Routing, never duplicate in graph/Status. Eq-local badge164×28 radius8 border1 inside; exact design RGBA→QML ARGB `background #6C4EA633→#336C4EA6`, `border #A989F2B3→#B3A989F2`, `text #E9DCFFEE→#EEE9DCFF`. This violet is not global PROCESSED purple. No hover/focus/button states on badge.

Lower tier: Bell Frequency+Gain+Q; Notch Freq+Q; Low/High Shelf Frequency+Gain+numeric UNIT-LESS ShelfSlope; HP/LP Frequency+SIX DISCRETE slope choices 6/12/18/24/36/48 dB/oct, not dropdown. Hide nonapplicable controls entirely (no disabled placeholder). Use Segoe UI for labels (12lp/600) and Consolas for numeric values (16lp/400), inherited fallback; numeric complete component50=label16+gap6+input28; proposed EQ-local input box width164. Numeric values right aligned; optional `Hz`/`dB` suffix **to the RIGHT of the input box** after8lp gap, suffix glyph text LEFT aligned (not the unit on left of the input). No artificial input precision cap, no silent clamp. Preserve real existing C++ validation and draft APIs. Invalid raw text remains visible and visibly coral, never publishes DSP or preview; Enter valid commit, valid focus-out commit, Escape cancel. Editing remains usable in bypass.

HP/LP lower strip subtotal `164 Frequency input BOX +16 group gap+56 SLOPE label+8 gap+485 segmented slope =729 lp` of820; the **8lp Hz gap, actual Hz glyph width and focus outsets are NOT contained in729** and must fit in residual91. Measure all Qt children, no clipped suffix/focus/tooltip. If this or the tight upper row budget fails, STOP with numeric measurements for PO narrow local delta.

## 8. Milestone F — Status, semantics and microstates (Boards02,03,05,07)

External Status/Validation Strip24 tall, 12 gap below Inspector. **Literally empty** when no eligible actual error: no neutral READY text, dot, fake success, Mixed duplicate or debug labels. `validationMessage` nonempty overrides actual `previewError` when previewStatus ERROR; only real ViewModel strings, coral immediately; ellipsis if necessary but full tooltip+Accessible text, fixed24 height. Preview badge stays in Header only; errors do not change section dimensions.

Use inherited control-state colors from Boards02/03/05/06 exactly, including Normal/Hover/Pressed/Selected/Focus/Disabled/Invalid, and precise focus rings that never clip. EQ-local motion TARGETS from Board07: hover80ms, pressed60, keyboard focus visible immediately0ms, selected120, toggle100, decorative status150. Required semantic state and validation/error content visible immediately; only modest decorative interpolation. Reduced Motion must stop/minimize nonessential effects when platform support exists. No costly continuous blur, numeric-value tweening, drag lag or new runtime motion state.

## 9. Milestone G — smoke, evidence, automated checks

Extend the EXISTING Windows UI smoke `tests/ui_smoke/test_source_metadata_panel.cpp` in its existing production-like setup, retaining all current pre-WOW functional assertions. At a minimum, test/measure real item bounds and resulting screenshot pixels for the following matrix:

| Variant | Essential proof |
|---|---|
| Fresh UI | No QML errors, correct Main shell and menu, tool window opens as before; initial IDLE shown as NO PREVIEW if observed. |
| 1040×660 / one band | Exact five-region vertical dimensions, only existing band selector, Remove disabled, Add available, empty neutral status. |
| 1040×660 / six bands | All 6 real band labels, Add disabled and Remove enabled regardless of Enabled values, valid A/B preview. |
| 900×580 / six bands / Mixed | EXACT all 6 Filter and 5 Routing including LEFT fully visible and clickable, single badge164×28, compact Add/Remove96, no clip/overlap/scroll. |
| 900×580 / mono | Stereo available; Mid/Side/Left/Right physically visible but unavailable; Badge reflects ViewModel truth. |
| Both sizes graph | One Bell Band1 Fs48k 1000Hz +3dB Q.707 C++ response, independently placed other handles, correct end labels; separately Fs44.1k19845 bound; no root clipping at plot extremes. |
| Filter family | Bell, Notch, shelves, HP/LP six slope BUTTONS visibility and actual existing edit/commit, no fabricated disabled placeholders. |
| Invalid entry | Simulate genuine keyboard user editing (NOT programmatic `text=`); show raw `99999`, ViewModel validationField and message; no DSP commit/preview from invalid; Escape restores confirmed, clears indicator. |
| A/B | A/B mutually exclusive with real existing module bypass, selected styles distinct; bypass-triggered preview refresh truthfully rendered. |
| Focus/motion | Keyboard focus through principal controls including all selected/disabled variants, activeFocus visible immediately at both sizes, no clipped focus; Reduced Motion if supported. |
| Main shell regression | Existing global shell frozen layout/1440×900 evidence unchanged. |

When `RGSML_GUI01_EVIDENCE_DIR` is set, save named real Windows screenshot files (not AI mockups): `m12b_wow_1040x660_1band.png`, `m12b_wow_1040x660_6bands.png`, `m12b_wow_900x580_6bands_mixed.png`, `m12b_wow_900x580_mono.png`, `m12b_wow_invalid_draft.png`, `m12b_wow_keyboard_focus.png`, `m12b_wow_ab_bypass.png`, `m12b_wow_graph_44100_end.png`, `main_shell_1440x900_postwow.png`, plus machine-readable `m12b_wow_runtime_geometry.json` listing observed client/frame/item x,y,w,h and implicit metrics. Use existing screenshot/evidence helpers; if one state is impossible without unsafe backend hooks, state exactly what was/wasn't verified and STOP for review. No fake app screenshot.

Do not use only static diagram width sums as test pass. Inspect real Qt logical dimensions and assert no overlap in targeted windows, especially last Filter, LEFT, badge, HP/LP Hz suffix, action button focus outsets and graph extreme handles. Keep Linux focused tests unchanged and green. Current pre-WOW PR Focused CI #48 was green on both Windows and Linux; the NEW HEAD after visual edits must pass the same jobs, actual Windows UI smoke and evidence upload. No Windows Full in this task; only the PO/Chat authorizes its manual dispatch after independent technical and visual review.

## 10. Deterministic bounded execution sequence

1. Confirm same Draft PR branch, live HEAD, root instructions, manifest availability and allow-list; verify protected root file unchanged.
2. Instrument/measure both target Windows sizes **first**, including native frame vs QML client semantics, all 6/5 controls and focus outsets. If frozen figures do not truly fit, STOP with measured conflict before extensive styling.
3. Implement frozen EQ-local material/type/state tokens and five fixed macro sections, no shared-wide palette/button refactor.
4. Implement Header/Preview/A-B and responsive 1..6 band strip, then graph and independent handle overlay, then Inspector and status/numeric controls. Preserve existing viewModel data, C++ transfer response and genuine edit semantics.
5. Extend in-place Windows UI smoke + exact geometry/assertions + visual evidence. Run relevant local tests if available, then commit only allow-listed paths and push to SAME Draft PR.
6. Wait for the new PR Focused Windows AND Linux CI. If red, identify the FIRST real failure, fix only bounded cause in the SAME PR, rerun. Do not claim CI passed based on compilation alone.
7. At new green HEAD: report commits, changed filenames, geometry JSON and screenshot artifact run ID, test commands/results, documented deviations (if any), and protected SHA. STOP for independent Chat technical + visual/source audit; do not self-certify PO Gate M or L, do not run Windows Full, do not merge or start M13.

**If file scope or dimensions conflict:** emit `M12B_WOW_MEASURED_LAYOUT_CONFLICT` or `M12B_WOW_BASELINE_CONFLICT_DISCOVERED` as appropriate, provide the exact QML item/font/coordinate measurements and smallest explicitly proposed EQ-local delta; no silent redesign and no speculative retry loops.

## 11. Final acceptance remains external

Design pack eight manifests = PO-FROZEN. Code implementation = NOT YET APPROVED. Required downstream sequence: new PR Focused double green → independent source/technical and real Windows visual review → manual Windows Full Qualification (Debug full, Release full, tests-off Release, stage/deploy smoke + artifact) → staged Release → Product Owner Gate M (UI/interaction) → Product Owner Gate L (real RGS source + Gold Reference human EQ bypass/listening tests) → explicit PO merge permission → merge PR #8 → only then M13. No coding agent may mark these PO gates passed on its own.

Do not modify prior accepted M11A, M11B or M12A architectural contracts. Do not start M13 in this task.
