# RGS MasterLab — L1-M12B
# BOARD 07 — CANONICAL MIXED ROUTING / VALIDATION / GLOBAL STATES / MOTION MANIFEST v1.1 — INTEGRATION RECONCILED

**Deliverable:** text-only, deterministic visual/interaction specification for the existing Parametric EQ Editor.  
**State:** **Board 07 design scope independently reconciled and accepted for M12B**, with the later Qt/QML runtime verification gate still mandatory. The complete Visual WOW Design Package is **not** declared frozen by this document.  
**Platform acceptance baseline:** Windows desktop / Qt 6 / QML.  
**Product:** RGS MasterLab — Reference Guided Sound — Gold Reference Mastering Environment.  
**Scope:** contextual Mixed Routing indicator; the four existing preview statuses; independence of preview and EQ-module A/B; existing validation presentation and 24-lp Status / Validation Strip; authorized combinations of existing states; nonfunctional UI motion proposals and accessibility safeguards.

---

## 1. Authority, precedence, and non-supersession

| Pre-existing authority | Governs here | Board 07 does **not** change |
|---|---|---|
| Board 01 — Canonical Macro Geometry v1.0 | Tool-window geometry; independent Header, Band Strip, Graph, Inspector, and Status / Validation regions | Window `1040 × 660 lp` default / `900 × 580 lp` minimum; effective inset `24 lp`; inter-section gap `12 lp`; Header `48 lp`; Band Strip `40 lp`; Graph `324 lp` default / `244 lp` minimum; Inspector `128 lp`; external Status / Validation Strip `24 lp` |
| Board 02 — Canonical Material Tokens v1.1 QML-Safe | All structural Studio Slate materials, inherited semantic colors and overlays, and color-notation convention | No new global material, gradient, surface, or semantic color |
| Board 03 — Canonical Typography & Numeric Fields v1.0 | Segoe UI / Consolas roles, direct-entry anatomy, numeric focus/invalid treatments, and text hierarchy | No type-family substitution, numeric-field redesign, alternate validation rules, or new runtime applicability |
| Board 04 — Canonical Graph & Handles v1.1 Integration Reconciled | Selected-band-only C++ response, handles, graph geometry and rendering | No composite curve, spectrum, graph restyling, or additional graph indicator |
| Board 05 — Canonical Band Selector / Preview Status / A-B v1.1 Integration Reconciled | Existing four preview states, Header badge, mutually exclusive A/B, control state visuals and accessible names | No second preview badge, altered A/B semantics, invented status, or button family redesign |
| Board 06 — Canonical Inspector Controls v1.1 Integration Reconciled | Inspector two-tier structure; Routing subrow; badge envelope; actual Filter/Routing/HP-LP controls | No alteration of Inspector or segmented-control dimensions; no new routing mode |

**Precedence:** these earlier authorities govern their existing subjects. Board 07 contributes only the **EQ-local Mixed Routing pigments and associated noninteractive badge treatment**, the documented status/error composition of existing runtime values, and **EQ-local proposed motion tokens**. In any apparent conflict with the authorities above, an earlier inherited specification prevails; request a narrow Product Owner-approved delta instead of silently changing it.

**Important separation:** the `48-lp` Header owns preview and A/B; the `128-lp` Inspector owns Mixed Routing; the `24-lp` external Status / Validation Strip owns eligible error text. These are three separate regions and must not be merged.

### 1.1 Classification vocabulary

- **SHARED RGS — INHERITED:** approved global semantic/color/typography references, reused without redefinition.
- **MASTERING MODULE FAMILY — PROPOSED:** a future reusable component pattern, not made globally canonical by Board 07. No new such pigment is needed here.
- **EQ-LOCAL — PROPOSED:** the three Mixed Routing colors, their local badge presentation, and the motion targets in §12. Promotion requires independent approval.

---

## 2. Mixed Routing — existing functional condition and single-indicator policy

`mixedRouting` is an **existing derived ViewModel property**. Its truth condition is: **the enabled bands contain at least two different Routing values**. A band that exists but is processing-disabled does not, by itself, contribute to this test. A band neither stores nor independently activates a `mixedRouting` mode.

| Attribute | Canonical requirement |
|---|---|
| Source of truth | Existing ViewModel `mixedRouting` boolean, derived in existing C++ logic |
| Visible text | `MIXED ROUTING ACTIVE` |
| Count | **One badge only**, regardless of number of bands or distinct routings |
| Location | **Inspector → Routing subrow**, after the five normal Routing options |
| Visibility | Visible only when `mixedRouting == true`; completely hidden when `false` |
| Interaction | **None:** non-button, non-toggle, non-selectable, non-focusable, no Hover/Pressed/Selected variants |
| Effect on graph | **None:** graph still renders only `selectedBandResponsePoints` from C++ for the selected band; other bands have independent handles |
| Forbidden | Per-band Mixed badges, a sixth Routing mode, Status Strip duplicate, synthetic combined curve, or independent user switch |

**Illustrative derived state — `true`:** Band 1 = Stereo, Band 2 = Mid, Band 3 = Left, Band 4 = Right; **all four enabled**. Show one `MIXED ROUTING ACTIVE` badge for the Inspector as a whole, not one per band.  
**Illustrative derived state — `false`:** all enabled bands use Stereo. The badge is absent. Disabled bands must not trigger a mixed designation by themselves.

### 2.1 Inspector Routing geometry — inherited design target

The complete Inspector is `128 lp` tall. At minimum inner width `852 lp`, it has `16 lp` horizontal padding per side, hence **usable width `820 lp`**. Reuse Board 06 exactly:

| Routing-row child | Width |
|---|---:|
| Band + Enabled column | `160 lp` |
| Gap | `8 lp` |
| ROUTING label column | `56 lp` |
| Label-to-controls gap | `8 lp` |
| Five Routing segments + four shared dividers | `5 × 80 + 4 × 1 = 404 lp` |
| Gap before Mixed badge | `8 lp` |
| Mixed badge | `164 lp` |
| **TOTAL REQUIRED** | **`160 + 8 + 56 + 8 + 404 + 8 + 164 = 808 lp`** |
| **AVAILABLE** | **`852 − 16 − 16 = 820 lp`** |
| **REMAINING DESIGN BUDGET** | **`12 lp`** |

Routing options remain exactly **Stereo, Mid, Side, Left, Right**. The `8-lp` badge gap and all shared `1-lp` dividers are already counted. **Do not add unbudgeted padding, separator width, or margins.** These are design targets, **not** proof of actual Qt implicit-size fit; §17 contains the mandatory runtime gate.

### 2.2 Mixed badge exact local anatomy

| Property | Value | Classification |
|---|---|---|
| `eq.mixed.width` | `164 lp` | Board 06 inherited geometry |
| `eq.mixed.height` | `28 lp` | Board 06 inherited geometry |
| `eq.mixed.radius` | `8 lp` | EQ-LOCAL — PROPOSED, approved Board 07 visual direction |
| `eq.mixed.borderWidth` | `1 lp`, drawn **inside** its allocated bounds | EQ-LOCAL — PROPOSED |
| `eq.mixed.font` | Segoe UI | Board 03 family inherited |
| `eq.mixed.fontSize` | `12 lp` | EQ-LOCAL badge-specific proposal |
| `eq.mixed.fontWeight` | `600` | Board 03 control-label hierarchy inherited |
| `eq.mixed.label` | `MIXED ROUTING ACTIVE`; vertically and horizontally centered | Existing approved user-facing wording |
| Background compositing | **Source-over**, clipped to local badge radius | Uses pigment in §3; no additive blend |
| Glow / motion | **None required**; status appears/disappears with the derived condition and does not acquire interaction states | No hero glow, no focus ring |
| Accessibility | Accessible informative name `Mixed routing active`; noninteractive semantics; not in Tab order | No new command |

---

## 3. Canonical Mixed Routing pigments — mandatory correction

The following three literals **supersede the erroneous Mixed-border/color printing on the final image**. They are the **only** Board 07 Mixed pigments. Their scope is **EQ-LOCAL — PROPOSED**, solely for the Inspector's contextual badge. They do **not** replace `rgs.processed.purple` or define per-band color identities.

| Token name | Role | Design `#RRGGBBAA` | Qt/QML `#AARRGGBB` | Alpha decimal | Classification |
|---|---|---|---|---:|---|
| `eq.mixed.background` | Badge translucent violet background | **`#6C4EA633`** | **`#336C4EA6`** | `0x33/255 = 20.000%` | EQ-LOCAL — PROPOSED |
| `eq.mixed.border` | Refined lavender/violet 1-lp inside border | **`#A989F2B3`** | **`#B3A989F2`** | `0xB3/255 ≈ 70.196%` | EQ-LOCAL — PROPOSED |
| `eq.mixed.text` | High-legibility pale lavender lettering | **`#E9DCFFEE`** | **`#EEE9DCFF`** | `0xEE/255 ≈ 93.333%` | EQ-LOCAL — PROPOSED |

**Byte-level check:** conversion maps design bytes `(RR, GG, BB, AA)` to QML bytes `(AA, RR, GG, BB)`: `6C 4E A6 33 → 33 6C 4E A6`; `A9 89 F2 B3 → B3 A9 89 F2`; `E9 DC FF EE → EE E9 DC FF`. **Do not paste design-format eight-digit colors directly into QML.**

**Composition:** draw the background over the inherited Control Surface with standard `Source-over` alpha, draw the `1-lp` border **inside** the `164 × 28-lp` bounds, then draw the text using the specified foreground alpha. No extra ambient purple light, processed-state implication, animation, shadow, or background panel is authorized. Inherited `rgs.processed.purple = #8B42C0FF` remains the separate global **PROCESSED** semantic role.

---

## 4. Preview Status — four and only four real states

Preview Status is an **informational badge** in the **48-lp Header**, immediately left of the A/B pair. Its state comes only from the existing ViewModel; it is **not** an application-health summary and is **independent of A/B selection**. Reuse Board 05 component size, typography, surfaces, and Header-width reservation; Board 07 introduces no new preview geometry or color.

| Existing ViewModel status | Visible label | Inherited visual treatment | Tooltip / accessible meaning |
|---|---|---|---|
| `NO_PREPARED_REALIZATION` | **NO PREVIEW** | Neutral `eq.control.gradBottom` child-fill reference, neutral `eq.control.border`, `rgs.neutral.300` text; no success/error color | No usable PREPARED realization is available; EQ preview is unavailable. |
| `RENDERING` | **RENDERING** | Neutral child surface and text; optional existing small vector activity indicator **without** percent or elapsed-time claim | EQ preview is being rendered. |
| `READY` | **READY** | `rgs.success.green` on text and edge; inherited clipped `eq.overlay.success` over neutral child surface; **no broad glow** | EQ preview is ready. |
| `ERROR` | **ERROR** | `rgs.error.coral` text and edge; inherited clipped `eq.overlay.error`; **no invented diagnosis in Header** | EQ preview failed; `previewError`, when available, is shown in the bottom Status / Validation Strip. |

**Inherited local badge geometry (Board 05):** badge height `28 lp`, horizontal content padding `12 lp`, corner radius `6 lp`, border `1 lp`; label Segoe UI **11 lp / weight 600 / line-height 16 lp** (`eq.type.previewStatus`). Header fit is based on the **largest actually rendered** label across all four localized statuses and the existing optional activity glyph. Do not assume which label is widest without Qt font metrics. Preserve the compact Header title (`Parametric EQ` / `Manual Mastering`) and the existing A/B pair at `852 lp` minimum inner width.

**Initial C++ sentinel (integration clarification):** the current `EqViewModel` initializes `previewStatus_` to `IDLE` before a preview request or publication. `IDLE` is an existing initialization value, **not** a fifth approved user-visible preview mode. If it is observable by QML, the EQ-local presentation must map it to the existing neutral **NO PREVIEW** treatment until one of the four public preview states is available. Do not render a fifth `IDLE` badge or introduce a new backend enum/property. The current PR#8 QML directly prints the raw status; this is an explicit bounded visual-integration correction to verify in the Windows runtime gate.

**No extra user-visible statuses:** in particular, no `ANALYZING`, invented percent/progress bar, FFT activity, global success, or fake readiness. The preview badge is not repeated in the external Status Strip.

---

## 5. A/B — EQ-module state and preview independence

| Property | A | B |
|---|---|---|
| Meaning | **EQ Active** | **EQ Module Bypass** |
| Existing action | `viewModel.setBypass(false)` | `viewModel.setBypass(true)` |
| Selection | Mutually exclusive: A selected **or** B selected, never both | Mutually exclusive: B selected **or** A selected, never both |
| Selected semantic accent | Inherited interaction cyan `rgs.raw.cyan` | Inherited `rgs.gold.amber` **as contextual bypass accent only** |
| Nonselected visual | Existing neutral A/B treatment | Existing neutral A/B treatment |
| Parameter set | The current EQ parameter set | **The same** current EQ parameter set |
| Editor behavior | Normal parameter-edit permissions | Bypass does **not** automatically make parameters non-editable |

The Board 05 A/B **visual states, 32-lp child geometry, typography, selected edge, focus ring, and no-broad-glow rules** remain authoritative. B does **not** mean GOLD audition, generic processed-versus-unprocessed signal switching, Level Match, a second preset, or a second parameter snapshot.

**Required independence specimens:**

1. **Preview READY + A EQ Active selected + B inactive:** READY remains green; A uses its selected cyan treatment; B uses neutral treatment.
2. **Preview READY + B EQ Module Bypass selected + A inactive:** READY remains green; B uses its selected contextual amber treatment; A uses neutral treatment. Applicable fields remain editable under existing M12B permissions.

**Bypass-triggered preview refresh (integration clarification):** the current `EqViewModel::setBypass` updates bypass, increments `previewGeneration` and calls `request_preview()`. Consequently, switching A/B **may correctly transition** an existing READY preview to `RENDERING` and then `READY` or a genuine `ERROR`; if no PREPARED realization is available, the existing `NO_PREPARED_REALIZATION` state may result. “Preview independence” means the status badge truthfully reflects the real preview subsystem rather than the A/B button style; it does **not** mean READY must remain unchanged immediately after a bypass switch. No fifth public status or fabricated ERROR is permitted.

---

## 6. Invalid Numeric Draft — C++-owned validation

Validation authority and published DSP values stay in the existing **C++ / ViewModel**. Board 07 defines **presentation of existing outputs only**. The relevant existing properties are `validationField` and `validationMessage`; neither `validationInfo` nor a new GUI-side validation state is authorized.

When direct numeric entry contains invalid raw text:

- Preserve the **raw text visibly** in the field; use Board 03 **INVALID DRAFT** treatment (`rgs.error.coral` value/border and clipped `eq.overlay.error`). This can coexist with retained editing focus; the error cue has immediate visual priority.
- Display the actual ViewModel error message, associated with the field designated by `validationField`.
- The invalid draft **does not** publish a new committed DSP parameter and **does not** request a new render preview for the invalid value.
- **Enter** commits a valid input. **Valid focus-out** commits a valid input. **Escape** restores the previously confirmed value.
- No Apply/Cancel buttons, silent clamping, automatic correction, novel QML validators, or fake DSP error logic.

### 6.1 Exact canonical validation specimen

| Item | Value |
|---|---|
| Sample rate `Fs` | `44100 Hz` |
| Formula from existing parameter authority | `maximumFrequency = min(20000 Hz, 0.45 × Fs)` |
| Derived maximum | `min(20000, 0.45 × 44100) = 19845 Hz` |
| User's invalid raw text, kept visible | **`99999`** |
| Actual `validationField` | **`frequency`** |
| Actual `validationMessage` | **`Frequency must be between 20 Hz and 19845 Hz.`** |
| Border/text treatment | Board 03's **Error Coral**, not a new warning category |
| DSP/preview effect | **No invalid commit, no new preview request** |

The exact message above must be used beside the invalid Frequency field **and** in the Status / Validation Strip when that same ViewModel validation message is active. `19845 Hz` is sample-rate-specific, **not** a universal fixed upper bound.

---

## 7. Status / Validation Strip — existing runtime precedence

**Position:** separate, external to Inspector. **Height:** exactly `24 lp`. **Minimum width:** the `852-lp` editor inner-content width. Its structural material and sizing remain governed by Boards 01–02. It is **not** a second Preview Status badge, notification queue, debug/status telemetry surface, or Mixed Routing container.

| Actual condition | Strip content | Visual treatment |
|---|---|---|
| **A. NEUTRAL / EMPTY**: no eligible error text | **Literally empty** | Existing strip material only. **No dot, info icon, global READY, debug label, brand, or invented confirmation.** |
| **B. PARAMETER VALIDATION ERROR**: `validationMessage` is nonempty | Show the **actual `validationMessage`**; field association uses the real `validationField` | Error Coral and existing local error treatment; for §6.1 use the exact string `Frequency must be between 20 Hz and 19845 Hz.` |
| **C. PREVIEW ERROR**: `previewStatus == ERROR` and `validationMessage` is empty | Show the **actual `previewError` from ViewModel**, when supplied | Error Coral and existing local error treatment. `previewError from ViewModel` is a documentation placeholder **only**, never literal runtime diagnosis. |

**Deterministic priority:**

1. If `validationMessage` is **nonempty**, display it, even if preview is also ERROR.
2. Otherwise, if `previewStatus == ERROR` and an actual `previewError` message is available, display that actual message.
3. Otherwise, leave the strip empty. Do **not** fabricate text to occupy it.

**Single-line overflow policy:** keep the strip at `24 lp` with **no height growth** and no second row. Reserve the available space for the existing content, render overlong text on one line with a readable ellipsis, and expose its **complete actual message** via tooltip and accessible text. Truncation is purely visual and must not rewrite the stored message. Ellipsis, accessibility information, and focus treatment must remain visible/readable at minimum size. Any existing nontext error pictogram shown in the approved Board 07 specimen is permitted only in actual error rows, never in the neutral row and never at the cost of message legibility.

No extra warning, diagnostic classifier, status ticker, fake success text, animated queue, second status line, or invented `validationInfo` property.

---

## 8. Authorized combinations of existing EQ-editor states

“Global States” means **visual combinations of the real, independently sourced editor states**, not a new application-wide state machine. Each row below is an example, **not** a new ViewModel enum:

| Existing combination | Header | Inspector | Numeric field / Strip | Non-negotiable distinction |
|---|---|---|---|---|
| Preview **READY** + **A EQ Active** | READY badge + A selected cyan / B neutral | Current controls remain normal | Empty strip if no error | Preview readiness is independent of A |
| Preview **READY** + **B EQ Module Bypass** **after successful bypass preview** | READY badge + A neutral / B selected amber | Applicable EQ controls remain editable | Empty strip if no error | B is EQ-module bypass, not GOLD; an intervening truthful RENDERING state is permitted |
| **Mixed Routing** + **A EQ Active** | A selected; preview remains whatever its actual state is | **One** `MIXED ROUTING ACTIVE` badge when `mixedRouting` is true | No badge in Strip | Mixed is derived from enabled-band routing |
| **Mixed Routing** + **B EQ Module Bypass** | B selected; preview remains independent | **One** Mixed badge if existing condition is true | No badge in Strip | Bypass does not erase or redefine routing |
| **Invalid Numeric Draft** | Preserve actual preview and A/B states | Selected band's field contains visible invalid raw text | Actual `validationMessage` with precedence | No invalid DSP commit or new preview request |
| Preview **ERROR** with message | ERROR badge, A/B independent | No invented Inspector error control | Actual `previewError` when no higher-priority validation message | No generic guessed failure diagnosis |

There is no special “mixed-preview” backend state, composite-response mode, standalone Warning mode, or synthetic status for any combined row.

---

## 9. Control-state reference — reuse earlier authorities

Board 07 **documents**, but does not reimplement or redefine, the approved controls:

| Control family | Authorized visual states | Additional restriction |
|---|---|---|
| Segmented buttons — Filter, Routing, HP/LP Slope | **NORMAL; HOVER; PRESSED; SELECTED; KEYBOARD FOCUS; DISABLED** only where functionally justified | Selection and focus distinguishable, no changing size or label; no invalid free-text state |
| Band Enabled toggle | **OFF; ON; HOVER; PRESSED; KEYBOARD FOCUS** | Actual OFF/ON semantics preserved; Band Enabled OFF does **not** disable the Inspector or prevent band selection; no invalid free-text state |
| Direct numeric fields | **NORMAL; HOVER; FOCUS / EDITING; INVALID DRAFT** | Board 03 owns numeric anatomy and invalid visuals; a DISABLED field may be shown only as an **abstract specimen**, not as the default way to display an inapplicable parameter |
| Band selectors / Add / Remove | Inherit Board 05's exact family-specific states | Add and Remove remain momentary, with no persistent SELECTED; a band can be processing-disabled but selectable |
| Mixed Routing badge | **Visible normal / hidden**, determined by existing `mixedRouting` | **No Hover, Pressed, Selected, Keyboard Focus or interactive disabled state** |

Use inherited Board 05 **2-lp outer cyan keyboard-focus ring / 2-lp visual offset** where that common-button treatment is specified; inherit Board 03's direct-entry focus treatment for numeric fields. Keyboard Focus must be visible **immediately** and independently of Hover or Selected. Do not propagate numeric INVALID DRAFT to a toggle, segmented control, preview badge, or status badge.

---

## 10. Inherited material/color/type crosswalk — no global token changes

This crosswalk references existing approved values. **No values in this section are newly coined by Board 07.** Structural material definitions, gradients, highlights, and shadows remain in Board 02 v1.1; numerical inputs and fonts remain Board 03 v1.0; child controls remain Boards 05–06.

| Inherited reference | Design `#RRGGBBAA` | Qt/QML `#AARRGGBB` | Authorized Board 07 use |
|---|---|---|---|
| `rgs.neutral.100` | `#F5F8FCFF` | `#FFF5F8FC` | Primary control text |
| `rgs.neutral.300` | `#A1B5C9FF` | `#FFA1B5C9` | Secondary/neutral preview text |
| `rgs.neutral.500` | `#62788FFF` | `#FF62788F` | Muted informational text where inherited |
| `rgs.raw.cyan` | `#00C8FFFF` | `#FF00C8FF` | Authorized interaction/focus and A selected accent |
| `rgs.success.green` | `#00D47AFF` | `#FF00D47A` | Actual preview READY |
| `rgs.warning.yellow` | `#FFC107FF` | `#FFFFC107` | Abstract Warning design-system specimen **only**, not active in M12B |
| `rgs.error.coral` | `#F27683FF` | `#FFF27683` | Actual invalid draft, preview ERROR, Status Strip errors |
| `rgs.processed.purple` | `#8B42C0FF` | `#FF8B42C0` | Existing PROCESSED semantic reference, **not** Mixed badge pigment |
| `rgs.gold.amber` | `#F2B632FF` | `#FFF2B632` | B selected contextual bypass accent, **not** global GOLD audition choice |
| `eq.control.gradBottom` | `#0E1F2EFF` | `#FF0E1F2E` | Neutral child color reference; structural parent material stays Board 02's complete Control Surface |
| `eq.control.border` | `#2C5A78FF` | `#FF2C5A78` | Inherited neutral control/preview border reference |
| `eq.overlay.focus` | `#00C8FF14` | `#1400C8FF` | Inherited local clipped focus wash, when applicable |
| `eq.overlay.success` | `#00D47A14` | `#1400D47A` | Actual preview READY clipped wash |
| `eq.overlay.error` | `#F2768314` | `#14F27683` | Actual invalid and preview ERROR clipped wash |
| `eq.overlay.warning` | `#FFC10714` | `#14FFC107` | Abstract-only warning specimen when explicitly labeled inactive |

**Text roles:** Segoe UI for UI text; Consolas for numeric readouts with Board 03's Windows fallbacks. Header title `20 lp/600/24-lp line` and subtitle `12 lp/400/16-lp line` remain unchanged. Badge Mixed uses the Board 07 local `12 lp/600` label; Preview Status retains Board 05 / Board 03 `11 lp/600/16-lp line` and A/B retains its inherited type. No Inter requirement or new font distribution.

**Color serialization rule:** design literals are `#RRGGBBAA`, QML literals are `#AARRGGBB`. For new EQ-local colors refer **only** to §3's verified three Mixed tokens. Source-over compositing only, no additive/neon light treatment.

---

## 11. Motion scope, limits, and ownership

Motion is a **visual feedback proposal**, not new functional timing. Existing ViewModel state changes, commits, validation feedback and accessibility updates occur when their underlying events occur, independently of any decorative animation. The EQ Editor may locally adopt the proposed motion tokens below only after integration acceptance; they do **not** alter Board 01 geometry, Board 02 surface material, Board 03 input semantics, the existing C++/DSP chain, or globally shared `StudioButton` animations.

**No geometry shift:** never animate QML `implicitWidth`, `implicitHeight`, `Layout.preferredWidth`, margins, control positions, or neighboring sibling positions as part of these microtransitions. For `Pressed`, any optical depth/scale cue remains confined to the existing allocated bounds and focus-hit area. No expensive blur, shader, perpetual bloom, or synthetic numeric interpolation.

---

## 12. Proposed EQ-local motion tokens — deterministic table

These are **EQ-LOCAL — PROPOSED**, not globally frozen timing or a guarantee of current runtime implementation. `OutCubic` below means Qt's ordinary cubic-out easing; `Linear` has its ordinary meaning. Durations are wall-clock **milliseconds** for **decorative interpolation only**.

| Token | Event / control | Duration | Animated decorative property | Easing | Maximum effect and hard boundary | Reduced Motion |
|---|---|---:|---|---|---|---|
| `eq.motion.hover` | Pointer Hover on an eligible control | **80 ms** | Existing child surface/border opacity and *existing* subtle overlay | **OutCubic** | Incremental opacity change **≤ 0.08**. Final color and overlay are those inherited from Boards 03/05/06; no new hue, halo or dimension change. | **0 ms**; immediate stable state. |
| `eq.motion.pressed` | Press on an eligible momentary/segmented control | **60 ms** | Existing Pressed fill/border and at most a contained optical depth cue | **OutCubic** | Optical scale **≥ 0.98** and **≤ 1.00** if used, inside fixed hit box; no actual geometry/layout shift; Pressed must remain clearly unlike Disabled. | **0 ms**; immediate Pressed contrast. |
| `eq.motion.keyboardFocus` | Keyboard focus gained | **0 ms** for required focus visibility | **Required focus edge/ring appears immediately**; no mandatory animated property | **Instant** | Full approved focus treatment visible on focus event; optional later glow decoration may use only the *pre-existing local glow range*, must not defer focus or expand the geometry. | **Always instant**; no decorative focus animation required. |
| `eq.motion.selected` | Selection within an existing segmented/button group | **120 ms** | Existing selection surface/border/decorative edge interpolation **after** selection becomes semantically visible | **OutCubic** | Any extra opacity interpolation **≤ 0.12**; approved final selected border/geometry from relevant earlier board; selection is readable immediately without waiting. | **0 ms**; final selected visual instant. |
| `eq.motion.toggle` | Existing Band Enabled toggle changes OFF/ON | **100 ms** | Thumb translation **within already approved travel** and existing track fill | **OutCubic** | **No overshoot**, no extra movement beyond the approved endpoints; OFF/ON meaning available immediately from state/accessibility. | **0 ms**; snap thumb to actual state. |
| `eq.motion.statusTransition` | Existing preview badge / Status Strip status changes | **150 ms** | Optional nonessential surface opacity/crossfade **after immediate content/state update** | **OutCubic** | Decorative opacity can reach the final inherited surface, but **actual label/error text and error edge appear immediately**; no strip height change or hidden alert. | **0 ms**; immediate complete destination state. |

**Motion-token interpretation:** every final color, border thickness, focus ring, selected state, and control shape still comes from its corresponding earlier board. The maxima above constrain transient *changes*, not permission to redefine the final state. There is no new “motion state” in the ViewModel. Avoid transitions on noninteractive Mixed Routing beyond immediate show/hide. An optional RENDERING activity glyph must not convey progress, completion time, or a new backend phase; Reduced Motion may present its static recognizable glyph plus `RENDERING` text.

---

## 13. Functional safety guarantees for animation

1. **Keyboard Focus:** the ring/edge from the relevant inherited control appears **on the focus event**, at `0 ms`. A later subtle glow is optional and purely decorative; it cannot be the first visible focus indication.
2. **INVALID DRAFT:** invalid raw text, Error Coral text/border, and the ViewModel message become recognizable **immediately**. No deferred fade-in of a required error.
3. **Status / Validation:** the actual message appears immediately according to §7 precedence. `150 ms` can animate only its nonessential surface treatment; it cannot delay, truncate unexpectedly, or obscure error text.
4. **Graph dragging:** the existing selected-band handle/draft visual follows pointer input directly; no 80/120/150-ms easing is imposed on the drag position, plotted response, or geometry. On release, commit follows the existing ViewModel contract. Do not trigger a new Render Preview for each pointer movement.
5. **Numeric readouts:** no artificial interpolation, count-up, replacement formatting during draft, delayed validation, speculative clamp, or QML-side range reconciliation.
6. **RENDERING:** do not animate an invented percentage, progress bar, ETA, spectrum trace, or perpetual bloom.
7. **Reduced Motion:** if supported Windows/accessibility preferences are available, reduce or eliminate decorative motion without hiding any field, focus outline, selected treatment, error or toggle meaning.
8. **No reflow:** motion must not change any Board 01/05/06 allocated dimensions and must not create clipping or overlay other control labels at the minimum window size.

---

## 14. Reduced Motion — platform-compatible acceptance behavior

Respect the user's Windows reduced-motion preference **where the supported application/platform integration exposes it**. Do not invent an application preference or backend flag as part of this visual board.

- Set decorative interpolation durations to **0 ms** or remove the animation entirely; render the destination state immediately.
- Show keyboard focus immediately regardless of motion preference.
- Show actual validation/error text and Error Coral immediately; never conceal alerts behind a fade.
- Preserve selected and processing-off cues by text/border/geometry as well as color, and preserve the approved toggle endpoint positions.
- Preserve a truthful, accessible `RENDERING` label even with any rotating activity glyph stopped.
- Do not rely on movement alone to convey function, routing, selection, or confirmation.

The Windows integration mechanism for detecting any supported preference belongs to the later implementation/reconciliation task. No new ViewModel property is authorized by this manifesto.

---

## 15. Warning — abstract design-system specimen, not an M12B runtime state

The current M12B does **not** expose an independent automatic EQ-parameter Warning backend. A yellow Warning example may appear **only** when explicitly labeled:

> **DESIGN SYSTEM SPECIMEN ONLY — NOT ACTIVE IN M12B**

Such an abstract specimen inherits `rgs.warning.yellow` and `eq.overlay.warning` **only for library illustration**. It may not introduce “recommended range” thresholds, a new EQ Warning enum, an extra Status Strip category, or automatic advisory text. Similarly, a generic Success notification is not authorized by preview `READY`.

---

## 16. Implementation feasibility — Qt 6 / QML

All visible changes can be implemented with Qt Quick's existing scalable primitives (`Rectangle`, `Text`, border, simple clipped `Gradient`/overlays, `Shape` for an optional small activity glyph, and the already approved child controls), with normal source-over blending. **No custom shader, expensive continuous blur, raster control bitmap, duplicated C++ validation, or newly materialized DSP/backend behavior is required.**

- Mixed badge: one conditional, noninteractive `164 × 28-lp` item inside the actual Routing subrow, with §3's exact colors, 1-lp inside border, 8-lp corner radius; hidden when the existing derived ViewModel flag is false.
- Preview: bind to the existing four states from the existing ViewModel, retaining the Board 05 badge implementation and separate A/B state.
- Status Strip: render existing actual ViewModel strings according to §7 priority. Keep one line, 24-lp height, safe clipping/ellipsis, tooltip and accessible full text.
- Motion: animate only the permitted visual properties of the existing QML children; instant changes for required focus/error labels. Preserve earlier control families instead of replacing shared controls for aesthetic convenience.
- Inherited material surfaces and numeric-entry styles remain owned by Boards 02–03; focus/selected child treatments are inherited from Boards 05–06.

This document is a **visual implementation target**, not a claim that the current Windows executable already implements it or that the earlier integrated v1.1 manifests are silently superseded.

---

## 17. Mandatory Windows integration verification gate

**Test both real window sizes:** `1040 × 660 lp` and `900 × 580 lp`, with Windows 10 as the visual acceptance baseline. The following conditions are mandatory **before** accepting a Qt/QML materialization:

| Gate | Observable acceptance requirement |
|---|---|
| Mixed single-badge logic | Two or more distinct Routing modes **among enabled bands** → exactly one Inspector badge. Same Routing among enabled bands → badge absent. Never one badge per band. |
| Mixed dimensions/fit | Badge `164 × 28 lp`; inherited Routing row `808 / 820 lp`, nominal `12-lp` remainder; actual Qt text, `implicitWidth`, border and spacing fit with **no clipping or overlap**. |
| Exact pigments | Compare `#6C4EA633 → #336C4EA6`, `#A989F2B3 → #B3A989F2`, and `#E9DCFFEE → #EEE9DCFF` byte for byte. No substituted PROCESSED color. |
| Preview states / startup sentinel | Exercise all **four public** backend values and their authorized visible labels, surfaces, tooltips/accessibility; badge remains immediately left of A/B. Also exercise the existing initial `IDLE` sentinel and verify it is presented as neutral **NO PREVIEW**, never as a fifth UI label. |
| Preview / A/B independence | READY + A and READY + B **after successful preview publication**; verify `setBypass` may legitimately request a new preview (including RENDERING and later READY/ERROR/NO PREVIEW), that A/B remain mutually exclusive, and bypass does not automatically disable applicable editing. |
| Validation fidelity | At `Fs = 44100`, invalid `99999` remains visibly uncommitted; `validationField = frequency`; exact `Frequency must be between 20 Hz and 19845 Hz.` appears beside field and in strip when it is the active `validationMessage`. |
| Error priority | Simultaneous validation and preview error → `validationMessage` first; otherwise actual `previewError` only when `previewStatus == ERROR` and text exists. No invented diagnosis. |
| Neutral strip | At no eligible message, strip is **literally empty** (no dot, icon, confirmation, debug label, or branding). Always **24 lp** tall. |
| Long-message accessibility | One-line truncation/ellipsis without height growth; tooltip and accessibility contain the complete actual message. |
| Existing state families | Filter/Routing/HP-LP, toggle and numeric states remain faithful to Boards 03/05/06; no free-text invalid state on segmented/toggle controls. |
| Keyboard focus | Focus visible immediately (`0 ms` required ring/edge), distinguishable from Hover and Selected, **not clipped** by compact groups. |
| Motion | Targets `80/60/0/120/100/150 ms`; no drag lag, numeric interpolation, delayed error, status-text delay, layout shift, synthetic progress, heavy continuous blur or shaders. |
| Reduced Motion | Where supported, decorative motion is eliminated/reduced without removing focus, state meaning, validation text or accessibility. |
| Geometry and scope | No clipping, control overlap or horizontal scrolling at either size; no changes to Board 01 macro geometry or shared `StudioButton` outside approved EQ-local scope. |

**Stop / escalation:** the `12-lp` Mixed Routing row reserve is a *design budget*, not certified runtime clearance. If real `implicitWidth`, localization/font metrics, focus outsets or other Qt layout behavior cause overlap or clipping, **stop**, identify the exact measured conflict and request a **narrow Product Owner-approved EQ-local delta**. Do not silently widen the Inspector, alter inherited typography, reduce the badge text, add horizontal scrolling, or redefine the shared button system.

---

## 18. Explicit exclusions and review status

This manifest authorizes **no** new backend or DSP state, no user-editable Mixed Routing mode, no per-band Mixed badge, no fake combined response, no Analyzer or spectrum, no global GOLD choice, no new warning/notification subsystem, no fake preview progress, no second Status Strip, no Apply/Cancel, no QML-side DSP validation, no redesign of Boards 01–06, and no Board 08 integrated composition or QML implementation handoff.

**Integration reconciliation and scope decision (v1.1):** independent review cross-checked Board 01–06 accepted scoped manifests and GitHub Draft PR#8 HEAD `5676505f586738d29349b3a2f4907ba011575141` on 23 September 2026. The three Mixed pigments in §3 are verified byte-exact and accepted **within the Board 07 M12B design scope**; §12 motion is an accepted EQ-local *target*, **not yet runtime-accepted**. Two source-truth clarifications were added: an existing initial `IDLE` C++ sentinel must map to the neutral public NO PREVIEW presentation if observed (no fifth public UI state); and `setBypass()` legitimately triggers a preview refresh, so the READY+A and READY+B specimens are stable post-render combinations, not a promise of unchanging READY immediately upon toggling. No change to preceding Boards 01–06, macro geometry, underlying DSP, or shared component behavior is authorized. Real Windows 1040×660 and 900×580 Qt/QML measured fit, preview startup/refresh, error priority, focus, motion and reduced-motion gates remain mandatory. **The overall L1-M12B Visual WOW Design Package remains unfrozen pending Board 08 and its integrated independent review.**
