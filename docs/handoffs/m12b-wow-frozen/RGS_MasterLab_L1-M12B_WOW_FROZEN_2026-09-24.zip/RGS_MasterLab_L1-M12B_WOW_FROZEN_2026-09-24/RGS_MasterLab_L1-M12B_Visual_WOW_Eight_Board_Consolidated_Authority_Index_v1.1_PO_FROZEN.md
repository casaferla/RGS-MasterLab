# RGS MasterLab — L1-M12B Visual WOW: Eight-Board Consolidated Authority Index v1.1 — PRODUCT OWNER FROZEN

**Date:** 2026-09-24 (PO Freeze)  
**State:** Eight of eight scoped design boards independently reviewed and accepted. Complete design package **TECHNICAL CROSS-BOARD PASS + EXPLICIT PRODUCT OWNER FREEZE — PO-FROZEN VISUAL TARGET**. Bounded Jules WOW implementation is authorized for the same Draft PR #8 after manifest-folder handoff. No successful rendering of new WOW UI in Qt has yet been verified.  
**Canonical product:** RGS MasterLab — Reference Guided Sound — Gold Reference Mastering Environment. Windows 10/11 x64 primary; Android parallel/future platform integration, Apple excluded. This L1-M12B editor design is Windows-specific.

## 1. Exact board ownership, definitive manifests

| Board | Normative scope | Definitive version | Google Drive file ID |
|---|---|---|---|
| 01 | Macro geometry / tool window | v1.0 | `1fvmY4lwh3XurzDy2Jcxnx73EniJ3-tY8Jeo68Vw-Beg` |
| 02 | Studio Slate materials, shared tokens / exact QML-safe colors | v1.1 QML-Safe | `1VrGCJgVRx_vPdlFvqCxwUck08YeDW69A` |
| 03 | Segoe UI/Consolas; numeric field anatomy and states | v1.0 | `19ilTo0KuiYguN7cGBN-T83NPM7yfHcWQ` |
| 04 | Graph/handles/selected response; genuine rendering data | v1.1 Integration Reconciled | `1qJW-hRyw4M67EpZ49zKryDcuB9W_g0zx` |
| 05 | Band strip, preview badge, A/B; responsive action buttons | v1.1 Integration Reconciled | `13N8VgTWLawJm2aadAI7KBKc-OTIQLNDA` |
| 06 | Two-tier Inspector, six filters, five routing, conditional parameter sets | v1.1 Integration Reconciled | `1HbNBx1SKCVHdq-gQDiDmC6yp7LdUYOya` |
| 07 | Mixed Routing, validation/status, global visual combinations and motion | v1.1 Integration Reconciled | `1IBiXJFUvNxGV17UyaquAlCkF0Zda2Pdo` |
| 08 | Integrated editor composition; default/minimum, final corrective rules | **v1.1 Integration Reconciled** | **`1G0sfoqw-wkhfWqf8w7tRmSU6cZwp5oCb`** |

Original Board08 user-provided v1.0 preserved as provenance only: Drive ID `15WHT6BoLn5SFmP5hS8jZhJ7ijZF0Q8Lv`; original SHA-256 `6a550f71637077334fcf4e28740b9bc60d8d9673d293929e9232c3ea3ef00aa5`. Board08 v1.1 SHA-256 `18ecb34a08b0eaae3fe70f7045fcffbe40494329a03fef457c66b6b0b226aed0`.

Final Board08 art *accepted solely as composition reference with errata*: Drive JPEG ID `1FiL83KLdic9UJ-D3jzXwJi8SdRcjplak`. The small minimum illustration is NOT runtime-proof and visually omits LEFT; repeated image-note errors about Remove Band and Mixed Routing are **superseded** by definitive Board08 text. The visuals are not sources of runtime values or DSP curves.

## 2. Hierarchy and conflict resolution

1. Later explicit PO Frozen decisions and accepted forward deltas govern any actual scope conflicts. Each numbered board's latest accepted canonical manifest owns its component. Board08 **composes** but does not overwrite Boards01–07.
2. Static pictures show visual direction, not authoritative text/measurements, Qt-runtime evidence or C++ DSP samples. For source-coupled states, actual **existing** C++ and any accepted functional contract outrank speculative art.
3. No new DSP, combined curve, full-spectrum analyzer, Level Match, presets or global RGS redesign are authorized by this pack.
4. Classification is explicit: **SHARED RGS — INHERITED** material/type references; **MASTERING MODULE FAMILY — PROPOSED** reusable graph/controls styling only after cross-milestone review; **EQ-LOCAL — PROPOSED** geometry, Mixed badge pigments and interaction tokens specific to this editor. Subsequent Compressor/Stereo/Reference Match milestones can reuse the design system only with scoped adoption, not silent promotion of the EQ editor's exact composition.
5. Persistent conflicts discovered during future coding require a documented bounded, PO-approved delta, not silent dimensions/behavior substitutions.

## 3. Independent numerical/semantic review findings

- **Macro:** 1040×660 default → inner992×612; 900×580 minimum → inner852×532; effective inset24 per edge. Five sections Header48/BandStrip40/Graph324→244/Inspector128/Status24 and four inter-section gaps12. Both vertical sums correct.
- **BandStrip six bands:** `6×90+5×8=580`; plus `12+24+128+12+128+20=324` gives904/992, reserve88 at default; compact actions96 each gives840/852, reserve12 at minimum. Compact breakpoint at inner width852–915; full at≥916, only if true Qt measured metrics fit.
- **Graph:** one selected-band C++ `selectedBandResponsePoints`, independent other handles. At Fs48k fMax20k; at Fs44.1k fMax19845; Bell specimen Band1 1kHz +3dB Q.707. Default plot928×292 and min788×212 use common plot projection. Axis ±18/12/6/0. Painting clipped to plot only; interaction/handle overlay must remain visible at extrema.
- **Inspector:** `6+28+4+28+4+50+8=128`; inner852 minus16×2=usable820. Filter `160+8+56+8+(6×96+5×1)=813`, reserve7. Routing `160+8+56+8+(5×80+4×1)+8+164=808`, reserve12. All six Filter/five Routing incl LEFT at both sizes; single contextual Mixed badge when enabled committed bands have different routing. Mono Stereo-only. Bell Frequency+Gain+Q; Notch Freq+Q; shelves Freq+Gain+unitless ShelfSlope; HP/LP Freq+six discrete6/12/18/24/36/48 slope buttons. HP/LP lower listed subtotal729/820 excludes Hz/gap/focus; reserve91 for omitted measured children.
- **Validation/status:** numeric fields height50 (label16+gap6+box28), unit suffix placed to the **RIGHT** of box with text left-aligned after8lp gap. Enter valid commit, valid focus-out commit, Escape cancel; invalid raw retained no DSP/preview publication. True neutral bottom Status24 completely blank; validationMessage precedes previewError for actual ERROR.
- **Preview:** four public labels NO PREVIEW, RENDERING, READY, ERROR; C++ internal initial IDLE maps to NO PREVIEW. A EQ Active / B real EQ-module bypass mutually exclusive; changing A/B may initiate preview regeneration, so READY need not persist during transition.
- **Colors:** Mixed badge EQ-local background Design `#6C4EA633`/QML `#336C4EA6`, border `#A989F2B3`/`#B3A989F2`, text `#E9DCFFEE`/`#EEE9DCFF` (not the corrupt values printed in the art). Inherit other Board02/04 materials verbatim. Never paste Design `#RRGGBBAA` values into QML as though already ARGB.
- **Motion:** Board07 EQ-local visual targets Hover80ms, Pressed60, Required Keyboard Focus0ms, Selected120ms, Toggle100ms, decorative Status150ms; semantic focus/error/commit immediate, Reduced Motion where supported.

## 4. Current source baseline vs accepted future design

**GitHub** `casaferla/RGS-MasterLab` PR #8, `L1-M12B: Parametric EQ Visible Editor and Windows Gate Preparation`, Draft/open/unmerged at independently observed HEAD `5676505f586738d29349b3a2f4907ba011575141` on 2026-09-23; base `8f1b8d5f6ce2c2ba08b3c82eae6b3010cd50998b`. This does **not** imply WOW code exists or full qualified binaries have passed. The pre-WOW QML still has `StudioButton.implicitHeight=32`, root-clipped graph handles, obsolete BANDS label and raw previewStatus string. These become later bounded implementation targets; do not claim they are corrected already or change shared `StudioButton` globally.

## 5. Mandatory subsequent gates — do not skip

1. **COMPLETED 2026-09-24:** Product Owner explicitly froze all eight reviewed manifest scopes in this conversation (“Va bene. Procedi.”) after the independent cross-board PASS; PO Freeze Decision v1.0 is part of the release handoff package. This does not accept Windows visual/runtime behavior.
2. Prepare a **bounded self-contained agent-neutral implementation handoff** for Jules on the **same Draft PR #8**, same existing baseline, explicit allow-list/protected files/test commands and evidence requirements. Jules is implementer, not author of new UI architecture, geometry, DSP or token decisions.
3. Implement EQ-local QML visual target, with measurements and **real Windows screenshots at1040×660 and900×580** across 1 and6 bands, all filter/routing variants, mixed, mono, A/B, preview/error, focus, disabled and narrow widths. Runtime checks must prove absence of clipping/overlap/horizontal scrolling and exact token/color fidelity; if the nominal7/12lp reserves fail, stop and propose measured local PO layout delta.
4. Rerun both PR Focused CI runners, independent technical/source/visual review, then manual Windows Full Qualification staged Release with generated actual evidence and artifact. Execute **Product Owner Gate M** interaction/visual and **Gate L** reference listening. Explicit PO permission is required for merge. M13 is blocked until M12B accepted and merged.

**Technical cross-board disposition:** PASS for design consistency / numeric contracts, Board08 v1.1 SCOPED ACCEPTED, eight scoped manifests available. NOT a certification of runtime QML fit, Windows Full, Gold Reference listening or overall WOW product acceptance. Full Visual WOW pack **PO-FROZEN AS DESIGN TARGET ON 2026-09-24**. Subsequent Qt/Windows actual rendering, CI, staged Release, PO Gate M/L and merge remain separate pending gates.

## 6. Binding Product Owner freeze / implementation task

The Product Owner explicitly authorized freezing the eight cross-board-reviewed manifests on 2026-09-24 in immediate reply to the final package review. The authoritative signed-off scope consists ONLY of the exact eight versioned manifest Drive IDs in §1. Companion record: `RGS_MasterLab_L1-M12B_WOW_Package_PO_Freeze_Decision_2026-09-24_v1.0.md`; bounded agent-neutral work packet: `RGS_MasterLab_L1-M12B_WOW_Jules_Visual_Implementation_Handoff_2026-09-24_v1.0.md`. Historical candidate images and superseded v1.0 manifest drafts are NOT reopened by this decision. The frozen Board08 v1.1 corrects the image’s absent LEFT button and misleading labels; Board02 owns ARGB-safe values. This design freeze is reusable in future chats through the present v1.1 index and protocol checkpoint, but not an automatic cross-milestone promotion of EQ-LOCAL geometry or visuals.
