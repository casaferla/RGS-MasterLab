# RGS MasterLab — L1-M12B
# BOARD 06 — CANONICAL INSPECTOR CONTROLS MANIFEST v1.1 — INTEGRATION-RECONCILED

**Deliverable:** deterministic textual companion to the visually reviewed **Board 06 — Inspector Controls**.  
**Product:** RGS MasterLab — Reference Guided Sound — Gold Reference Mastering Environment.  
**Reference platform:** Qt 6 / QML, Windows 10, logical pixels (lp).  
**Status:** **independent design/numeric integration review PASS — SCOPED BOARD 06 ACCEPTED**, with the precise outstanding inputs and mandatory Windows runtime-fit checks below. The overall Visual WOW Package is **not frozen**; design approval is **not** evidence that current Qt runtime controls fit.

## 1. Authority, precedence and scope

This manifest applies **only** to the L1-M12B Parametric EQ Inspector. The following upstream contracts are not amended:

1. **Board 01 — Canonical Macro Geometry v1.0:** tool window `1040 × 660 lp` default, `900 × 580 lp` minimum; effective content inset `24 lp`; inter-section gap `12 lp`; Header `48 lp`, Band Strip `40 lp`, flexible Response Graph `324 lp` default / `244 lp` minimum, Inspector **`128 lp`**, external Status / Validation Strip `24 lp`. Available inner width `992 lp` default / **`852 lp`** minimum.
2. **Board 02 — Canonical Material Token Manifest v1.1 QML-Safe:** structural Control Surfaces material, inherited palette, state overlays, QML hex serialization. Its Inspector material is `eq.control.*`; Board 06 may use its existing color *references* for child controls but cannot replace the parent surface material.
3. **Board 03 — Canonical Typography & Numeric Field Manifest v1.0:** Segoe UI/Consolas, text and direct-entry field anatomy, numerical validity and editing states. All 50-lp numeric component dimensions below inherit this authority.
4. **Board 04 — Canonical Graph & Handles Manifest v1.1 Integration Reconciled:** response graph, handle colors and behavior; this Board 06 does not duplicate or change them.
5. **Board 05 — Canonical Band Selector / Preview Status / A-B Manifest v1.1 Integration Reconciled:** adjacent band selection, header preview status and module bypass; Board 06 does not redefine these. Only compatible child-control visual patterns may be reused.

**Precedence:** when this Inspector specification refers to an upstream token, the referenced canonical manifest owns its value. The tables in this document **do not create replacement shared RGS tokens**. If the integrated v1.1 revisions differ from a visual specimen, the integrated textual authority prevails; do not silently revise this document or shared components.

**In scope:** Band identity, Band Enabled, Filter, Routing, contextual Mixed Routing, filter-dependent lower-tier controls, visual states and geometric acceptance targets. **Out of scope:** new DSP, new ViewModel API, graph or handle changes, preview status, A/B semantics, Band Strip, additional controls, global StudioButton changes, QML handoff.

## 2. Inspector macro geometry — authoritative design target

### 2.1 Horizontal envelope

| Token / role | Value | Classification |
|---|---:|---|
| Inspector outer width, default | `992 lp` | Board 01 — inherited |
| Inspector outer width, minimum | `852 lp` | Board 01 — inherited |
| `eq.inspector.paddingX` | `16 lp` **on each side** | EQ-LOCAL — PROPOSED |
| `eq.inspector.usableWidthMin` | `852 − 16 − 16 = 820 lp` | Derived design budget |
| `eq.inspector.bandEnabledColumnWidth` | `160 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.interColumnGap` | `8 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.controlLabelColumnWidth` | `56 lp` | EQ-LOCAL — PROPOSED; FILTER or ROUTING |
| `eq.inspector.labelToControlsGap` | `8 lp` | EQ-LOCAL — PROPOSED |

All horizontal calculations in §§3–4 use **the full 820-lp usable track**. No additional uncounted row padding, margins, separators or implicit spacer may be inserted. The Band identity / Band Enabled column occupies the **same fixed 160-lp column** for both upper subrows.

### 2.2 Exact vertical budget

| Vertical item (top → bottom) | Height |
|---|---:|
| Top internal padding | `6 lp` |
| Filter subrow | `28 lp` |
| Gap between Filter and Routing subrows | `4 lp` |
| Routing subrow | `28 lp` |
| Inter-tier gap, **including horizontal divider if drawn** | `4 lp` |
| Lower tier: complete numeric component | `50 lp` |
| Bottom internal padding | `8 lp` |
| **TOTAL** | **`6 + 28 + 4 + 28 + 4 + 50 + 8 = 128 lp`** |

- The `160-lp` Band identity / Enabled column spans both upper subrows and their intervening 4-lp gap; it does not create an additional row.
- An optional 1-lp inter-tier divider must be **painted within the existing 4-lp inter-tier gap**. It must not increase the Inspector's measured height.
- Numeric labels, 6-lp label-to-field gaps and 28-lp input boxes are **already included** in each 50-lp lower-tier numeric component.
- The **24-lp Status / Validation Strip is outside** this 128-lp Inspector. `MIXED ROUTING ACTIVE` must not appear there.
- This macro budget is a design specification, not proof that the existing component `implicitHeight` values already fit.

## 3. Filter subrow — six explicit segmented options

**Authorized filter choices (exactly six):** `BELL`, `NOTCH`, `LOW SHELF`, `HIGH SHELF`, `HIGH PASS`, `LOW PASS`. Show all six as explicit, readable segments, **not** a replacement dropdown.

| Segment of the 820-lp track | Width (lp) |
|---|---:|
| Band identity + Enabled column | `160` |
| Following gap | `8` |
| FILTER label column | `56` |
| Label-to-controls gap | `8` |
| Six filter segments | `6 × 96 = 576` |
| Five shared segment dividers | `5 × 1 = 5` |
| **Complete segmented filter group** | **`581`** |
| **TOTAL REQUIRED** | **`160 + 8 + 56 + 8 + 581 = 813`** |
| **AVAILABLE** | **`820`** |
| **REMAINING DESIGN RESERVE** | **`7`** |

| Token | Value | Classification |
|---|---:|---|
| `eq.inspector.filter.segmentWidth` | `96 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.filter.segmentHeight` | `28 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.filter.dividerWidth` | `1 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.filter.groupWidth` | **`581 lp`** | Derived target |
| `eq.inspector.filter.labelText` | `FILTER`, Segoe UI `12 lp / 600 / 16 lp` | Board 03 typography — inherited |

The 1-lp separators are **included** in 581 lp: do not also add five `Layout.spacing` gaps. Focus rendering must not change any segment's allocated width/height or erase its label. **7 lp is a design remainder**, not certified extra space for Qt implicit widths or a clipped outer focus ring.

## 4. Routing subrow — five explicit options and contextual badge

**Authorized routing choices (exactly five):** `STEREO`, `MID`, `SIDE`, `LEFT`, `RIGHT`. Do not add a sixth routing segment or a Mixed selector.

| Segment of the 820-lp track | Width (lp) |
|---|---:|
| Band identity + Enabled column | `160` |
| Following gap | `8` |
| ROUTING label column | `56` |
| Label-to-controls gap | `8` |
| Five routing segments | `5 × 80 = 400` |
| Four shared segment dividers | `4 × 1 = 4` |
| **Complete segmented routing group** | **`404`** |
| Gap to Mixed Routing badge | `8` |
| Contextual Mixed Routing badge | `164` |
| **TOTAL REQUIRED** | **`160 + 8 + 56 + 8 + 404 + 8 + 164 = 808`** |
| **AVAILABLE** | **`820`** |
| **REMAINING DESIGN RESERVE** | **`12`** |

| Token | Value | Classification |
|---|---:|---|
| `eq.inspector.routing.segmentWidth` | `80 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.routing.segmentHeight` | `28 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.routing.dividerWidth` | `1 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.routing.groupWidth` | **`404 lp`** | Derived target |
| `eq.inspector.mixedGap` | `8 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.mixedBadgeWidth` | `164 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.mixedBadgeHeight` | `28 lp` | EQ-LOCAL — PROPOSED; within Routing subrow |
| `eq.inspector.routing.labelText` | `ROUTING`, Segoe UI `12 lp / 600 / 16 lp` | Board 03 typography — inherited |

**Mono input:** `STEREO` remains available; `MID`, `SIDE`, `LEFT`, `RIGHT` are unavailable and shown using the genuinely unavailable segmented-control treatment. No other routing mode is added. **The 12-lp reserve is an arithmetic target, not a runtime guarantee.**

## 5. Band identity and Band Enabled

- **Identity:** `Band 1` through `Band 6`, displaying the **current ordinal of the selected band**, never internal UUID or opaque model identifier. Place in the left 160-lp upper-tier column.
- **Band Enabled:** the real processing on/off toggle for that selected band, placed below its identity **within the same 160-lp column**. It has the existing premium Studio Slate toggle treatment and a visible `Band Enabled` label; it is not a new DSP control.
- **States:** `OFF`, `ON`, `HOVER`, `PRESSED`, `KEYBOARD FOCUS`. State combinations (for example ON + keyboard focus) retain their underlying on/off geometry.
- **OFF ≠ unavailable:** disabling a band's processing does **not** make its Band Strip selector, Inspector or parameter fields automatically unselectable/uneditable. The existing view-model authority continues to govern data and edits.
- **Current StudioToggle baseline versus local visual target:** live M12B `ui/qml/StudioToggle.qml` paints an existing **`40 × 22 lp` track**, radius **11 lp**, thumb **16 lp**, travel **18 lp**. Its separate outer/focus indicator is **`44 × 26 lp`** and its root `implicitHeight` is **`32 lp`**; current label spacing is **`12 lp`**, not 8 lp. Board 06 may propose an **EQ-local 8-lp track-to-label gap** only after actual text/indicator metrics are checked within the 160-lp Band/Enabled column. The existing painted track dimensions are reusable; the label gap, outer focus envelope and row fit must not be silently treated as already implemented. The left column spans both 28-lp upper subrows plus their 4-lp intervening gap (**60 lp**), so its 32-lp root does not itself have to shrink to 28 lp. Do not globally modify `StudioToggle` or `StudioButton`.
- **Focus treatment:** visible independent keyboard focus, not merely an ON halo or Hover fill; preserve focus-ring visibility within the 160-lp column and the 28-lp upper-row envelope. If the current shared toggle contract uses a different exact focus rendering, preserve that contract and request a **narrow EQ-local delta** rather than globally changing it.

## 6. Contextual Mixed Routing badge

- Show the non-interactive label **`MIXED ROUTING ACTIVE`** *only* when the existing ViewModel reports `mixedRouting = true`.
- The badge is **`164 × 28 lp`** within the Routing subrow and is accounted for by its complete 808-lp budget, even when the runtime condition is false. When absent, the corresponding badge is **not** converted into a new user-facing control.
- The badge uses the approved **local muted-violet Mixed Routing treatment**. It is visually distinct from normal/cyan selection and from `rgs.processed.purple`; Mixed Routing is not a synonym for the global PROCESSED semantic color.
- It is not a button, not focusable, not an additional routing mode, and never appears a second time in the 24-lp bottom Status / Validation Strip.
- **Token ownership and intentionally deferred paint authority:** Boards 02–05 do not establish a unique final approved EQ-local pigment pair for this inspector badge. The next dedicated **Board 07 — Mixed Routing / Validation / Global States** must specify or explicitly confirm the exact local Mixed badge colors and design `#RRGGBBAA` → QML `#AARRGGBB` crosswalk. Board 06 freezes the badge **geometry, visibility, placement and non-interactive meaning only**, not an invented pigment. Do not substitute `rgs.processed.purple` because both are violet. **BOARD07 PAINT INPUT REQUIRED before pixel-fidelity implementation sign-off.** This narrow deferred visual input is not permission to redesign the Board 06 layout.

## 7. Typography — inherited without modification

| Role | Token | Font / fallback | Size | Weight | Line-height | Tracking | Color token | Alignment |
|---|---|---|---:|---:|---:|---:|---|---|
| Selected Band identity | `mastering.type.sectionTitle` | Segoe UI / platform sans-serif | `14 lp` | `600` | `20 lp` | `0` | `rgs.neutral.100` | Left |
| `FILTER`, `ROUTING`, parameter labels | `mastering.type.controlLabel` | Segoe UI / platform sans-serif | `12 lp` | `600` | `16 lp` | `0` | `rgs.neutral.300` | Left |
| Other small descriptive labels | `mastering.type.secondaryLabel` | Segoe UI / platform sans-serif | `11 lp` | `400` | `16 lp` | `0` | `rgs.neutral.300` | Left |
| Direct numeric value | `mastering.type.numericValue` | Consolas / Courier New → platform fixed pitch | `16 lp` | `400` | `20 lp` | `0` | `rgs.neutral.100` | Right; tabular |
| Hz, dB, dB/oct (where applicable) | `mastering.type.unit` | Segoe UI / platform sans-serif | `12 lp` | `400` | `16 lp` | `0` | `rgs.neutral.300` | Left |
| Segmented button text | `mastering.type.buttonTab` | Segoe UI / platform sans-serif | `13 lp` | `600` | `18 lp` | `0` | `rgs.neutral.100` (normal) | Center |

**Control labels are `Segoe UI 12 lp / 600`, numeric values are `Consolas 16 lp / 400`**. Never use the `160-lp` Band column width as a font size or silently restore old Inter specimens. This board does not modify the global GUI-01 typography authority.

## 8. Direct numeric field geometry

Board 03's complete component is reused **without rescaling**:

| Component dimension / behavior | Value | Authority |
|---|---|---|
| Label line box | `16 lp` | Board 03 |
| Label-to-field gap | `6 lp` | Board 03 |
| Input **box** height | `28 lp` | Board 03 |
| Complete label + gap + input height | **`50 lp`** | Board 03; `16 + 6 + 28` |
| Value font | Consolas `16 lp / 400 / 20-lp line` | Board 03 |
| Label font | Segoe UI `12 lp / 600 / 16-lp line` | Board 03 |
| Unit font | Segoe UI `12 lp / 400 / 16-lp line` | Board 03 |
| Value alignment | Right; fixed-pitch/tabular | Board 03 |
| Unit alignment | Left | Board 03 |
| Input-to-unit gap | `8 lp` | Board 03 |
| EQ-local **input box width** | **`164 lp`** | **EQ-LOCAL — PROPOSED**; not a Board 03/global width |
| Input-only field radius | `4 lp` | Board 03 EQ-local field treatment |

The optional unit label is **outside** the numeric input box unless the existing numeric component contract explicitly includes it. It must be accounted for by a parent group's available width and actual font metrics, not silently omitted. The **50-lp** height applies to the label, gap and input rectangle; it does not consume extra vertical space for unit text.

## 9. Parameter visibility and validity

### 9.1 Filter → visible lower-tier controls

| Selected filter | Visible controls in order | Controls not shown |
|---|---|---|
| **Bell** | Frequency · Gain · Q | Shelf Slope and HP/LP Slope |
| **Notch** | Frequency · Q | Gain and both slope controls |
| **Low Shelf** | Frequency · Gain · Shelf Slope | Q and HP/LP Slope |
| **High Shelf** | Frequency · Gain · Shelf Slope | Q and HP/LP Slope |
| **High Pass** | Frequency · HP/LP Slope | Gain, Q and Shelf Slope |
| **Low Pass** | Frequency · HP/LP Slope | Gain, Q and Shelf Slope |

**Non-applicable controls are HIDDEN**, not grayed-out placeholders, and do not reserve unused horizontal slots. This visibility contract does not introduce new numeric or DSP behavior. The standard visual specimen is **Band 1 / Enabled ON / BELL / STEREO / Frequency `1000 Hz` / Gain `+3.0 dB` / Q `0.707`**, with *only these three* parameter fields in its lower tier.

### 9.2 Existing parameter limits (validation authority stays in the current C++/ViewModel)

| Parameter | Actual accepted range / choices | UI control type | Applicable filters |
|---|---|---|---|
| Frequency | `20 Hz ≤ f ≤ min(20000 Hz, 0.45 × Fs)` | Direct numeric | All six |
| Gain | `−18.0 dB ≤ G ≤ +18.0 dB` | Direct numeric | Bell, Low Shelf, High Shelf |
| Q | `0.10 ≤ Q ≤ 12.0` | Direct numeric, unitless | Bell, Notch |
| Shelf Slope | `0.10 ≤ S ≤ 1.0` | **Direct numeric, unitless** | Low Shelf, High Shelf |
| HP/LP Slope | **`6 / 12 / 18 / 24 / 36 / 48 dB/oct`** | **Six-choice discrete segmented control** | High Pass, Low Pass |

Example: if `Fs = 44100 Hz`, the frequency upper bound is `19845 Hz`. A Shelf Slope value such as `0.70` is **not** `24 dB/oct`; those are distinct parameters of distinct filter families. Display formatting must not silently cap direct-entry precision, change a committed value, or clamp invalid drafts.

### 9.3 Compact lower-tier examples

- **Bell:** Frequency `1000 Hz` + Gain `+3.0 dB` + Q `0.707`.
- **Notch:** Frequency `1000 Hz` + Q `0.707`.
- **Low Shelf:** Frequency `200 Hz` + Gain `+4.0 dB` + unitless Shelf Slope `0.70`.
- **High Pass:** Frequency `80 Hz` + discrete HP/LP Slope `24 dB/oct` (selected).

Examples demonstrate *applicability and presentation*, not new presets or backend defaults. Reflow only existing applicable controls inside the 50-lp lower-tier height; do not create another tier.

## 10. HP/LP Slope — six-button discrete segmented control

The **real M12B control uses six individual discrete buttons**. A dropdown, direct numeric editor, free-text value, slider or knob is **not** authorized for HP/LP Slope.

| Token / role | Target |
|---|---:|
| `eq.inspector.hpSlope.segmentWidth` | `80 lp` |
| `eq.inspector.hpSlope.segmentHeight` | `28 lp` |
| `eq.inspector.hpSlope.dividerWidth` | `1 lp` |
| `eq.inspector.hpSlope.segmentCount` | `6` |
| `eq.inspector.hpSlope.groupWidth` | **`6 × 80 + 5 × 1 = 485 lp`** |
| Visible choices | `6`, `12`, `18`, **`24`**, `36`, `48` |
| Unit | `dB/oct`, included in the group label, tooltip and full accessible name |

The `24` selected specimen uses the same segmented-control family as Filter and Routing. **Selection ≠ Hover ≠ Keyboard Focus**; focus is distinguishable without changing geometry. A valid selection follows the **existing ViewModel draft/commit** interaction. Do not invent a new commit gesture or a QML-side DSP validation path.

### 10.1 High Pass / Low Pass lower-tier width budget

| Component | Width (lp) |
|---|---:|
| Frequency input box | `164` |
| Inter-control gap | `16` |
| SLOPE label column | `56` |
| Label-to-slope-controls gap | `8` |
| Six slope segments incl. five 1-lp dividers | `485` |
| **SPECIFIED GROUP SUBTOTAL** | **`164 + 16 + 56 + 8 + 485 = 729`** |
| **AVAILABLE** | **`820`** |
| **UNALLOCATED TARGET RESERVE** | **`91`** |

**Important accounting distinction:** `729 lp` is the explicitly approved *listed-items subtotal*, not a measurement of every rendered child. The 164-lp Frequency input **box** remains separate from its `8-lp` unit gap and the actual rendered `Hz` width. Their footprint, any label overhang and focus-ring outsets **must fit into the remaining 91-lp reserve** without clipping or displacing the other controls outside 820 lp. Do not falsely count the Hz label as included inside the 164-lp input box. Any position adjustment to honor those existing children is a **local runtime-fit decision**, subject to the acceptance gate below.

The six 28-lp slope segments align vertically with the **input box**, while the Frequency numeric component keeps its complete **50-lp** label + gap + input anatomy. The unit `dB/oct` is not copied onto six numeric-entry boxes; it belongs to the segmented group label/accessible context.

## 11. Visual states and accessibility

### 11.1 Filter, Routing and HP/LP segmented controls

| State | Visual requirement | Text, border and geometry |
|---|---|---|
| **NORMAL** | Quiet, raised instrument-like child surface | Inherited neutral Segoe UI label, 1-lp neutral edge; unchanged segment geometry |
| **HOVER** | Localized, subordinate cyan surface/edge emphasis | Text stays legible; no selection claim; inherited hover token where approved |
| **PRESSED** | Transient shallow mechanical darkening | Never mistaken for Disabled or persistent Selected |
| **SELECTED** | Inward emphasized accent edge **and** stable surface contrast | Clear without color alone; selected value remains visible when hover ends |
| **KEYBOARD FOCUS** | Separate, clearly visible keyboard outline above underlying state | Focus ≠ Hover ≠ Selected; no row/segment geometry shift |
| **DISABLED — only if justified** | Attenuated but recognizable option | For **mono** material applies to Routing MID/SIDE/LEFT/RIGHT; do not invent other unavailable conditions |

All available interactive controls are Tab-focusable and expose full descriptive `Accessible.name`; use standard Qt activation behavior for discrete buttons without introducing new global shortcuts. Segment labels use the approved 13-lp / 600 typography and must not be compressed or ellipsized to manufacture fit. Unavailable controls expose their existing disabled semantics, not a fake processing-off status.

**Color/material mapping:** child controls may reference `eq.control.gradBottom` and `eq.control.border`; focused surfaces may reuse clipped `eq.overlay.focus`; the localized Pressed/Selected washes follow the approved Board 05 family where compatible. **No new global color** or permanent glow is created. Do not present one derived control as proof that all shared StudioButtons already render at 28 lp.

**Focus-ring geometry/placement:** where the Board 05 common-button treatment is reused, its existing **2-lp cyan focus ring / 2-lp visual offset** is the family reference. In dense 1-lp-divided segmented groups, paint focus above adjacent sibling visuals without enlarging `implicitWidth`/`implicitHeight`. The **7-lp Filter** and **12-lp Routing** design reserves are especially sensitive: if that established outer-ring geometry clips or visually collides, the coding agent must stop for a **narrow EQ-local focus-placement delta**, not silently shrink text, change the approved width formula or alter the shared focus token.

### 11.2 Direct numeric fields — inherit Board 03 without reinterpretation

| State | Text | Background | Border / width | Overlay | Caret and committed-value rule |
|---|---|---|---|---|---|
| **NORMAL** | `rgs.neutral.100` | `eq.field.bg` | `eq.control.border`, `1 lp` | None | Display current confirmed value |
| **HOVER** | `rgs.neutral.100` | `eq.field.bg` | `eq.field.hoverBorder`, `1 lp` | None | No editing claim from hover alone |
| **FOCUS / EDITING** | `rgs.neutral.100` | `eq.field.bg` | `rgs.raw.cyan`, `2 lp` | `eq.overlay.focus`, clipped Source-over | 2-lp cyan caret while editing; valid draft allowed |
| **INVALID DRAFT** | `rgs.error.coral` | `eq.field.bg` | `rgs.error.coral`, `1 lp` | `eq.overlay.error`, clipped Source-over | Raw text such as `abc` visible and **uncommitted** |
| **DISABLED — abstract specimen only** | `eq.field.disabledText` | `eq.field.bg` | Neutral `1 lp` under `eq.overlay.disabled` | Disabled overlay | **Does not** stand for hidden, non-applicable parameters |

`INVALID DRAFT` applies **only to direct numeric input**, never to Filter/Routing/HP-slope segmented buttons or the Band Enabled toggle. Invalid text must remain visible until the authorized interaction resolves it, and may not publish a DSP change. **Enter** commits valid input, **valid focus-out** commits, **Escape** restores the confirmed value; **no Apply/Cancel, no silent clamping**. Bypass and Band Enabled OFF do **not** automatically make applicable parameters readonly or unavailable.

### 11.3 Band Enabled state handling

| State | Requirement |
|---|---|
| OFF | Thumb/geometry expresses OFF; selected band remains editable |
| ON | Thumb/geometry expresses ON; accent is local/controlled |
| HOVER | Additional pointer feedback; does not toggle merely on hover |
| PRESSED | Transient feedback; not permanently selected by appearance alone |
| KEYBOARD FOCUS | Visible independent focus feedback; ON/OFF remains recognizable in grayscale |

`DISABLED` for Band Enabled is **not** assigned a new runtime condition in this manifest. If the actual code exposes a valid unavailable state, adapt the existing neutral visual family without inventing why or when it occurs.

## 12. Deterministic visual tokens and material crosswalk

### 12.1 Existing inherited colors — **do not redefine**

All color literals below are copied from the approved **Board 02 v1.1** or **Board 03 v1.0** manifests. The design column is **`#RRGGBBAA`**; Qt/QML uses **`#AARRGGBB`**. Never paste design-format eight-digit literals directly into QML.

| Token | Authority / role | Design `#RRGGBBAA` | QML `#AARRGGBB` |
|---|---|---|---|
| `eq.control.bg` | Board 02 parent material fallback | `#12243FFF` | `#FF12243F` |
| `eq.control.gradTop` | Board 02 Control Surfaces top | `#1C3A59FF` | `#FF1C3A59` |
| `eq.control.gradBottom` | Board 02 Control Surfaces bottom; allowed child fill *color* reference | `#0E1F2EFF` | `#FF0E1F2E` |
| `eq.control.border` | Board 02 parent/neutral control edge color | `#2C5A78FF` | `#FF2C5A78` |
| `eq.overlay.focus` | Board 02 clipped focus wash | `#00C8FF14` | `#1400C8FF` |
| `eq.overlay.disabled` | Board 02 clipped disabled wash | `#00000066` | `#66000000` |
| `eq.overlay.error` | Board 02 clipped invalid wash | `#F2768314` | `#14F27683` |
| `eq.field.bg` | Board 03 flat numeric child fill | `#0E1F2EFF` | `#FF0E1F2E` |
| `eq.field.hoverBorder` | Board 03 input hover edge | `#00C8FF59` | `#5900C8FF` |
| `eq.field.selectionBg` | Board 03 numeric editing selection | `#00C8FF40` | `#4000C8FF` |
| `eq.field.disabledText` | Board 03 abstract disabled text | `#62788F99` | `#9962788F` |
| `rgs.raw.cyan` | Shared RGS — inherited interaction/focus use | `#00C8FFFF` | `#FF00C8FF` |
| `rgs.error.coral` | Shared RGS — inherited true invalid text/edge | `#F27683FF` | `#FFF27683` |
| `rgs.neutral.100` | Shared RGS — inherited primary text | `#F5F8FCFF` | `#FFF5F8FC` |
| `rgs.neutral.300` | Shared RGS — inherited secondary text | `#A1B5C9FF` | `#FFA1B5C9` |
| `rgs.neutral.500` | Shared RGS — inherited muted text | `#62788FFF` | `#FF62788F` |

The **full** inherited `eq.control` surface is the Board 02 vertical gradient `#1C3A59FF → #0E1F2EFF`, structural 1-lp `#2C5A78FF` border, **6-lp** radius, `#2AA0D026` 1-lp internal top highlight and `#00000033` inner shadow at `(0,+1 lp)`, nominal 4-lp blur with the documented lightweight approximation. Reusing only its flat bottom color for a child is **not** permission to remove or replace the parent's structural material.

### 12.2 Compatible component-state references — inherited/proposed, no global promotion

| Token/reference | Classification | Design `#RRGGBBAA` | QML `#AARRGGBB` | EQ Inspector usage |
|---|---|---|---|---|
| `eq.board05.hoverOverlay` | **EQ-LOCAL — PROPOSED by Board 05, referenced here** | `#00C8FF14` | `#1400C8FF` | Localized Hover wash for compatible segmented/button child |
| `eq.board05.pressOverlay` | **EQ-LOCAL — PROPOSED by Board 05, referenced here** | `#00000026` | `#26000000` | Localized transient Pressed wash |
| `eq.board05.selectedOverlay` | **EQ-LOCAL — PROPOSED by Board 05, referenced here** | `#00C8FF24` | `#2400C8FF` | Selected cyan wash; paired with edge geometry |
| `eq.inspector.segment.focusEdge` | **EQ-LOCAL — PROPOSED reference alias** | `#00C8FFFF` | `#FF00C8FF` | Existing RGS interaction cyan; **not** a new pigment |
| `eq.inspector.segment.normalFill` | **EQ-LOCAL — PROPOSED reference alias** | `#0E1F2EFF` | `#FF0E1F2E` | Flat child fill; not another structural panel |
| `eq.inspector.segment.normalBorder` | **EQ-LOCAL — PROPOSED reference alias** | `#2C5A78FF` | `#FF2C5A78` | Neutral 1-lp segment-group frame/divider |

These referenced values have been **cross-checked against the accepted Board 05 v1.1 Integration-Reconciled** token table: `hoverOverlay #00C8FF14`, `pressOverlay #00000026`, `selectedOverlay #00C8FF24` (design notation) match. Board 05 v1.1 owns those tokens; Board 06 only references them and makes **no independent supersession**. No custom blur, neon halo, raster control skins, new warning/error use, or automatic adoption outside the EQ Editor is authorized.

### 12.3 Board 06 geometry tokens — candidate, **not global**

| Token | Value | Classification |
|---|---:|---|
| `eq.inspector.height` | `128 lp` | Board 01 — inherited |
| `eq.inspector.paddingX` | `16 lp` per side | EQ-LOCAL — PROPOSED |
| `eq.inspector.paddingTop` | `6 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.paddingBottom` | `8 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.filter.rowHeight` | `28 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.routing.rowHeight` | `28 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.upperSubrowGap` | `4 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.interTierGap` | `4 lp`, includes optional divider | EQ-LOCAL — PROPOSED |
| `eq.inspector.numericComponentHeight` | `50 lp` | Board 03 — inherited |
| `eq.inspector.bandEnabledColumnWidth` | `160 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.interColumnGap` | `8 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.controlLabelColumnWidth` | `56 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.labelToControlsGap` | `8 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.filter.segmentWidth` | `96 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.filter.groupWidth` | `581 lp` | Derived; six segments + five dividers |
| `eq.inspector.routing.segmentWidth` | `80 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.routing.groupWidth` | `404 lp` | Derived; five segments + four dividers |
| `eq.inspector.mixedBadgeWidth` | `164 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.mixedGap` | `8 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.numericInputBoxWidth` | `164 lp` | EQ-LOCAL — PROPOSED, not global |
| `eq.inspector.hpSlope.segmentWidth` | `80 lp` | EQ-LOCAL — PROPOSED |
| `eq.inspector.hpSlope.groupWidth` | `485 lp` | Derived; six segments + five dividers |

All segmented controls target **28-lp visual height** and use **1-lp shared dividers**, without manufacturing new independent gaps between segment rectangles. Their child border/radius appearance stays within the approved Studio Slate family. These values are **targets**, not measured Qt `implicitWidth` or `implicitHeight`.

## 13. Qt 6/QML implementation feasibility gate — mandatory

**Board 06 passes arithmetic review, not measured runtime layout review.** Existing shared `StudioButton` has approximately **32-lp implicit height**. Board 06 proposes **28-lp** Filter, Routing and HP/LP controls. Reaching that visual size requires an **EQ-local adaptation** verified on the real Windows executable. Do not silently shrink or modify `StudioButton` across RGS MasterLab.

### 13.1 Required measurements on actual Windows QML controls

The coding agent must measure and record:

1. Actual `implicitWidth` and `implicitHeight` for **all six Filter segments**, including `HIGH SHELF` and `HIGH PASS`, not just short labels.
2. Actual Segoe UI text metrics at Board 03 sizes/weights, real internal padding, shared dividers and any `Layout.spacing`.
3. Actual `implicitWidth`/height and text metrics for **all five Routing segments**, including unavailable modes on MONO.
4. Actual Band + Enabled group width with its toggle and readable label in **160 lp**.
5. Full **164-lp** Mixed badge width including its label at the approved font/padding and any applicable border.
6. **28-lp** segmented-control height in the existing Qt component family; any local derived component must remain visually consistent and not change the shared `StudioButton`.
7. Numeric input **164-lp width**, **28-lp box height**, **50-lp complete component height**, font and unit-label spacing, all applicable filter variants. For HP/LP the approved **729-lp** subtotal includes the Frequency **box** but does not include the `8-lp` unit gap, rendered `Hz` label, or focus outsets; measure those against the 91-lp unallocated reserve rather than treating them as free.
8. All **six HP/LP Slope buttons** (labels, shared dividers, focus rendering, visible `dB/oct` context), including the **485-lp** group width.
9. Actual external focus-ring outsets or rendering overlap with siblings. Verify no clipped 2-lp/2-lp family focus treatment, especially with **7-lp** and **12-lp** remaining row budgets.
10. At `900 × 580` and `1040 × 660`, verify actual rendered envelopes for the complete upper and lower tiers; inspect keyboard-only traversal and viewport/clipping. Separately measure the **current 44 × 26-lp toggle outer indicator / 32-lp root**, its readable label and its actual spacing inside the 160-lp left column; apply any gap adjustment EQ-locally.

### 13.2 Required functional/view-state specimens

- **Bell** lower tier: Frequency, Gain, Q only.
- **Notch** lower tier: Frequency, Q only.
- **Low Shelf / High Shelf**: Frequency, Gain, unitless numeric Shelf Slope.
- **High Pass / Low Pass**: Frequency plus **six discrete** HP/LP slope buttons; `24` selected specimen.
- **Mono Source:** STEREO usable; MID, SIDE, LEFT, RIGHT unavailable and visibly marked without inventing a new routing.
- **Band Enabled OFF:** band stays selected/selectable and its applicable parameters remain editable.
- **Mixed Routing:** badge appears only when existing `mixedRouting == true`; remains inside Routing subrow and absent from bottom Status / Validation.
- **Numeric invalid draft:** raw `abc` can remain visible and uncommitted; focus/valid and invalid/error are visually distinct.
- **Segmented focus:** focus differs from selected/hover; no invalid free-text treatment for segments or toggle.

### 13.3 Acceptance / stop conditions

Accept Board 06 visual implementation **only after** on-device Qt/QML evidence establishes:

- [ ] Inspector exactly `128 lp` high; Band Strip/Graph/Status macro geometry from Board 01 unchanged.
- [ ] Horizontal padding exactly `16 lp` per side; `820-lp` minimum usable track; no unbudgeted extra row padding.
- [ ] Filter subrow calculated `813 lp`, Routing subrow `808 lp`; actual Qt implicit widths, labels, dividers, padding and focus rendering fit without clipping or overlap.
- [ ] Full vertical arithmetic `6 + 28 + 4 + 28 + 4 + 50 + 8 = 128 lp`, optional divider included in the existing 4-lp inter-tier gap.
- [ ] Filter **six × 96 × 28 lp**, shared dividers `5 × 1 lp`; Routing **five × 80 × 28 lp**, dividers `4 × 1 lp`, 164-lp Mixed badge as appropriate.
- [ ] HP/LP **six × 80 × 28 lp** with five 1-lp dividers; 485-lp total; High Pass layout includes Frequency plus this exact discrete group, not a dropdown.
- [ ] Only applicable controls are visible for all filters; no disabled placeholders or reserved spaces for hidden parameters.
- [ ] All direct-entry fields retain Board 03's anatomy; values/units/focus/invalid text are visually and semantically correct.
- [ ] No horizontal scrolling, no clipped label, no missing or inaccessible button, no clipped keyboard-focus ring, no introduced business/DSP logic.
- [ ] Both **`1040 × 660`** and **`900 × 580`** Windows tool-window sizes pass measured layout tests; observed measurements are attached to independent integration review.

**Blocking rule:** the Filter row's **7-lp** and Routing row's **12-lp** arithmetic reserves are **not safety certificates**. If Qt `implicitWidth`/`implicitHeight`, font metrics, padding, unit text or focus outsets defeat the candidate, **stop** and request a **narrow, explicit, Product Owner-approved EQ-local layout delta**. Do not silently redefine Board 01, reduce fonts, remove options, stack rows, add scrolling, or globally change `StudioButton`.

## 14. Scope exclusions and freeze boundary

This is the **Board 06 canonical textual design manifest v1.0** for independent integration review. It defines an implementation-ready target specification, **not** proof of current runtime fit. It does not generate Board 07, rewrite Boards 01–05, create QML code/handoff, add feature or DSP logic, change any global color/font token, invent unavailable states, introduce controls/presets/sliders/knobs/Apply/Cancel, or declare the full RGS MasterLab Visual WOW package frozen.


## 15. Independent integration reconciliation and freeze boundary — v1.1

**Source/provenance:** GUI-authored Board 06 v1.0 manifest. The accepted visual direction is the Board 06 Final Reconciled Candidate. This v1.1 changes no approved Board 01 macro dimensions, Board 02 materials, Board 03 typography, Board 04 graph logic, Board 05 band/preview/A-B controls or DSP semantics.

**Verified:** vertical Inspector budget **128 lp**; usable min width **820 lp** after two 16-lp insets; Filter **813 lp** with **7-lp** nominal remainder; Routing including contextual Mixed badge **808 lp** with **12-lp** nominal remainder; HP/LP six discrete segments **485 lp**, lower-tier listed subtotal **729 lp** with **91-lp reserve for actual Hz/gap/focus and residual placement**; per-filter applicability, mono routing, direct-entry draft rules, and 22 inherited/reference design-to-QML color pairs.

**Two narrow clarifications only:** (1) the current `StudioToggle` already paints a 40 × 22-lp track but has a separate 44 × 26-lp focus/indicator envelope, root `implicitHeight=32`, and 12-lp default label spacing; its proposed 8-lp EQ-local label gap is not an existing baseline fact. (2) exact Mixed badge color authority remains explicitly **reserved for Board 07**; never invent a local color or silently equate it with the global PROCESSED color. The referenced Board 05 v1.1 overlay token triplet has been cross-checked unchanged.

**Scoped disposition:** Board 06 Inspector Controls **DESIGN / NUMERIC INTEGRATION PASS — SCOPED FROZEN**, except that its Mixed badge exact pigment awaits the Board 07 paint crosswalk. **Runtime fit is NOT certified.** Before real UI approval, the later bounded EQ-local implementation must pass actual Windows Qt measurements, keyboard/pointer inspection and rendered evidence at 1040 × 660 and 900 × 580. If actual dimensions break the narrow design remainder, stop for a PO-approved EQ-local forward delta rather than reducing fonts, losing controls, changing shared components, adding scrolling or modifying Board 01.

**Next phase:** Board 07 visual design/review, one board at a time. Do not initiate Jules WOW implementation, Windows Full Qualification, PO Gates M/L, PR merge or M13 solely on the strength of this design manifest.
