# RGS MasterLab — L1-M12B
# BOARD 05 — CANONICAL BAND SELECTOR / PREVIEW STATUS / A-B MANIFEST v1.1 — INTEGRATION RECONCILED

**Deliverable:** text-only canonical numerical/visual companion to **Board 05 — Runtime-Compatible Consolidated Candidate**, submitted for **independent integration review**.  
**Scope:** EQ tool-window Header and Band Strip only: dynamic band selectors, Add/Remove, preview-status presentation, EQ-module A/B, associated local states and accessibility.  
**Status:** **INDEPENDENT INTEGRATION PASS — M12B-scoped visual/design specification accepted.** The exact control sizes remain implementation **targets**, not demonstrated QML runtime fit; the explicit measurement and Windows visual gates in §9 remain mandatory before implementation acceptance. Shared/family token promotion is not implied. **The overall L1-M12B Visual WOW Package is not frozen.**

## 1. Authority, precedence, and non-supersession

| Authority | Binding scope for this document | Boundary |
|---|---|---|
| **Board 01 — Canonical Macro Geometry v1.0** | Tool window **1040 × 660 lp** default, **900 × 580 lp** minimum; effective inset **24 lp** each side; inner widths **992 / 852 lp**; Header **48 lp**; Band Strip **40 lp**; inter-section gap **12 lp** | No revised window, inset, section heights, graph, Inspector, or Status/Validation geometry |
| **Board 02 — Canonical Material Token Manifest v1.1 QML-Safe** | Existing `rgs.*`, `eq.control.*` structural material, and `eq.overlay.*` values/serialization | No new shared colors; no replacement of structural gradients, borders, radii, or shadows |
| **Board 03 — Canonical Typography & Numeric Field Manifest v1.0** | Segoe UI, typography/fallback, `mastering.type.buttonTab`, `eq.type.previewStatus`, `eq.type.abControl`, existing color precedence | No revised global fonts or numeric fields |
| **Board 04 — Canonical Graph & Handles v1.1 Integration Reconciled** | Existing curve, band-handle, grid, and band-identity authority | No new curve/handle colors, geometry, or graph interactions in this Board 05 |
| **Board 05 — Runtime-Compatible Consolidated Candidate** | Component visual direction and arrangement, corrected by the explicit exact geometry and semantic requirements in this manifest | Visual illustration is **not** proof of QML fit; erroneous image-table entries have no numerical authority |

All dimensions are **logical pixels (`lp`)** under the Windows 10 reference baseline. Design RGBA strings use **`#RRGGBBAA`**; Qt/QML eight-digit `color` strings use **`#AARRGGBB`**. Use the existing Board 02 QML-Safe crosswalk for inherited colors; every new local color in §8 includes both forms.

**Reusability designations:** **SHARED RGS — INHERITED** means a reference only, not a global modification. **MASTERING MODULE FAMILY — PROPOSED** describes potential reuse requiring later approval. **EQ-LOCAL — PROPOSED** remains within M12B. No proposed item is silently promoted to a shared frozen token.

## 2. Two separate rows: Header and Band Strip

| Row / arrangement | Exact requirement | Content |
|---|---|---|
| **Header** | **48 lp high**, full usable width | Left: **Parametric EQ** above **Manual Mastering**. Right: **Preview Status** immediately left of **A / B** |
| **Inter-row gap** | **12 lp** | Empty separation, not a functional row |
| **Band Strip** | **40 lp high**, full usable width | **Only** 1–6 existing band selectors, one visual separator, **Add Band**, **Remove Band** |

Both rows use their assigned Board 02 material hierarchy. The Band Strip and Inspector inherit the same structural **Control Surfaces** material; this manifest defines component-only treatments *inside* that existing surface. No optional **BANDS** label, duplicate app logo, PREPARED/PROCESSED/GOLD selector, global navigation, transport, analyzer, or new backend state is introduced.

**Header optical fit:** Board 03 title **Segoe UI 20/600/24**, subtitle **Segoe UI 12/400/16**, combined **40-lp line box** in the **48-lp header**. Preview status and A/B align to the same header and do not displace, wrap, or diminish the title. The Preview Status and A/B share the right-end cluster; no additional status is inserted between them.

**Vertical component placement (EQ-local Board 05 proposal):** band and action buttons are **32 lp** high, vertically centered in the **40-lp** Band Strip (**4 lp** free above and below). A/B controls are represented at **32 lp** high and the preview badge at **28 lp** high, respectively centered in the **48-lp** Header (**8 lp** and **10 lp** free above/below). These child dimensions do not alter Board 01's rows.

## 3. Geometry and dynamic band population

### 3.1 Exact horizontal tokens

| Token | Value | Classification | Meaning |
|---|---:|---|---|
| `eq.band.buttonWidth` | **90 lp** | EQ-LOCAL — PROPOSED | Each **existing** band-selector button |
| `eq.band.buttonHeight` | **32 lp** | EQ-LOCAL — PROPOSED | Band-selector visible/button height |
| `eq.band.buttonRadius` | **8 lp** | EQ-LOCAL — PROPOSED | Child control radius; does not change `eq.control.radius` |
| `eq.band.interButtonGap` | **8 lp** | EQ-LOCAL — PROPOSED | Gap between consecutive existing band buttons |
| `eq.band.countMin` / `countMax` | **1 / 6** | EXISTING M12B RUNTIME | Dynamic number of bands; not six permanent controls |
| `eq.band.postBandGap` | **12 lp** | EQ-LOCAL — PROPOSED | Empty width after last band before separator area |
| `eq.band.separatorToAddGap` | **24 lp** | EQ-LOCAL — PROPOSED | Whole reserved segment from separator-area start to Add left edge; **includes the 1-lp visual separator** |
| `eq.band.separatorStroke` | **1 lp** | EQ-LOCAL — PROPOSED | Non-interactive decorative separator, **inside** the accounted 24-lp segment |
| `eq.band.actionGap` | **12 lp** | EQ-LOCAL — PROPOSED | Space between Add and Remove |
| `eq.band.rightMargin` | **20 lp** | EQ-LOCAL — PROPOSED | Space after Remove to the strip's usable right edge |
| `eq.action.widthDefault` | **128 lp** | EQ-LOCAL — PROPOSED | Add Band / Remove Band at default-width context |
| `eq.action.widthCompact` | **96 lp** | EQ-LOCAL — PROPOSED | **EQ-local** Add / Remove at minimum-width context |
| `eq.action.height` | **32 lp** | EQ-LOCAL — PROPOSED | Both action buttons in both contexts |
| `eq.action.radius` | **8 lp** | EQ-LOCAL — PROPOSED | Both action buttons |
| `eq.header.height` | **48 lp** | BOARD 01 — INHERITED | Header, not a new Board 05 height |
| `eq.band.stripHeight` | **40 lp** | BOARD 01 — INHERITED | Band Strip, not a new Board 05 height |
| `eq.headerToBand.gap` | **12 lp** | BOARD 01 — INHERITED | Empty inter-section gap |

**Separator accounting:** there is **no extra separator width outside** the listed `12 + 24` post-band/separator segments. This is deliberate; otherwise the six-band minimum-width case exceeds its budget.

### 3.2 Mandatory mathematical fit

**Six bands at minimum window width (900-lp outer; 852-lp inner):**

| Segment | Arithmetic | Width (lp) |
|---|---|---:|
| Six selectors | `6 × 90` | **540** |
| Five gaps | `5 × 8` | **40** |
| **Complete band group** | `540 + 40` | **580** |
| Post-band gap | Fixed | **12** |
| Separator-to-Add reserved segment, separator included | Fixed | **24** |
| Compact Add | Fixed | **96** |
| Add-to-Remove gap | Fixed | **12** |
| Compact Remove | Fixed | **96** |
| Right margin | Fixed | **20** |
| **TOTAL REQUIRED** | `580 + 12 + 24 + 96 + 12 + 96 + 20` | **840** |
| **AVAILABLE** | `900 − 2 × 24` | **852** |
| **REMAINING** | `852 − 840` | **12** |

**Six bands at default window width (1040-lp outer; 992-lp inner):** `580 + 12 + 24 + 128 + 12 + 128 + 20 = 904 lp`; **992 − 904 = 88 lp** remaining.

### 3.2a Deterministic responsive action variant (integration clarification)

**Switch by available inner content width, not by an arbitrary named window size.** The nominal full-action arrangement occupies **904 lp** and the compact-action arrangement **840 lp**. Preserve a **minimum 12-lp left visual/focus reserve** in the six-band case. Therefore use the **128-lp default Add Band / Remove Band actions when usable inner width is at least 916 lp**; use the **96-lp compact Add / Remove actions when usable inner width is 852–915 lp**. On the frozen 24-lp effective inset, the nominal threshold corresponds to an outer width of **964 lp**. This threshold is an **EQ-local nominal layout rule**: if measured Qt `implicitWidth`, text/icon/padding or focus geometry differ from the nominal targets, recalculate the breakpoint and seek explicit approval for any local geometry delta. Do not silently shrink labels, reduce Board 01 insets, or modify shared StudioButton.

**Reserve policy:** the remaining **12 lp minimum / 88 lp default** may be placed to the **left of the band group** as elastic empty reserve; it must not be quietly added to the fixed gaps or button implicit widths. A right margin of **20 lp** is still included in the calculations. With left-aligned, unexpanded buttons, the six-band layouts have these deterministic target x ranges measured from the usable content's left edge:

| Range | Minimum / compact (lp) | Default / full (lp) |
|---|---|---|
| Left elastic reserve | `[0, 12)` | `[0, 88)` |
| Six-band group | `[12, 592)` | `[88, 668)` |
| Post-band gap | `[592, 604)` | `[668, 680)` |
| Separator-to-Add reserved segment | `[604, 628)` | `[680, 704)` |
| Add button | `[628, 724)` | `[704, 832)` |
| Action gap | `[724, 736)` | `[832, 844)` |
| Remove button | `[736, 832)` | `[844, 972)` |
| Right margin | `[832, 852)` | `[972, 992)` |

These are **design targets, not measured QML dimensions**. The separator is purely visual within its reserved segment; no width is added to either total. For 1–5 existing bands the selector group simply contains fewer buttons; the actions remain visible and no ghost band buttons are rendered.

### 3.3 Identity inside each button

Visible band labels are the **current ordinal** plus a compact filter abbreviation: **`BELL`, `NOTCH`, `LS`, `HS`, `HP`, `LP`**. Full expansions: Bell, Notch, Low Shelf, High Shelf, High Pass, Low Pass. The number reflects **current ordinal 1–6**, never an internal UUID. The button shows the **filter currently assigned to that band**; `1 BELL` through `6 LP` are **illustrative sample data**, not a requirement that each ordinal permanently maps to that filter.

The full filter name must be discoverable by pointer tooltip **and** keyboard-focus tooltip/accessibility. Example `Accessible.name`: `Band 3, Low Shelf, processing disabled, selected` (compose from actual model flags); do not expose internal identifiers as display labels. Selecting a band changes selection only, **not** its DSP parameters. No reorder, scrolling strip, hidden tabs, or band-type inference from band color.

## 4. Band-selector visual-state contract

### 4.1 State separation and precedence

A band may be **processing disabled** while its selector stays **enabled, selectable, focusable**, and capable of opening that band in the Inspector for reactivation. This must **never** be implemented with the selector's Qt `enabled = false`. Processing-disabled is an independent visual dimension that can coexist with **Selected** and/or **Keyboard Focus**. General `CONTROL UNAVAILABLE` is **not added as an EQ runtime state** by this manifesto.

Apply visual priority: **Keyboard Focus outer ring** coexists with **Selected** treatment; a transient **Pressed** state adds only press feedback; **Processing Disabled** subdues content without suppressing actual selection/focus. Pointer Hover is lower emphasis than explicit Selected/Focus. All seven named specimens use the same **90 × 32-lp geometry** without layout shift.

### 4.2 Deterministic states and treatment

The color-only aliases below reference Board 02; EQ-local overlay proposals are listed and crosswalked in §8. These EQ-local control-state treatments must remain visually subordinate to the EQ graph and the inherited editor-surface hierarchy; this Board 05 does not introduce or modify transport controls.

| State | Fill / overlay | Border / geometry | Ordinal + abbreviation | Selection / focus identification |
|---|---|---|---|---|
| **NORMAL** | Color `eq.control.gradBottom` (`#0E1F2EFF`) as flat child fill | `eq.control.border` (`#2C5A78FF`), **1 lp**, radius **8 lp** | `rgs.neutral.100`, `mastering.type.buttonTab` | No special halo |
| **HOVER** | Normal + `eq.board05.hoverOverlay` (`#00C8FF14`), Source-over | `eq.field.hoverBorder` (`#00C8FF59`), **1 lp** | Primary text unchanged | Subtle local brightening; no focused outer ring |
| **PRESSED** | Normal + `eq.board05.pressOverlay` (`#00000026`), Source-over | Cyan hover border, **1 lp**, fixed footprint | Primary text unchanged; no disabled fade | Inset darkness gives mechanical press feedback; no persistent selection |
| **SELECTED** | Normal + `eq.board05.selectedOverlay` (`#00C8FF24`), Source-over | `rgs.raw.cyan` (`#00C8FFFF`), **2 lp** drawn inward | Primary, full contrast | Stroke **and** visible surface change, not cyan alone; no enlarged box |
| **PROCESSING DISABLED BUT SELECTABLE** | Normal + `eq.board05.processingOffOverlay` (`#00000029`), Source-over | Neutral **1-lp** border | `rgs.neutral.300`; ordinal/filter **remain readable** | Focus and click still work; no semantic warning/error color |
| **SELECTED + PROCESSING DISABLED** | Processing-off treatment + selected overlay **only within the same button** | Cyan **2-lp inward** selected border | `rgs.neutral.300` at readable contrast | Selected by edge/surface while still visibly processing-off; remains selectable |
| **KEYBOARD FOCUS** | Preserve underlying processing/selection state; optionally local `eq.overlay.focus` (`#00C8FF14`) | **2-lp** cyan outer ring with **2-lp visual offset**; ring is an overlay, **not** extra Layout width | Inherit actual selected/processing treatment | Spatially distinct **outer** ring from Hover's **1-lp** border and Selected's **2-lp inward** border |

For **Selected + Processing Disabled + Keyboard Focus**, show all three: subdued readable label, selected **inward** 2-lp border, and separate **outer** 2-lp ring. Use a short fixed-opacity local edge echo (not blur) only where needed for the chosen premium visual direction. No broad halo and no automatic orange/yellow/red encoding for processing-off.

## 5. Add Band and Remove Band — momentary action controls

| Aspect | Add Band | Remove Band |
|---|---|---|
| Meaning | Append one band while total < 6 | Remove currently selected band while total > 1 |
| Visible default text | `Add Band` | `Remove Band` |
| Visible compact text | `Add` | `Remove` |
| Icon | **PLUS** in **all** states | **MINUS** in **all** states |
| Widths | **128 lp default / 96 lp compact** | **128 lp default / 96 lp compact** |
| Height / radius | **32 / 8 lp** | **32 / 8 lp** |
| State set | Normal, Hover, Pressed, Keyboard Focus, Disabled | Normal, Hover, Pressed, Keyboard Focus, Disabled |
| Disabling rule | Actual band count = **6** | Actual band count = **1** |

These are **momentary** actions. **No persistent Selected state.** The image's Remove-Hover **PLUS** glyph is a visual error: every Remove instance is **MINUS**, including Hover, Pressed, Focus, and Disabled. Do not add an extra confirmation dialog or an unauthorized seventh/zero-band workflow.

**Visual states:** Normal = neutral `eq.control.gradBottom` flat child fill, `eq.control.border` 1 lp, primary text; Hover = `eq.board05.hoverOverlay` + 1-lp cyan-alpha hover border; Pressed = `eq.board05.pressOverlay` + stable 1-lp border, no persistent glow; Keyboard Focus = same **2-lp outer cyan ring, 2-lp offset**, visible independently of Hover; Disabled = `eq.overlay.disabled` (`#00000066`) over the control surface/border, readable muted text `rgs.neutral.500`, glyph still recognizable. Keep identical geometry/icon in all states. Existing parent `StudioButton` behavior is not globally changed.

**Accessibility:** `Accessible.name` = `Add Band` or `Remove Band` (full name even for compact text). When disabled, expose actual disabled state and a truthful reason (`Maximum of six bands` / `Minimum of one band`) through accessible description and/or tooltip; do not invent a new UI command. Each enabled button participates in Tab focus and uses standard Qt button activation through Space/Enter; no new shortcuts are assigned.

## 6. Preview Status — the four real runtime states only

The preview badge is **informational, not a button**. It lives in the **48-lp Header**, directly **left of A/B**, and is independent of whether A or B is selected. Use Board 03 `eq.type.previewStatus`: **Segoe UI 11 lp, weight 600, line-height 16 lp**. Proposed badge height **28 lp**, **12-lp horizontal content padding**, **6-lp radius**, **1-lp border**. No long text is injected into the Header.

| Existing runtime status | Visible label | Foreground / border | Surface and optional indicator | Tooltip / accessible text |
|---|---|---|---|---|
| `NO_PREPARED_REALIZATION` | **NO PREVIEW** | `rgs.neutral.300` / `eq.control.border` | Neutral `eq.control.gradBottom`; **no** success, warning or error hue; no loading indicator | `No usable PREPARED realization is available; EQ preview is unavailable.` |
| `RENDERING` | **RENDERING** | `rgs.neutral.100` / `eq.control.border` | Neutral surface; optional **small segmented-ring activity glyph** in the existing badge area, **no numeric/progress claim** | `EQ preview is being rendered.` |
| `READY` | **READY** | `rgs.success.green` / `rgs.success.green` | Neutral surface + clipped `eq.overlay.success` (`#00D47A14`), Source-over; no broad glow | `EQ preview is ready.` |
| `ERROR` | **ERROR** | `rgs.error.coral` / `rgs.error.coral` | Neutral surface + clipped `eq.overlay.error` (`#F2768314`), Source-over | `EQ preview failed; details are available in Status / Validation when provided by previewError.` |

`eq.board05.preview.*` component geometry/colors are **EQ-LOCAL — PROPOSED**, except the inherited references themselves. The RENDERING activity glyph, if present in the approved visual, must remain a small vector/Shape icon; it does **not** imply an additional backend state, a percentage, continuous FFT analysis, or a guaranteed time-to-ready. No other preview states (including `ANALYZING`) are authorized. The long real `previewError` detail belongs in the existing **bottom Status / Validation Strip**, not beside A/B.

**Maximum-label header reservation:** calculate actual `QFontMetrics`/Qt text implicit widths for **all four localized visible labels** in Segoe UI **11/600**, then allocate `badgeWidth = max(labelImplicitWidth of all four) + 2 × 12 lp` (plus actual activity-glyph footprint only if it is shown **inside** that badge). Reserve that maximum consistently across preview states to avoid layout shift. **Do not assume** `ERROR` or `NO PREVIEW` is widest without measuring the actual font and label set. At **852-lp inner width**, simultaneously show the **Parametric EQ / Manual Mastering** title block, worst-case preview badge, and the existing A/B cluster without clipping or a second branding row; exact rendered fit is a QML acceptance test, not a claim proved by the board illustration.

## 7. A/B — EQ module processing state, not separate presets

| Aspect | A | B |
|---|---|---|
| Control meaning | **EQ Active** | **EQ Module Bypass** |
| Visible label | `A` + `EQ Active` | `B` + `Bypass` (compact UI label) |
| Full accessible name | `A, EQ Active` | `B, EQ Module Bypass` |
| Existing model action | `viewModel.setBypass(false)` | `viewModel.setBypass(true)` |
| Selected semantic accent | `rgs.raw.cyan` **used as interaction cyan here** | `rgs.gold.amber` as **contextual Bypass accent only** |
| Parameters | **Same EQ parameters** | **Same EQ parameters** |
| Selection | Mutually exclusive with B | Mutually exclusive with A |

B is the **real bypass of this EQ module only**. It is **not** a generic processed/unprocessed switch, a second preset, a second parameter snapshot, a Level Match function, or a global GOLD audition selection. Bypass must not automatically make EQ parameter inputs non-editable. Do not reinterpret a preview READY/ERROR status as selecting A/B or vice versa.

**Proposed component geometry:** A and B have the same **32-lp height**, **8-lp child radius**, and a **1-lp normal border**. The compact internal lettering-and-label composition should derive its **implicit width from the actual rendered Segoe UI `eq.type.abControl` text** (13 lp / 600 / 18-lp line) and its existing `StudioButton` content padding/icon arrangement. No artificial fixed width is authorized here that would truncate `EQ Active` or `Bypass`; the **852-lp header fit must be measured** before QML acceptance. For predictable layout, reserve both A/B widths in both selection states.

| Visual state | A treatment | B treatment | Invariant |
|---|---|---|---|
| **Default (not selected)** | Neutral child surface, subdued neutral border/text | Same neutral treatment | Text `A`/`B` and names stay legible |
| **Hover** | Local cyan-alpha hover border/surface | Local **amber-alpha** hover border/surface | No selected-state assumption or broad halo |
| **Pressed** | Press-darkened neutral/underlying surface + cyan edge | Press-darkened neutral/underlying surface + amber edge | Transient press, not a third EQ mode |
| **Selected** | Inward **2-lp cyan** border plus local cyan overlay | Inward **2-lp amber** border plus local amber overlay | One selected, other unselected; surface/stroke and label express selection, not color alone |
| **Keyboard Focus** | Separate **2-lp outer cyan** ring, **2-lp offset**, on top of existing state | Same outer keyboard-focus ring while retaining B's contextual amber treatment | Focus is visibly distinct from Hover and Selected; no layout shift |

Normal texts inherit Board 03 `eq.type.abControl` (`rgs.neutral.100` when active, `rgs.neutral.300` when inactive). B amber is an **EQ-local contextual reuse**, not a change to the global GOLD token. No extra A/B states or backend modes are defined.

## 8. Color/material tokens and exact QML crosswalk

### 8.1 Existing inherited references — do not redeclare or supersede

| Existing token / classification | Design `#RRGGBBAA` | QML `#AARRGGBB` | Board 05 use |
|---|---|---|---|
| `eq.control.gradBottom` — Board 02 local structural **inherited** | `#0E1F2EFF` | `#FF0E1F2E` | Flat child-color reference only; parent Control Surfaces gradient **unchanged** |
| `eq.control.border` — Board 02 local structural **inherited** | `#2C5A78FF` | `#FF2C5A78` | Neutral component border color reference |
| `eq.field.hoverBorder` — Board 03 **EQ-LOCAL PROPOSED, inherited here** | `#00C8FF59` | `#5900C8FF` | 1-lp hover edge for neutral buttons |
| `eq.overlay.focus` — Board 02 local **inherited** | `#00C8FF14` | `#1400C8FF` | Clipped local focus surface cue only |
| `eq.overlay.disabled` — Board 02 local **inherited** | `#00000066` | `#66000000` | Genuinely unavailable action buttons only |
| `eq.overlay.success` — Board 02 local **inherited** | `#00D47A14` | `#1400D47A` | Actual preview READY badge fill overlay |
| `eq.overlay.error` — Board 02 local **inherited** | `#F2768314` | `#14F27683` | Actual preview ERROR badge fill overlay |
| `rgs.raw.cyan` — **SHARED RGS — INHERITED** | `#00C8FFFF` | `#FF00C8FF` | Interaction, focus, A selected edge |
| `rgs.success.green` — **SHARED RGS — INHERITED** | `#00D47AFF` | `#FF00D47A` | READY text/border only when ready |
| `rgs.gold.amber` — **SHARED RGS — INHERITED** | `#F2B632FF` | `#FFF2B632` | B selected **contextual** border, not global GOLD state |
| `rgs.error.coral` — **SHARED RGS — INHERITED** | `#F27683FF` | `#FFF27683` | Actual preview ERROR only |
| `rgs.neutral.100` — **SHARED RGS — INHERITED** | `#F5F8FCFF` | `#FFF5F8FC` | Normal readable control text |
| `rgs.neutral.300` — **SHARED RGS — INHERITED** | `#A1B5C9FF` | `#FFA1B5C9` | Secondary/inactive/processing-off readable text |
| `rgs.neutral.500` — **SHARED RGS — INHERITED** | `#62788FFF` | `#FF62788F` | Actually disabled action text |

An inherited **color reference** is not reuse of a whole structural material. Board 02 continues to own parent surfaces, gradients, structural edge highlights, radii, and shadows; Board 03 continues to own font definitions. Board 04 v1.1 continues to own graph/handle/identity tokens: **no Band 1–6 identity-color definitions appear here**.

### 8.2 New Board 05 candidate local color tokens

| Token | Classification | Design `#RRGGBBAA` | Qt/QML `#AARRGGBB` | Purpose, alpha, composition |
|---|---|---|---|---|
| `eq.board05.hoverOverlay` | **EQ-LOCAL — PROPOSED** | `#00C8FF14` | `#1400C8FF` | Cyan **7.84%** local Hover wash; **Source-over**, clipped to control |
| `eq.board05.pressOverlay` | **EQ-LOCAL — PROPOSED** | `#00000026` | `#26000000` | Black **14.90%** transient inset-press wash; Source-over |
| `eq.board05.selectedOverlay` | **EQ-LOCAL — PROPOSED** | `#00C8FF24` | `#2400C8FF` | Cyan **14.12%** selected surface wash; Source-over |
| `eq.board05.processingOffOverlay` | **EQ-LOCAL — PROPOSED** | `#00000029` | `#29000000` | Black **16.08%** processing-off *selector* wash, **not** `eq.overlay.disabled`; Source-over |
| `eq.board05.bypassHoverEdge` | **EQ-LOCAL — PROPOSED** | `#F2B63259` | `#59F2B632` | Amber **34.90%** B-Hover edge; no warning meaning |
| `eq.board05.bypassSelectedOverlay` | **EQ-LOCAL — PROPOSED** | `#F2B63224` | `#24F2B632` | Amber **14.12%** selected B fill; Source-over |

All values above are **component-state proposals**, not replacements for `rgs.*`, `eq.control.*`, or Board 03 field tokens. `eq.board05.bypassHoverEdge` is for the existing GOLD amber **color reused in the Bypass context**, **not** a global semantic color change. The preview states reuse Board 02 `eq.overlay.success` and `eq.overlay.error` unchanged. No additive blending, shader-only gradient, persistent neon edge, broad bloom, or raster button asset is required.

### 8.3 Component-state geometry/material summary

| Component | Normal fill color reference | Normal border | Radius | Local focus treatment | Highlight/shadow policy |
|---|---|---|---:|---|---|
| Band button | `eq.control.gradBottom` as child fill | `eq.control.border`, **1 lp** | **8 lp** | **2-lp** outer cyan, **2-lp offset** | Parent Control Surfaces retain Board 02 material; only small clipped overlays and sharp edge shifts |
| Add / Remove button | Same neutral child fill | Same **1-lp** neutral border | **8 lp** | Same **2-lp** outer cyan, **2-lp offset** | Same subdued child treatment; disabled uses inherited overlay |
| Preview badge | Same neutral child fill | Neutral **1 lp**; conditional semantic border | **6 lp** | Informational label: **not Tab-focusable** | READY/ERROR translucent semantic overlays only; RENDERING optional small vector indicator |
| A/B buttons | Same neutral child fill | Neutral **1 lp**; selected inward **2 lp** | **8 lp** | **2-lp** outer cyan, **2-lp offset** on focused control | A cyan / B contextual amber clipped selected washes; no broad halo |

**Layering:** structural parent `eq.control` material → component flat child surface and 1-lp edge → clipped transient/selection overlay → text/vector glyph → inward selected border → outer keyboard-focus ring (if applicable). All focus rings are painted outside the **visual** button border without changing its **implicitWidth**, the reserved inter-control gaps, or strip/header height. Ring visibility **and** clipping must be checked in the actual QML instance, including neighboring controls and the compact six-band state.

## 9. Keyboard, accessibility, semantics and implementation boundaries

**Tab and accessible behavior.** All *interactive, available* band selectors, Add/Remove, and A/B controls support standard Qt Tab navigation and Space/Enter activation according to their actual existing button semantics. A **processing-disabled** band selector is still available and focusable. Unavailable Add at six bands and unavailable Remove at one band expose their true unavailable states. Preview is informational with an accessible name/description and is not a new focusable button. Tooltip delay follows the existing desktop system/implementation, not an invented new timing constant. Do not assign extra shortcuts or change global focus order here.

**State independence.** Preview `NO_PREPARED_REALIZATION` / `RENDERING` / `READY` / `ERROR` does not control A/B selection. A and B are mutually exclusive EQ-module states and never separate presets; their visual state does not itself establish a numeric-field disable condition. Band processing-enabled status and selector interactivity remain separate. Add/Remove never retain Selected.

**Qt Quick feasibility.** Child controls can use `Rectangle`, `Text`, borders, simple `Shape`/vector PLUS/MINUS glyphs, clipped transparent state overlays, and existing or **EQ-local derived** `StudioButton` components. No raster button skin, custom shader, heavy blur, or mandatory continuous blur. Do not alter the shared `StudioButton` just to reach Board 05 dimensions. In particular, existing M12B band selector **`minimumControlWidth = 90`** is a minimum, **not** proof of exact 90-lp implicit width.

**Required local QML fit gate before implementation acceptance:**

1. Measure **actual `implicitWidth`** for the six dynamic band buttons in every sample filter label, including text metrics and selected/focus rendering; verify **90-lp target** without truncating number/filter abbreviation.
2. Measure actual Add/Remove `implicitWidth` under existing `minimumControlWidth`, icon box, icon–label gap and `contentPadding`; implement the **128-lp default and 96-lp compact variants locally** rather than changing the shared StudioButton contract.
3. Measure the actual QML layout gaps, both reserve widths, **20-lp right margin**, and separator **inside** the allotted segment; confirm the complete six-band strip footprint **904 lp default / 840 lp compact** *with actual implicit widths*, not merely hard-coded outer Rectangles.
4. Verify the **2-lp outer focus ring**, its **2-lp offset**, and neighboring-control clipping/overlap in the compact strip. It must not steal layout width or create overlap when the nominal **12 lp minimum-width reserve** is the only remaining horizontal space.
5. Exercise **one band** (Remove unavailable, Add available) and **six bands** (Add unavailable, Remove available); processing-off, selected + processing-off, and keyboard focus must remain visible and functional.
6. Test **1040 × 660** and **900 × 580** on Windows 10, including the worst measured preview-label width and A/B labels in the **48-lp Header**; test the strip in its **40-lp row**.
7. Reject clipping, overlap, missing buttons, hidden band filter labels, horizontal scrolling, text wrapping, or focus-ring loss. The artwork and mathematical budget **do not by themselves certify runtime fit**.

If actual QML measurements fail, record the exact cause and request **explicitly approved EQ-local correction**; do not silently modify Board 01 geometry, Board 02 surfaces, Board 03 typography, Board 04 graph/handles, or the shared StudioButton.

## 10. Independent integration delta and remaining authority boundary

**v1.1 reconciliation of the submitted v1.0 (no visual redesign or token/color changes):**

1. Added the **nominal responsive switch at inner width 916 lp / outer width 964 lp**, derived from the full-action width 904 lp plus a 12-lp left reserve. Compact actions apply at 852–915 lp inner width. The switch must be recalculated if actual QML text, icon or focus metrics invalidate the targets.
2. Removed a stray reference to an unrelated **68-lp Transport** control from the band-selector state section. Board 05 governs the EQ tool-window header and selector controls only, and does not create a transport hierarchy dependency.
3. Independently checked all **20** inherited/local design `#RRGGBBAA` ↔ QML `#AARRGGBB` pairs in §8.1–8.2: zero byte-order mismatches. All six newly proposed local colors preserve their original values. The exact **840 / 852** compact and **904 / 992** full-width totals are unchanged.

**Design scope is accepted/frozen for M12B only.** The 90/128/96-lp dimensions are conditional engineering targets, not proof that present QML already fits. Windows-rendered 1040×660 and 900×580, all real preview labels, one/six band cardinality, action `implicitWidth`, filter-label text, keyboard focus-ring visibility and clipping tests remain mandatory. Failure requires a narrow, explicit EQ-local reviewed correction; do not silently change Board 01–04 or shared StudioButton.

### 10.1 Implementation acceptance checklist

- [ ] Header **48 lp** and Band Strip **40 lp** remain **separate** with **12-lp** intervening gap; Preview Status is immediately **left** of A/B. Header carries **Parametric EQ / Manual Mastering**, no duplicate app logo or invented navigation.
- [ ] Only 1–6 **existing** bands are shown; every button exposes ordinal, current filter abbreviation, full-name tooltip, descriptive `Accessible.name`, selection state and independently its processing-enabled state.
- [ ] All band buttons target **90 × 32 lp**, **8-lp radius**, **8-lp inter-button gaps**; Add/Remove target **128 × 32 lp** default / **96 × 32 lp** minimum context, **8-lp radius**, no persistent selected state.
- [ ] With **six** bands, complete arithmetic is **840 lp / 852 lp = 12 lp reserve** at minimum and **904 lp / 992 lp = 88 lp reserve** at default; separator has **no hidden extra width**.
- [ ] Processing-disabled band remains selectable, keyboard-focusable and can open the Inspector; selected + processing-disabled is visibly distinct from unavailable action buttons.
- [ ] Every Add state uses **PLUS**; every Remove state uses **MINUS**, explicitly correcting the erroneous Remove-Hover PLUS in the candidate artwork.
- [ ] Four and **only four** preview statuses: `NO_PREPARED_REALIZATION`, `RENDERING`, `READY`, `ERROR`; visible `NO PREVIEW`, `RENDERING`, `READY`, `ERROR`; tooltip/accessibility preserves the full meaning. Error detail belongs in existing lower validation/status area.
- [ ] A is **EQ Active**, B is **EQ Module Bypass**; same parameters; mutually exclusive; bypass remains EQ-local and does not automatically disable parameter editing. Cyan for A, contextual amber for B.
- [ ] Board 02/03 inherited design/QML color conversions remain byte-exact; no new shared token; no changes to graph/handle identity tokens from Board 04.
- [ ] QML runtime geometry, `implicitWidth`, compact StudioButton, focus-ring clipping, one-/six-band tests and both window sizes are verified **on the running Windows build** before declaring visual implementation accepted.

**Out of scope:** no Board 01–04 changes, Board 06, new image, DSP/backend logic redesign, new runtime states, QML Implementation Handoff, global token promotion, or whole-package freeze. This manifest is submitted for **independent integration review**.
