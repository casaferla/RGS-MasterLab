RGS MASTERLAB — M12B FROZEN WOW DELIVERY FOLDER (2026-09-24)

This directory contains the exact eight current canonical design manifest versions, PO freeze decision, independently cross-board-reconciled index v1.1, and bounded agent-neutral QML implementation handoff. READ the Markdown documents before coding. Board01 local copy was transcribed from its Google Drive canonical content; definitive Board01 remains Drive file ID 1fvmY4lwh3XurzDy2Jcxnx73EniJ3-tY8Jeo68Vw-Beg. The other seven local manuscripts reproduce the scoped, pinned versions currently accepted by the PO.

How to use with Jules: extract the ZIP to a local folder, supply/upload that FOLDER if Jules accepts folder inputs, and paste `RGS_MasterLab_L1-M12B_WOW_Jules_CopyPaste_Prompt_2026-09-24.txt` in the SAME existing Jules session 9003884410820853273. Do not send only one or two screenshots: `manifests/` and the full Markdown implementation handoff are required. If the Jules UI does not allow the agent to read this folder or otherwise consume the eight manifest contents, do not start the coding pass; ask Chat to arrange another accessible handoff method.

No agent is authorized to alter the frozen design, main-shell geometry, shared palette, M12A DSP, PO gates, PR merge or M13. If measured Windows Qt layout contradicts the frozen narrow reserves, stop with measurements and request a local PO-approved delta.

Drive pointers: PO freeze decision 1qluFCpBQuV3vcjFLTChuWZpFzVkEpIJR; bounded handoff 131TH8ARliop16mBc4cLySrPvCMSk5QQU; frozen consolidated index native Google Doc 1MOLiLrG5uLv7ybMg9rCg6Kckb1C8klQbzGgjue-VyeU.
