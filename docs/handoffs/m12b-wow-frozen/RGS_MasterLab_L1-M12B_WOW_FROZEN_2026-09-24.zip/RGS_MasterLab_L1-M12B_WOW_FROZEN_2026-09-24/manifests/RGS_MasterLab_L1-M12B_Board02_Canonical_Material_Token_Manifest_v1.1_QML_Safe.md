# RGS MasterLab — L1-M12B
# BOARD 02 — CANONICAL MATERIAL TOKEN MANIFEST v1.1 — QML-SAFE

**Ambito:** esclusivamente superfici, gerarchia dei materiali e state overlays del Parametric EQ Editor.  
**Stato:** revisione tecnica dei token materiali locali completata con tabella di serializzazione Qt/QML. Il design system condiviso NON è globalmente rifrozen e il Visual WOW Package complessivo non è frozen.  
**Precedenza adottata:** in caso di differenza tra *Local EQ Tokens* e *Surface Material Specifications* della Board 02 Revised Candidate, prevale la specifica dettagliata di superficie, purché coerente con il suo materiale illustrato. Non vengono modificati Board 01, architettura, controlli o semantiche M12B.

Tutte le costanti cromatiche qui sotto sono espresse in **`#RRGGBBAA`**. `FF` significa opaco; l'ultimo byte degli overlay/highlight/shadow contiene già la rispettiva opacità. Le dimensioni sono in logical px nella reference Windows 10.

**AVVISO VINCOLANTE PER L’IMPLEMENTAZIONE:** i codici a otto cifre delle sezioni 1–4 sono **design tokens** in formato `#RRGGBBAA` e **NON devono mai essere incollati direttamente** nelle proprietà `color` di Qt Quick/QML. Qt 6 interpreta le stringhe esadecimali a otto cifre come `#AARRGGBB` (ARGB). Per ogni token usare la colonna QML della tabella in Appendice A, oppure la conversione verificata `#RRGGBBAA` → `#AARRGGBB`. La conversione cambia esclusivamente l’ordine dei byte, NON il colore, l’opacità o la gerarchia approvata.


## 1. SHARED RGS TOKENS — ereditati, non ridefiniti dall'EQ

| Token condiviso | Colore `#RRGGBBAA` | Ruolo confermato in Board 02 |
|---|---|---|
| `rgs.raw.cyan` | `#00C8FFFF` | RAW; anche accento d'interazione/focus quando previsto dalla visual authority |
| `rgs.prepared.teal` | `#00D4A7FF` | PREPARED |
| `rgs.processed.purple` | `#8B42C0FF` | PROCESSED — distinto dall'indicatore di mixed routing |
| `rgs.gold.amber` | `#F2B632FF` | GOLD; eventuale accent bypass solo dove già previsto |
| `rgs.success.green` | `#00D47AFF` | Success / Ready |
| `rgs.warning.yellow` | `#FFC107FF` | Warning — **non** sostituisce GOLD |
| `rgs.error.coral` | `#F27683FF` | Error / invalid |
| `rgs.neutral.100` | `#F5F8FCFF` | Testo primario chiaro |
| `rgs.neutral.300` | `#A1B5C9FF` | Testo secondario |
| `rgs.neutral.500` | `#62788FFF` | Testo attenuato / hints |

Questa sezione trascrive i riferimenti condivisi presenti nella Board 02: **non è una modifica della palette globale frozen**. La tinta definitiva della curva EQ e quelle dei singoli band handles non sono stabilite da questo manifesto: spettano alla successiva tavola *Response Graph + Handles*.

## 2. LOCAL EQ MATERIAL TOKENS — quattro superfici distinte

**Regola di composizione comune.** Ogni superficie ha un `base` (fallback se il gradiente non viene reso) e, nella resa canonica, un unico gradiente **verticale top → bottom**, con stop `0.0 = gradTop` e `1.0 = gradBottom`. I gradienti opachi **sostituiscono** il riempimento base: non si sommano a esso. Bordo e highlight sono disegnati sopra il riempimento; l'ombra è sotto o internamente secondo il ruolo. Due superfici possono riusare un materiale solo se condividono **l'intero** set di token, non soltanto il colore base.

### 2.1 Layer 1 — Window Frame

| Proprietà / token | Valore canonico |
|---|---|
| `eq.window.bg` | `#0A1624FF` |
| `eq.window.gradTop` | `#102338FF` |
| `eq.window.gradBottom` | `#08121CFF` |
| `eq.window.gradientDirection` | Verticale, top → bottom; stop 0.0 / 1.0 |
| `eq.window.border` | `#1E3B56FF`, **1 lp** |
| `eq.window.radius` | **8 lp** |
| `eq.window.highlightTop` | `#2A4C6833`, linea interna **1 lp** a `y = 0` |
| `eq.window.shadow` | `#00000040`; **outer**, offset X **0**, offset Y **8 lp**, blur nominale **24 lp** |

La cornice è il livello più esterno, scuro e stabile: non deve diventare il principale oggetto luminoso dell'editor.

### 2.2 Layer 2 — Editor Panel

| Proprietà / token | Valore canonico |
|---|---|
| `eq.panel.bg` | `#0F2236FF` |
| `eq.panel.gradTop` | `#17324DFF` |
| `eq.panel.gradBottom` | `#0C1A2AFF` |
| `eq.panel.gradientDirection` | Verticale, top → bottom; stop 0.0 / 1.0 |
| `eq.panel.border` | `#27465FFF`, **1 lp** |
| `eq.panel.radius` | **8 lp** |
| `eq.panel.highlightTop` | `#2A6C9F26`, linea interna **1 lp** a `y = 0` |
| `eq.panel.shadow` | `#00000033`; **inner**, offset X **0**, offset Y **2 lp**, blur nominale **8 lp** |

È il contenitore principale. `eq.panel.bg` non è un alias del materiale del graph né delle superfici di controllo.

### 2.3 Layer 3 — Control Surfaces

**Ambito del materiale:** Band Strip e Inspector; stessi token e stesso materiale in entrambe le aree. Non vengono qui specificate geometrie interne di pulsanti, segmenti, toggle o field.

| Proprietà / token | Valore canonico |
|---|---|
| `eq.control.bg` | `#12243FFF` |
| `eq.control.gradTop` | `#1C3A59FF` |
| `eq.control.gradBottom` | `#0E1F2EFF` |
| `eq.control.gradientDirection` | Verticale, top → bottom; stop 0.0 / 1.0 |
| `eq.control.border` | `#2C5A78FF`, **1 lp** |
| `eq.control.radius` | **6 lp** |
| `eq.control.highlightTop` | `#2AA0D026`, linea interna **1 lp** a `y = 0` |
| `eq.control.shadow` | `#00000033`; **inner**, offset X **0**, offset Y **1 lp**, blur nominale **4 lp** |

### 2.4 Layer 4 — Response Graph Well

**Ambito del materiale:** il *well* incassato che contiene la superficie grafica, non la curva EQ, la griglia o i band handles.

| Proprietà / token | Valore canonico |
|---|---|
| `eq.graph.bg` | `#081824FF` |
| `eq.graph.gradTop` | `#0D2A3AFF` |
| `eq.graph.gradBottom` | `#06141DFF` |
| `eq.graph.gradientDirection` | Verticale, top → bottom; stop 0.0 / 1.0 |
| `eq.graph.border` | `#1A3E55FF`, **1 lp** |
| `eq.graph.radius` | **6 lp** |
| `eq.graph.highlightTop` | `#1AA0C61A`, linea interna **1 lp** a `y = 0` |
| `eq.graph.shadow` | `#00000026`; **inner/inset**, offset X **0**, offset Y **1 lp**, blur nominale **4 lp** |

Il graph well ha un materiale **distinto** da `eq.panel.*`: è la principale superficie incassata e centrale, senza bloom decorativo.

## 3. STATE OVERLAYS — layer 5, non nuove superfici strutturali

| Token locale | Colore finale | Alpha del colore | Metodo e ambito |
|---|---|---:|---|
| `eq.overlay.focus` | `#00C8FF14` | `0x14/255 ≈ 7,8%` | Overlay locale sull'area interessata; **Source-over** |
| `eq.overlay.disabled` | `#00000066` | `0x66/255 = 40%` | Oscuramento locale del target; **Source-over** |
| `eq.overlay.error` | `#F2768314` | `0x14/255 ≈ 7,8%` | Overlay locale soltanto in un reale stato d'errore; **Source-over** |
| `eq.overlay.success` | `#00D47A14` | `0x14/255 ≈ 7,8%` | Overlay locale soltanto ove sia applicabile uno stato success; **Source-over** |
| `eq.overlay.warning` | `#FFC10714` | `0x14/255 ≈ 7,8%` | Overlay locale soltanto ove sia applicabile un warning; **Source-over** |

**Metodo deterministico:** alpha compositing standard *Source-over* (`result = overlay × α + underlying × (1 − α)` in termini di composizione alpha); nessuna modalità additiva. Renderizzare sopra il materiale della superficie bersaglio, con clipping alla sua geometria e radius. Gli overlay non modificano `base`, gradienti o border token. Non definiscono qui focus-ring geometry, microstati dei controlli, validazione o nuove semantiche runtime.

## 4. RICONCILIAZIONE DELLE DUE TABELLE DI BOARD 02

| Voce verificata | Local EQ Tokens (tabella sintetica) | Surface Material Specifications (dettaglio) | Risoluzione per questo manifesto |
|---|---|---|---|
| Window Frame Gradient Top | `#002338` | `#102338FF` | **`eq.window.gradTop = #102338FF`**: prevale la specifica dettagliata |
| Window Frame Border | `#1E3B56` | `#1E3B56FF` | **`eq.window.border = #1E3B56FF`**: RGB coerente, alpha esplicitato; 1 lp |
| Editor Panel Background | `#0F2156` | `#0F2236FF` | **`eq.panel.bg = #0F2236FF`**: prevale la specifica dettagliata |
| Altri colori base, top/bottom e bordi di Control Surfaces / Graph Well | Valori RGB riportati in sintesi | Corrispondenti valori RGBA in dettaglio | Valori completi e univoci delle sezioni 2.3–2.4 |
| Focus / Disabled overlay | `#00C8FF` / `#000000` (tinte base) | `#00C8FF14` / `#00000066` | Si adottano i valori **con alpha** del dettaglio; non sono tinte opache |
| Error / Success / Warning overlay | Non completamente esplicitati nella tabella sintetica | `#F2768314`, `#00D47A14`, `#FFC10714` | Valori con alpha del dettaglio; Source-over |

La tabella sintetica riportava anche `eq.graph.grid = #123041` come riferimento per il *grid tint*: **non è un quinto materiale né un alias di `eq.graph.bg`**. Resta un riferimento documentale, senza congelare qui colore, spessore o opacità finale della griglia; tali specifiche spettano alla board del Response Graph. Analogamente, **nessun token finale per curva EQ o band handles** viene introdotto in questo documento.

## 5. IMPLEMENTATION FEASIBILITY — Qt 6 / QML, senza dipendenze pesanti

- **Riempimento e gradienti:** `Rectangle` con `Gradient` verticale a due `GradientStop` (`0.0`/`1.0`), colori a otto cifre della sezione 2. `base` è fallback, non un secondo layer opaco sotto il gradiente.
- **Bordi e radius:** `Rectangle.border` e `radius` con i singoli valori canonici per ruolo. I corner radius sono quelli delle **superfici**, non dei controlli figli.
- **Highlight:** una sottile shape/linea interna superiore da **1 lp**, colore già comprensivo di alpha, con clip sul radius della superficie; non richiede blur.
- **Overlay:** un `Rectangle` figlio, stessa geometria/radius della superficie interessata, colore RGBA semitrasparente, composizione *Source-over* predefinita. Nessun effetto additivo o texture raster.
- **Ombre:** il manifesto registra geometria e colore dell'ombra *di riferimento*, ma una sfocatura identica al blur nominale non deve imporre `MultiEffect` costoso, shader custom né blur animati. Implementazione leggera deterministica: 1–3 `Rectangle`/`Shape` statiche scure a offset prefissati, oppure bordo interno + uno stretto gradiente verticale con il medesimo token di ombra. Per la finestra si può usare l'ombra nativa di Windows 10 quando disponibile. La versione leggera è un'approssimazione dichiarata della morbidezza, **non** una modifica del colore, dell'offset o della gerarchia approvati.
- **Nessuna prospettiva runtime:** l'esploso della Board 02 è solo esplicativo. In QML i quattro materiali restano superfici planari annidate secondo la composizione frozen di Board 01.

## 6. AUTHORITY E LIMITI DEL MANIFESTO

**Priorità all'interno di Board 02:** (1) specifiche dettagliate *Surface Material Specifications*, se coerenti con l'estetica approvata; (2) tabella sintetica *Local EQ Tokens* dove il dettaglio non contiene una voce; (3) per il *shared design system*, prevalgono sempre eventuali authority globali RGS già frozen. Nessuna sostituzione cromatica globale è introdotta qui.

**Macro-layout invariato:** finestra `1040 × 660`, minimo `900 × 580`; effective inset `24 lp`; gap `12 lp`; Header `48 lp`; Band Strip `40 lp`; Graph flessibile `324 lp` default / `244 lp` minimum; Inspector a due livelli `128 lp`; Status / Validation `24 lp`. Preview Status nell'Header immediatamente a sinistra di A/B; **nessun** PREPARED / PROCESSED / GOLD nel tool window; **MIXED ROUTING ACTIVE solo nell'Inspector**, mai duplicato nello Status / Validation strip.

**Esclusi da questo manifesto:** anatomia di pulsanti/toggle/segmentati, numeric fields, dropdown, curva EQ, band handles, stati di interazione dettagliati e motion tokens. Nessun nuovo materiale, funzione o stato backend. **Board 01 non viene modificata e Board 03 non viene prodotta.**

## APPENDICE A — Conversione deterministica dei 39 token per Qt Quick/QML

**Autorità di rappresentazione:** la colonna design `#RRGGBBAA` resta il valore di riferimento; la colonna `QML #AARRGGBB` è la stringa esatta da usare in `Rectangle.color`, `GradientStop.color` e `border.color` in Qt Quick. Nessun valore cromatico è stato cambiato.

| Token | Design `#RRGGBBAA` | QML `#AARRGGBB` |
|---|---|---|
| `rgs.raw.cyan` | `#00C8FFFF` | `#FF00C8FF` |
| `rgs.prepared.teal` | `#00D4A7FF` | `#FF00D4A7` |
| `rgs.processed.purple` | `#8B42C0FF` | `#FF8B42C0` |
| `rgs.gold.amber` | `#F2B632FF` | `#FFF2B632` |
| `rgs.success.green` | `#00D47AFF` | `#FF00D47A` |
| `rgs.warning.yellow` | `#FFC107FF` | `#FFFFC107` |
| `rgs.error.coral` | `#F27683FF` | `#FFF27683` |
| `rgs.neutral.100` | `#F5F8FCFF` | `#FFF5F8FC` |
| `rgs.neutral.300` | `#A1B5C9FF` | `#FFA1B5C9` |
| `rgs.neutral.500` | `#62788FFF` | `#FF62788F` |
| `eq.window.bg` | `#0A1624FF` | `#FF0A1624` |
| `eq.window.gradTop` | `#102338FF` | `#FF102338` |
| `eq.window.gradBottom` | `#08121CFF` | `#FF08121C` |
| `eq.window.border` | `#1E3B56FF` | `#FF1E3B56` |
| `eq.window.highlightTop` | `#2A4C6833` | `#332A4C68` |
| `eq.window.shadow` | `#00000040` | `#40000000` |
| `eq.panel.bg` | `#0F2236FF` | `#FF0F2236` |
| `eq.panel.gradTop` | `#17324DFF` | `#FF17324D` |
| `eq.panel.gradBottom` | `#0C1A2AFF` | `#FF0C1A2A` |
| `eq.panel.border` | `#27465FFF` | `#FF27465F` |
| `eq.panel.highlightTop` | `#2A6C9F26` | `#262A6C9F` |
| `eq.panel.shadow` | `#00000033` | `#33000000` |
| `eq.control.bg` | `#12243FFF` | `#FF12243F` |
| `eq.control.gradTop` | `#1C3A59FF` | `#FF1C3A59` |
| `eq.control.gradBottom` | `#0E1F2EFF` | `#FF0E1F2E` |
| `eq.control.border` | `#2C5A78FF` | `#FF2C5A78` |
| `eq.control.highlightTop` | `#2AA0D026` | `#262AA0D0` |
| `eq.control.shadow` | `#00000033` | `#33000000` |
| `eq.graph.bg` | `#081824FF` | `#FF081824` |
| `eq.graph.gradTop` | `#0D2A3AFF` | `#FF0D2A3A` |
| `eq.graph.gradBottom` | `#06141DFF` | `#FF06141D` |
| `eq.graph.border` | `#1A3E55FF` | `#FF1A3E55` |
| `eq.graph.highlightTop` | `#1AA0C61A` | `#1A1AA0C6` |
| `eq.graph.shadow` | `#00000026` | `#26000000` |
| `eq.overlay.focus` | `#00C8FF14` | `#1400C8FF` |
| `eq.overlay.disabled` | `#00000066` | `#66000000` |
| `eq.overlay.error` | `#F2768314` | `#14F27683` |
| `eq.overlay.success` | `#00D47A14` | `#1400D47A` |
| `eq.overlay.warning` | `#FFC10714` | `#14FFC107` |

**Esempi critici:**
- `eq.window.bg`: design `#0A1624FF` → QML `#FF0A1624` (opaco).
- `eq.overlay.focus`: design `#00C8FF14` → QML `#1400C8FF` (20/255 ≈ 7,8% alpha).
- `eq.window.highlightTop`: design `#2A4C6833` → QML `#332A4C68` (51/255 = 20% alpha).
- `eq.window.shadow`: design `#00000040` → QML `#40000000` (64/255 ≈ 25,1% alpha).

La colonna design RGB con alpha non è una costante QML. In Qt usare sempre la colonna QML (o `Qt.rgba(r/255,g/255,b/255,a/255)` con i medesimi canali). Non trasferire la palette globale condivisa nel codice senza prima verificare la precedenza delle authority GUI-01.

## APPENDICE B — Ambito di accettazione della revisione tecnica

La presente v1.1 preserva integralmente i valori proposti nel manifesto v1.0. La revisione certifica la **coerenza interna della serializzazione cromatica** per i 39 token, non la fedeltà pixel-per-pixel degli effetti ombra: i blur nominali restano riferimenti estetici con approssimazione leggera consentita dalla sezione 5 e da sottoporre a review visiva sull’eseguibile reale.

I 10 `rgs.*` sono riferimenti condivisi trascritti dalla board e NON promossi automaticamente ad aggiornamenti globali del design system; l’autorità GUI-01 esistente prevale. I token `eq.*` qui verificati sono specifici della proposta materiale M12B. Le board successive rimangono draft fino alla loro review dedicata.

Riferimento implementativo Qt: https://doc.qt.io/qt-6/qml-color.html (Qt Quick QML color: stringhe esadecimali #AARRGGBB).
