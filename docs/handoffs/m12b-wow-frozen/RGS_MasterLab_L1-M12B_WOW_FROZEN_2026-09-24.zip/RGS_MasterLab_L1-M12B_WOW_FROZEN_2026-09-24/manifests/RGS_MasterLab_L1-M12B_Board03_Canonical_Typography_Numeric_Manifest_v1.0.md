# RGS MasterLab — L1-M12B
# BOARD 03 — CANONICAL TYPOGRAPHY & NUMERIC FIELD TOKEN MANIFEST v1.0

**Deliverable:** text-only numerical authority accompanying **Board 03 — Typography / Readout System / Numeric Field States — Final Corrected**.  
**Scope:** typography, readouts, direct numeric-entry fields and their visual states for the Parametric EQ Editor.  
**Review status:** Board 03 has passed visual integration review; this manifest is submitted for numerical integration review. **It does not freeze the entire Visual WOW Package or promote proposed tokens to the global RGS design system.**

## 1. Authority, precedence and scope

1. **Board 01 — Composition + Dimensions:** frozen macro-geometry. Non-modal Windows tool window **1040 × 660 lp**, minimum **900 × 580 lp**; effective content inset **24 lp** all sides; four inter-section gaps **12 lp** each. Header **48 lp**, Band Strip **40 lp**, Response Graph **flexible** (**324 lp** default / **244 lp** minimum), two-tier Inspector **128 lp**, Status / Validation Strip **24 lp**. Content widths **992 lp** default / **852 lp** minimum. These values are not modified here.
2. **Board 02 — Canonical Material Token Manifest v1.1 QML-Safe:** color and material authority for the EQ. In any conflict with a color printed on Board 03, **Board 02 v1.1 wins**. Its ten `rgs.*` tokens are inherited references, *not* automatic amendments to the frozen global GUI-01 palette. EQ surfaces, overlays, structural borders and radii are unchanged.
3. **Board 03 — Final Corrected:** approved visual reference for typographic hierarchy, field states and field anatomy, subject to the explicit values below. A reduced editor illustration is contextual only and cannot supersede Board 01 or specify graph curves/handles.
4. **Implementation convention:** dimensions and font sizes are **logical px (lp)** on the Windows 10 visual baseline; use pixel-sized text rather than implicit point-size scaling. Color **design notation is `#RRGGBBAA`**; the corresponding **Qt/QML string is `#AARRGGBB`**. Never paste an eight-digit design string directly into QML.

**Authority boundary:** this document does not change DSP rules, filter/routing UI topology, shared font definitions elsewhere in GUI-01, graph/handle styling, or the horizontal positions/widths of the Inspector controls.

## 2. Font families, fallback and classification

| Token | Primary | Deterministic fallback policy | Classification | Scope/meaning |
|---|---|---|---|---|
| `rgs.font.ui.inherited` | Segoe UI | Resolve Qt's available platform-default **sans-serif** family if Segoe UI is unavailable; do not hard-require Inter | **SHARED RGS — INHERITED** | Existing Windows/UI family reference, not a global font revision |
| `rgs.font.numeric.inherited` | Consolas | On Windows: Courier New if installed; otherwise Qt platform **fixed-pitch/monospace** system family | **SHARED RGS — INHERITED** | Existing Windows numeric-entry family reference; the Region Time Editor's independent frozen specification remains unaffected |

Font availability is checked by the application/Qt font resolver. No external font package, downloadable font or mandatory Inter dependency is introduced. Windows acceptance uses Segoe UI and Consolas where installed; fallback changes glyph metrics only when a preferred family is absent and must not silently change numeric values, edit precision or macro-layout.

### 2.1 Deterministic typography tokens

All **letter-spacing** values below are in logical px; `0` means no added tracking. All colors refer to the Board 02 tokens in §7 and are applied at **100% of their token alpha** unless stated otherwise. Line-height values describe the typographic line box, **not** the height of the containing control.

| Token | Component / role | Font family | Fallback | Size (lp) | Weight | Line-height (lp) | Tracking (lp) | Color token | Alignment | Reusability |
|---|---|---|---|---:|---:|---:|---:|---|---|---|
| `eq.type.windowTitle` | Header: **Parametric EQ** | Segoe UI | Platform sans-serif | 20 | 600 | 24 | 0 | `rgs.neutral.100` | Left | **EQ-LOCAL — PROPOSED** |
| `eq.type.headerSubtitle` | Header: **Manual Mastering** | Segoe UI | Platform sans-serif | 12 | 400 | 16 | 0 | `rgs.neutral.300` | Left | **EQ-LOCAL — PROPOSED** |
| `mastering.type.sectionTitle` | Section title / Band identity | Segoe UI | Platform sans-serif | 14 | 600 | 20 | 0 | `rgs.neutral.100` | Left | **MASTERING MODULE FAMILY — PROPOSED** |
| `mastering.type.controlLabel` | FREQUENCY, GAIN, Q, contextual parameter label | Segoe UI | Platform sans-serif | 12 | 600 | 16 | 0 | `rgs.neutral.300` | Left | **MASTERING MODULE FAMILY — PROPOSED** |
| `mastering.type.secondaryLabel` | Subordinate descriptive label | Segoe UI | Platform sans-serif | 11 | 400 | 16 | 0 | `rgs.neutral.300` | Left | **MASTERING MODULE FAMILY — PROPOSED** |
| `mastering.type.numericValue` | Direct-entry value and numeric readout | Consolas | Courier New → platform monospace | 16 | 400 | 20 | 0 | `rgs.neutral.100` | Right; tabular/monospaced | **MASTERING MODULE FAMILY — PROPOSED** |
| `mastering.type.unit` | Hz, dB, dB/oct where applicable | Segoe UI | Platform sans-serif | 12 | 400 | 16 | 0 | `rgs.neutral.300` | Left | **MASTERING MODULE FAMILY — PROPOSED** |
| `mastering.type.buttonTab` | Band-selector and common button/tab label | Segoe UI | Platform sans-serif | 13 | 600 | 18 | 0 | `rgs.neutral.100` | Center | **MASTERING MODULE FAMILY — PROPOSED** |
| `mastering.type.status` | Status / Validation Strip; normal message | Segoe UI | Platform sans-serif | 12 | 400 | 16 | 0 | `rgs.neutral.300` | Left | **MASTERING MODULE FAMILY — PROPOSED** |
| `eq.type.previewStatus` | Header preview status, e.g. READY | Segoe UI | Platform sans-serif | 11 | 600 | 16 | 0 | `rgs.success.green` **only for a truthful Ready state** | Center | **EQ-LOCAL — PROPOSED** |
| `eq.type.abControl` | A / EQ Active and B / Bypass labels | Segoe UI | Platform sans-serif | 13 | 600 | 18 | 0 | `rgs.neutral.100` active; `rgs.neutral.300` inactive | Center | **EQ-LOCAL — PROPOSED** |

**Header fit:** title line **24 lp** plus subtitle line **16 lp** = **40 lp**. Reserve the remaining **8 lp** within the frozen **48 lp** header for optical vertical alignment; no wrap and no additional headline. Preview Status sits **immediately left of A/B** in the same header. A means **EQ Active**; B means **Bypass**. These are two states of the existing A/B control, not added navigation.

**Promotion policy:** the inherited `rgs.font.*` references remain subject to their original GUI-01 authority. The proposed `mastering.type.*` family may be reused in subsequent DSP/editor proposals but is **not globally frozen** by Board 03. `eq.type.*` remains local to this editor. Promotion requires separate Product Owner/design-system approval.

## 3. Numeric readout system and component anatomy

### 3.1 Field anatomy — proposed Board 03 component geometry

| Token | Exact value | Meaning |
|---|---:|---|
| `eq.numeric.labelLineHeight` | **16 lp** | Label line box; typography: `mastering.type.controlLabel` |
| `eq.numeric.labelToFieldGap` | **6 lp** | Vertical empty space after label |
| `eq.numeric.inputBoxHeight` | **28 lp** | Numeric input rectangle only |
| `eq.numeric.completeComponentHeight` | **50 lp** | **16 + 6 + 28**; label + gap + input, excluding any parent Inspector padding |
| `eq.numeric.unitTextSize` | **12 lp** | Typography: `mastering.type.unit` |
| `eq.numeric.unitLeftGap` | **8 lp** | Horizontal spacing between input edge and applicable unit label |
| `eq.numeric.valueAlignment` | **Right** | Stable right edge for values; monospace characters at fixed pitch |
| `eq.numeric.unitAlignment` | **Left** | Unit text begins after the 8-lp gap |
| `eq.numeric.valueFont` | **Consolas, 16 lp / 400 / 20-lp line** | Courier New → platform monospace fallback |
| `eq.numeric.fieldRadius` | **4 lp** | **EQ-LOCAL — PROPOSED** field-only corner radius; does not change Board 02 panel/control-surface radii |

The **28-lp input box** is not the **50-lp complete component**. Vertical text optical centering takes place *inside the input*. Its label and input fit the second tier of the frozen **128-lp, two-tier Inspector** without imposing horizontal field widths or freezing that tier's internal padding.

**Numeric formatting:** tabular/monospaced figures, stable alignment, clear separation of value and unit. Use decimal-point notation in the illustrated English UI; examples `80.0`, `0.0`, `0.707`, `0.50`. These examples are **display examples, not an input precision limit or an invented commit-rounding policy**. Preserve the raw text being edited; do not constrain the number of decimal places solely to match an illustration. Any runtime conversion/precision rules remain those of the authoritative M12B implementation.

### 3.2 Parameter–unit treatment

| Parameter | Direct editing | Unit shown outside value | Presentation rule |
|---|---|---|---|
| Frequency | Yes | `Hz` | Right-aligned value; unit left-aligned after 8 lp |
| Gain | Yes | `dB` | Signed values are permitted within actual limits |
| Q | Yes | None | Unitless |
| Shelf Slope | Yes, shelf filters only | None | Unitless direct numeric input, **not dB/oct** |
| HP/LP Slope | **No**: existing discrete choice | `dB/oct` | Discrete `6 / 12 / 18 / 24 / 36 / 48`; not a numeric-entry field |

**No artificial input precision cap.** Display precision, editing precision and parameter validity are different matters. Do not silently clamp, truncate a user's draft, or publish a parameter value while its text is invalid.

## 4. Numeric-field visual states — deterministic EQ-local proposal

The states below use **only existing Board 02 colors/material references** except the explicitly identified EQ-local field tokens in §4.1. These describe *field visuals*, not newly defined runtime conditions. The structural `eq.control.*` material for Band Strip/Inspector is unchanged.

### 4.1 EQ-local field tokens proposed by Board 03

| Token | Design `#RRGGBBAA` | QML `#AARRGGBB` | Purpose and authority |
|---|---|---|---|
| `eq.field.bg` | `#0E1F2EFF` | `#FF0E1F2E` | **EQ-LOCAL — PROPOSED** flat inset input; reuses the **color** of `eq.control.gradBottom`, not its full panel material |
| `eq.field.hoverBorder` | `#00C8FF59` | `#5900C8FF` | **EQ-LOCAL — PROPOSED** 35%-alpha interaction-cyan hover border; subordinate to focused cyan |
| `eq.field.selectionBg` | `#00C8FF40` | `#4000C8FF` | **EQ-LOCAL — PROPOSED** 25%-alpha selection highlight within edit text |
| `eq.field.disabledText` | `#62788F99` | `#9962788F` | **EQ-LOCAL — PROPOSED** `rgs.neutral.500` at 60% alpha in an abstract Disabled specimen only |

These are **local field-specific treatments**, not new shared `rgs.*` palette entries or replacement materials for Board 02. Their compositing mode, where alpha is below FF, is ordinary **Source-over**. No bloom, persistent blur or additive mode.

### 4.2 State specification

| State | Text color | Background | Border color / width | Applicable overlay | Focus / caret treatment |
|---|---|---|---|---|---|
| **NORMAL** | `rgs.neutral.100` `#F5F8FCFF` | `eq.field.bg` `#0E1F2EFF` | `eq.control.border` `#2C5A78FF`, **1 lp** | None | No focus border, no caret shown |
| **HOVER** | `rgs.neutral.100` `#F5F8FCFF` | `eq.field.bg` | `eq.field.hoverBorder` `#00C8FF59`, **1 lp** | None | No focus border; no caret solely due to hover |
| **FOCUS / EDITING** | `rgs.neutral.100` `#F5F8FCFF` | `eq.field.bg` | `rgs.raw.cyan` `#00C8FFFF`, **2 lp** | `eq.overlay.focus` `#00C8FF14`, **Source-over**, clipped to input | **2-lp cyan caret** while editing; when text is selected, use `eq.field.selectionBg`, keep characters legible; focus must be visible without relying on a diffuse glow |
| **INVALID DRAFT** | `rgs.error.coral` `#F27683FF` | `eq.field.bg` | `rgs.error.coral` `#F27683FF`, **1 lp** | `eq.overlay.error` `#F2768314`, **Source-over**, clipped to input | Raw invalid draft **remains visible**; if editing retains focus, the caret remains legible; error border takes priority over normal/hover border; no automatic commit |
| **DISABLED — ABSTRACT VISUAL SPECIMEN** | `eq.field.disabledText` `#62788F99` | `eq.field.bg` | `eq.control.border` `#2C5A78FF`, **1 lp**, subdued by overlay | `eq.overlay.disabled` `#00000066`, **Source-over**, clipped to input/background/border; draw legible muted text above overlay | No editing caret; **visual library specimen only**, without invented runtime applicability |

**Priority for simultaneous pointer and keyboard conditions:** focused/invalid border takes precedence over hover; invalid takes precedence for error identification; disabled overrides interactive presentation **only if a separately established runtime state actually disables that field**. Ordinary Bypass is **not** such a condition.

**Material policy:** the field-only flat inset is a proposed child treatment, not a fifth Board 02 structural material. Do not replace the Inspector's vertical gradient, structural border, radius or shadow with field values. The design of buttons, toggles and segmented controls is out of scope.

## 5. Canonical color crosswalk — verified against Board 02 v1.1

All rows below reproduce the Board 02 **design values**, not RGB sampled from a generated image. Conversion: for design `#RRGGBBAA`, Qt/QML requires `#AARRGGBB` (move the trailing alpha byte to the front without changing any byte).

| Meaning | Canonical token | Design `#RRGGBBAA` | Qt/QML `#AARRGGBB` |
|---|---|---|---|
| Primary Text | `rgs.neutral.100` | `#F5F8FCFF` | `#FFF5F8FC` |
| Secondary Text | `rgs.neutral.300` | `#A1B5C9FF` | `#FFA1B5C9` |
| Muted Text | `rgs.neutral.500` | `#62788FFF` | `#FF62788F` |
| Interaction Cyan | `rgs.raw.cyan` | `#00C8FFFF` | `#FF00C8FF` |
| Prepared Teal | `rgs.prepared.teal` | `#00D4A7FF` | `#FF00D4A7` |
| Success Green | `rgs.success.green` | `#00D47AFF` | `#FF00D47A` |
| Warning Yellow | `rgs.warning.yellow` | `#FFC107FF` | `#FFFFC107` |
| Error Coral | `rgs.error.coral` | `#F27683FF` | `#FFF27683` |
| Processed Purple | `rgs.processed.purple` | `#8B42C0FF` | `#FF8B42C0` |
| Gold Amber | `rgs.gold.amber` | `#F2B632FF` | `#FFF2B632` |

**Additional Board 02 colors referenced by field states:**

| Token | Design `#RRGGBBAA` | Qt/QML `#AARRGGBB` | Field use |
|---|---|---|---|
| `eq.control.gradBottom` | `#0E1F2EFF` | `#FF0E1F2E` | Color reference for proposed `eq.field.bg` |
| `eq.control.border` | `#2C5A78FF` | `#FF2C5A78` | Normal field border |
| `eq.overlay.focus` | `#00C8FF14` | `#1400C8FF` | Focus overlay |
| `eq.overlay.error` | `#F2768314` | `#14F27683` | Invalid-draft overlay |
| `eq.overlay.disabled` | `#00000066` | `#66000000` | Abstract disabled overlay |

The **local** new color values in §4.1 use the same verified byte permutation. No new `rgs.*` color is introduced. GOLD and Warning stay distinct; PROCESSED is not interchangeable with the contextual Mixed Routing indication. Curve and individual band-handle colors remain reserved for **Response Graph + Handles**.

## 6. Parameter validity, precision and applicability

### 6.1 Actual M12B validity limits

| Parameter | Authoritative valid range / permitted choices | Parameter kind | Example (not a precision constraint) |
|---|---|---|---|
| Frequency | **20 Hz ≤ Frequency ≤ min(20000 Hz, 0.45 × Fs)** | Direct numeric entry; upper bound sample-rate dependent | `Fs = 44100 Hz` ⇒ **max = 19845 Hz** |
| Gain | **−18.0 dB ≤ Gain ≤ +18.0 dB** | Direct numeric entry | `0.0 dB` |
| Q | **0.10 ≤ Q ≤ 12.0** | Direct numeric entry, unitless | `0.707` |
| Shelf Slope | **0.10 ≤ Shelf Slope ≤ 1.0** | Direct numeric entry, unitless | `0.50` |
| HP/LP Slope | **6 / 12 / 18 / 24 / 36 / 48 dB/oct** | Discrete selection, **not** direct numeric entry | `24 dB/oct` |

These are inclusive numeric limits; HP/LP choices are the six enumerated options. For frequency at 44.1 kHz: `0.45 × 44100 = 19845`, and `min(20000, 19845) = 19845 Hz`. No implicit rounding or artificially fixed 20-kHz maximum where the sample-rate-dependent limit is lower.

**Precision contract:** the example decimal formatting shown in the Board 03 artwork is *presentation only*. The validity intervals do not imply a fixed number of input decimal places. Raw editing text is retained until validated/committed or canceled; actual parse, serialization, processing precision and any presentation normalization remain governed by the existing authoritative M12B implementation, not invented here. No silent clamping.

### 6.2 Parameter visibility per selected filter

| Filter | Exactly visible parameter controls in the Inspector |
|---|---|
| **Bell** | **Frequency + Gain + Q** |
| **Notch** | **Frequency + Q** |
| **Low Shelf** / **High Shelf** | **Frequency + Gain + Shelf Slope** |
| **High Pass** / **Low Pass** | **Frequency + HP/LP Slope** |

A non-applicable parameter's control is **hidden** by the real M12B editor; it is **not** automatically rendered as a gray disabled field. In particular, the Board 03 contextual **Bell** example shows **only Frequency, Gain and Q**, with no Shelf Slope or HP/LP Slope label, field or placeholder gap. MIXED ROUTING ACTIVE, when truthful, appears **only within the Inspector**; it is not duplicated in the bottom Status / Validation Strip.

## 7. Direct numeric-entry interaction contract — existing M12B semantics

1. **Invalid raw text remains visible** while the user is editing and must receive the Invalid Draft visual treatment. Do not silently replace, clamp or normalize it merely because it falls outside the permitted range.
2. **Invalid draft must not publish a change to the committed DSP parameter.** Committed state and current edit draft remain distinct.
3. **Enter** commits **valid** input. Invalid input remains an uncommitted visible draft.
4. **Valid focus-out** commits valid input; invalid focus-out does not publish an invalid change.
5. **Escape** cancels editing and restores the previously committed value and its normal presentation.
6. **No Apply/Cancel workflow; no silent clamping.** No new backend state or QML DSP validation is specified by this manifest.
7. **Bypass (B)** disables EQ processing, **not** numeric editability as a general rule. Disabled visuals only represent separately established, actually applicable conditions.

## 8. Implementation and acceptance boundaries

- Implement fonts with the stated families/availability fallbacks. Font sizes are **lp/pixel-sized**; preserve the approved line boxes/tracking rather than relying on a renderer's implicit line-height. Consolas supplies monospaced numeric alignment; don't infer numerical precision from its glyph width.
- For eight-digit colors, use the **Qt/QML column**, or explicitly convert `#RRGGBBAA → #AARRGGBB`. Never paste the design-column value directly into Qt Quick's `color`/`border.color`.
- Implement field backgrounds, borders and clipped overlays with lightweight Qt Quick primitives; no mandatory custom shader or continuous expensive blur. The proposed field-only tokens in §4.1 do not supersede Board 02 structural surfaces.
- At **900 × 580**, preserve Board 01's minimum **244-lp graph**, the **128-lp two-tier Inspector**, and visibility of all filter/routing options and applicable parameter inputs. This document does **not** freeze the Inspector's final horizontal control widths/spacing; those belong to its dedicated board.
- Header typography must remain inside **48 lp** and leave the Preview Status immediately before A/B. The tool window has no PREPARED / PROCESSED / GOLD control strip.
- The bottom **24-lp** strip presents actual validation/preview errors or an authorized neutral state, never a duplicate MIXED ROUTING ACTIVE badge.
- **Out of scope:** Board 01/Board 02 changes, response-curve/handle colors or geometry, final graph grid, detailed controls and animations, new runtime conditions, full-editor redraw, QML implementation handoff or global design-system freeze.

**Integration-review gate:** this v1.0 manifest is the proposed numerical/typographic companion to visually approved Board 03. It is not a declaration that the entire L1-M12B Visual WOW Package is frozen.
