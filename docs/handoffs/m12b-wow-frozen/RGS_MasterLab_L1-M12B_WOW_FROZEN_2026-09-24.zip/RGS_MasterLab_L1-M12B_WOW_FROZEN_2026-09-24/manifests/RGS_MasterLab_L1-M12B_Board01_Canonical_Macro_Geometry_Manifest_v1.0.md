RGS MasterLab — L1-M12B Board 01 Canonical Macro Geometry Manifest v1.0

Status: PRODUCT OWNER APPROVED / FROZEN for M12B macro geometry only.
Prepared from Board 01 Independent Review v0.1, specifically approved §§11 and 13, 23 September 2026. This document consolidates already approved decisions; it does not introduce a new design or independently certify implementation.
Parent authority: latest explicit PO decisions; accepted GUI-01 frozen scope for the main application shell; M12B accepted functional/technical contract. This manifest governs ONLY the separate, bounded, non-modal Parametric EQ tool-window macro composition.

1. Window and inner content geometry

Default outer EQ tool-window size: 1040 × 660 logical px.
Minimum outer EQ tool-window size: 900 × 580 logical px.
Effective content inset: 24 logical px on each of four sides. Existing design rationale: 8px outer window/editor inset + 16px editor/content inset; this decomposition is explanatory, while 24px effective inset is the frozen geometric requirement.
Default inner width: 1040 − 48 = 992 px; default inner height: 660 − 48 = 612 px.
Minimum inner width: 900 − 48 = 852 px; minimum inner height: 580 − 48 = 532 px.
At both default and minimum sizes, content must remain readable and functionally accessible. No horizontal clipping, missing essential controls or horizontal scrolling are accepted. This is an IMPLEMENTATION ACCEPTANCE REQUIREMENT, not a claim already verified by a static drawing.

2. Five-section vertical macro stack (top to bottom)

1 — Header: fixed 48 logical px.
2 — Band Selector Strip: fixed 40 logical px.
3 — Response Graph working surface: FLEXIBLE; expected 324 logical px at default size and 244 logical px at minimum size.
4 — Selected-Band Inspector: fixed macro height 128 logical px, BELOW graph, two-tier arrangement.
5 — Status / Validation Strip: fixed 24 logical px.
Inter-section gap between adjacent sections: 12 logical px each; 4 gaps total = 48px.
Default vertical sum: 48 + 40 + 324 + 128 + 24 + 48(gaps) = 612px inner content height.
Minimum vertical sum: 48 + 40 + 244 + 128 + 24 + 48(gaps) = 532px inner content height.
At the approved minimum size graph height 244px remains above current technical graph minimum 240px. Any future change needs a specific reviewed forward delta, not a contradictory later-board drawing.

3. Horizontal macro constraints

Every section—Header, Band Strip, Graph, Inspector and Status/Validation—fills the inner content width: 992px default, 852px minimum.
No section or contained control group may rely on more than 852px of total usable row width at the 900px outer minimum, including labels, controls, separators and ALL gaps.
The dynamic 1..6 Band Strip and Add/Remove actions must remain fully visible without horizontal scrolling at both cardinalities. Exact selector and action widths are NOT frozen in Board01; Board05 owns detailed controls and arithmetic.
The two-tier Inspector must show the currently applicable controls without overflow at the minimum window. Exact control widths and flow layout belong to the Inspector Controls board, not Board01.
Response Graph is the dominant working surface; its plot padding, axis gutters and handle-hit areas are specified separately by approved Board04, which may not change the overall graph section height.

4. Macro placement and scope boundaries

HEADER 48px: left aligned 'Parametric EQ' and subordinate 'Manual Mastering'; current Preview Status badge immediately to the left of A/B controls on the right. Header must NOT include PREPARED / PROCESSED / GOLD navigation or additional app branding/chrome. Native Windows window-caption controls remain the window host's responsibility, not fake controls drawn inside the editor.
BAND STRIP 40px: only currently existing 1..6 bands in canonical order, with Add Band and Remove Band controls, optional compact BANDS label, and no placeholders for absent bands. This row is SEPARATE from Header; preserve the 12px gap.
GRAPH: below band strip, above inspector; its contents are governed by Board04. The Board01 artwork curve is schematic only: actual selected-band-only C++ selectedBandResponsePoints may not be replaced by a fabricated aggregate curve, especially in mixed routing.
INSPECTOR 128px TWO-TIER: upper tier contains selected-band identity/enable, Filter, Routing and contextual Mixed Routing placement; lower tier contains numeric/contextual parameter entry. Layout preserves M12B behavior, exact microgeometry and applicable controls governed by dedicated Inspector Controls board.
STATUS/VALIDATION 24px: region reserved for validation and preview-error presentation, may be empty when no issue. The image's 'Parametric EQ ready.' is an illustration, NOT a mandatory persistent message. Do not duplicate contextual MIXED ROUTING ACTIVE here.
Unsupported illustrative Board01 combination 'Bell + Shelf Slope 24 dB/oct' is explicitly NON-AUTHORITATIVE. Only actual filter-specific controls are allowed under the accepted functional contract.

5. Authority and implementation gate

BOARD01 FROZEN AUTHORITY: all numeric macro window/section/inset/gap values and the placement/structure constraints recorded above.
NOT FROZEN BY BOARD01: individual control widths/heights, detailed button states, gradients and material palette, font and numeric-field specs, graph curve/handle color or geometry, filter-specific Inspector internal dimensions, animations and icons. Accepted later boards and manifests govern each of these within their own scopes.
Static board image + this manifest are DESIGN AUTHORITIES; they are not evidence that present PR#8 QML already implements the WOW geometry. Jules implementation, Windows focused tests, 900×580 visual/pointer no-clipping verification, Windows Full, human Gate M/L and explicit merge authorization remain separate later steps.
Reuse classification: the EQ window macro composition is M12B EQ-LOCAL and must not silently become a shared global window default. Broader material/type/control tokens from other boards may be candidates for cross-milestone promotion under the separate Visual Design System directive.
Priority if discrepancy: latest explicit PO/frozen decisions and this scoped canonical manifest prevail over minor art discrepancies; no later board may silently edit the already frozen macro geometry.

6. Sources and continuity

Board01 Independent Review (approved geometry §§11,13): https://docs.google.com/document/d/1o8XNl0rTSVDP7-m82KMHDcjv7p-mhXupOFbch1LHS40/edit
Reusable cross-milestone visual directive: https://docs.google.com/document/d/1cQOnC-kBNSPn_bHiZlmQ_BHm_vYOrAR7P5g6qua3zok/edit
Board02 accepted EQ-local material manifest v1.1 QML-safe: Drive ID 1VrGCJgVRx_vPdlFvqCxwUck08YeDW69A.
Board03 accepted typography/numeric manifest v1.0: Drive ID 19ilTo0KuiYguN7cGBN-T83NPM7yfHcWQ.
Board04 accepted graph/handles manifest v1.1: Drive ID 1qJW-hRyw4M67EpZ49zKryDcuB9W_g0zx.
Board05 revised graphic is in review, no canonical manifest yet. Boards06–08 have not been accepted; do not invent their canonical manifests.
END — Board01 Canonical Macro Geometry Manifest v1.0.
