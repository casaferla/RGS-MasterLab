# RGS MasterLab — L1-M12B Visual WOW Package — Product Owner Freeze Decision v1.0

**Date:** 2026-09-24  
**Decision:** **PO-FROZEN — EIGHT-BOARD DESIGN TARGET ONLY.**  
**PO authorization:** “Va bene. Procedi.” in immediate reply to the independently reconciled Board08 v1.1 and eight-board index, following the assistant's explicit request for PO permission to freeze all eight boards and prepare a bounded Jules implementation task.  
**Product:** RGS MasterLab — Reference Guided Sound — Gold Reference Mastering Environment. Windows 10/11 x64 primary. 

## Exact frozen manifest identities

| Board | Scope | Version | Canonical Google Drive file ID |
|---|---|---|---|
| 01 | Macro EQ tool-window geometry | v1.0 | `1fvmY4lwh3XurzDy2Jcxnx73EniJ3-tY8Jeo68Vw-Beg` |
| 02 | Studio Slate materials / QML-safe colors | v1.1 QML-Safe | `1VrGCJgVRx_vPdlFvqCxwUck08YeDW69A` |
| 03 | Segoe UI/Consolas, numeric fields | v1.0 | `19ilTo0KuiYguN7cGBN-T83NPM7yfHcWQ` |
| 04 | Graph/handles/selected C++ response | v1.1 Integration Reconciled | `1qJW-hRyw4M67EpZ49zKryDcuB9W_g0zx` |
| 05 | Band selector, preview, A/B | v1.1 Integration Reconciled | `13N8VgTWLawJm2aadAI7KBKc-OTIQLNDA` |
| 06 | Two-tier Inspector/filter/routing/numerics | v1.1 Integration Reconciled | `1HbNBx1SKCVHdq-gQDiDmC6yp7LdUYOya` |
| 07 | Mixed Routing/validation/motion | v1.1 Integration Reconciled | `1IBiXJFUvNxGV17UyaquAlCkF0Zda2Pdo` |
| 08 | Complete integrated composition | v1.1 Integration Reconciled | `1G0sfoqw-wkhfWqf8w7tRmSU6cZwp5oCb` |

**Consolidated pre-freeze technical authority index**: Drive raw Markdown `1qvmDEqLkWDiIHWGS8rq43eYPlkIWrPEQ` (v1.0, previously READY FOR PO FREEZE). The present decision is its package-wide freeze addendum; the new consolidated index v1.1 is the entry point for this and later chats.

## Normative hierarchy

- Latest explicit PO frozen choice and accepted M12 functional/technical contract remain superior to decorative interpretation. Each numbered board owns its domain; Board08 composes but does not override 01–07. This package freezes the eight **specific canonical manifests**, not every older candidate visual or historical draft.
- Full-resolution Board01 final and Board08 final images are **illustrative references**. In particular, Board08's miniature omitted LEFT, and its older explanatory notes incorrectly described Remove Band and Mixed Routing; those details are explicitly superseded by Board08 v1.1. The exact eight manifests, not image pixels or AI-rendered text, govern dimensions, QML color strings and functional states.
- The eight-board pack is EQ-editor visual design. SHARED RGS inherited typography/material tokens and separately scoped MASTERING MODULE FAMILY reusable proposals may inform subsequent milestones; all EQ-LOCAL dimensions, handle identities, Mixed colors and composition require separate scoped adoption elsewhere. No silent application-wide theme rewrite.
- No invented combined curve, spectrum analyzer, new backend state, Level Match, presets, global PREPARED/PROCESSED/GOLD selector inside the tool window or DSP changes.

## What is frozen versus not yet accepted

**PO-FROZEN NOW:** complete L1-M12B Visual WOW eight-board design and its deterministic token/geometry/semantics hierarchy.

**NOT accepted by this decision:** Qt implementation, measured real Windows fit, screenshot-perfect WOW realization, CI of future edits, Windows Full, staged Release, PO Gate M usability/visual interaction, PO Gate L audio listening, merge or M13. A green pre-WOW PR CI is not evidence that the WOW renderer already exists.

**Allowed next action:** bounded, agent-neutral WOW/QML visual implementation in the **same Draft PR #8 and same existing Jules task/session**, using the enclosed deterministic task and all eight frozen manifests. No creative redesign by the coding agent. Keep PR Draft and unmerged. Distinct PO approval is required before any proposed measured EQ-local geometry delta, Windows Full gate, or merge as prescribed by the existing workflow.

**At baseline inspection:** GitHub `casaferla/RGS-MasterLab`, Draft PR #8 `draft/m12b-parametric-eq-editor-window-9003884410820853273`, reviewed HEAD `5676505f586738d29349b3a2f4907ba011575141`, base `8f1b8d5f6ce2c2ba08b3c82eae6b3010cd50998b`; PR Focused CI run **#48**, run ID `35820585028`, Windows Focused build, UI smoke, tests and visual artifact **green**, Linux Portable guard **green**. Recheck HEAD and current status before edits.

**Runtime hard gate:** demonstrate real Windows editor at 1040×660 and 900×580 Qt logical px. Insist on five visible routing buttons (including LEFT), Mixed badge when true and precise 7/12-lp Inspector reserves, selected-band-only response from C++, uncut handle/focus overlays, coherent typography and premium Studio Slate treatment. If measured Qt implicit metrics or native decoration contradict target, stop, report measurements and request PO-approved narrow EQ-local delta; do not hide controls or silently resize frozen geometry.

**Status transition:** package design PO-FROZEN; Jules WOW implementation AUTHORIZED TO START after deterministic handoff is delivered. M12B implementation remains OPEN. M13 remains BLOCKED until M12B merged after PO gates.
