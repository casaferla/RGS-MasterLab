# RGS MasterLab — L1-M12B
# BOARD 08 — CANONICAL FINAL INTEGRATED PARAMETRIC EQ EDITOR COMPOSITION MANIFEST v1.1 — INTEGRATION RECONCILED

**Tipo:** manifesto testuale canonico di composizione integrata del Parametric EQ Editor.  
**Baseline visiva:** Board 08 — *Final Precision-Corrected Candidate*, accettata come riferimento compositivo **con le tre correzioni normative delle §§ 2, 6 e 12 di questo manifesto**.  
**Piattaforma di accettazione:** Windows 10/11 x64; baseline visuale e gate dimensionale Windows 10 con Qt 6 / Qt Quick / QML. Nessuna estensione dello scope ai sistemi Apple.  
**Unità:** `lp` = logical pixels, salvo diversa indicazione.  
**Stato:** **independent cross-board integration review PASS — SCOPED BOARD 08 DESIGN ACCEPTED**, con chiarimenti integrativi puntuali in questo documento. I target dimensionali NON costituiscono prova di corretto rendering nell'eseguibile Windows. Il freeze dell'intero Visual WOW Design Package è un gate di consolidamento distinto, non automaticamente attestato dalla sola Board 08.

## 1. Autorità, precedenza e ambito

La Board 08 **compone** i contratti precedenti: non li sostituisce, non ridisegna i componenti e non crea proprietà del ViewModel, funzioni DSP, controlli o navigazioni.

| Autorità | Materia vincolante | Ruolo per Board 08 |
|---|---|---|
| **Board 01 — Canonical Macro Geometry v1.0** | Finestra, inset, cinque sezioni, altezze, quattro gap, dimensioni default e minimum | **FROZEN**, nessuna modifica |
| **Board 02 — Canonical Material Tokens v1.1 QML-Safe** | Studio Slate, materiali strutturali, gradienti, border/radius, highlight/shadow, colori condivisi | **Ereditata**, nessuna sostituzione |
| **Board 03 — Canonical Typography & Numeric Fields v1.0** | Segoe UI, Consolas, metrica dei campi, testo, unità, focus/editing/invalid | **Ereditata**, nessuna sostituzione |
| **Board 04 — Canonical Graph & Handles v1.1 Integration Reconciled** | `plotRect`, assi/griglia, risposta della sola banda selezionata, curve/fill e sei identità/handle | **Ereditata**, nessuna nuova curva o regola DSP |
| **Board 05 — Canonical Band Selector / Preview Status / A-B v1.1 Integration Reconciled** | Header, Band Strip, selector dinamici, Add/Remove, quattro preview state, A/B, varianti dimensionali | **Ereditata**, nessun nuovo controllo |
| **Board 06 — Canonical Inspector Controls v1.1 Integration Reconciled** | Inspector a due livelli, Filter, Routing, Band Enabled, Mixed badge envelope, applicabilità e slope | **Ereditata**, nessuna nuova disposizione funzionale |
| **Board 07 — Canonical Mixed Routing / Validation / Global States / Motion v1.1 Integration Reconciled** | Condizione derivata `mixedRouting`, pigmenti del badge, error precedence, motion/reduced motion | **Ereditata**, nessun nuovo stato backend |
| **Board 08 — Final Precision-Corrected Candidate** | Inquadratura e proporzioni della composizione complessiva, modello default e minimum | Riferimento **visivo**, subordinato ai manifesti e alle correzioni di questo documento |

**Precedenza:** per ogni dettaglio vince il manifesto canonico della Board proprietaria del componente; le immagini sono esempi e non sorgenti di valori, stati, coordinate o regole runtime. I riferimenti `v1.1 Integration Reconciled` restano autoritativi nelle relative aree; Board 08 non tenta di ricostruire o sostituire eventuali delta integrativi mediante lettura delle immagini. I valori ripetuti qui sono solo quelli necessari a verificare la composizione, non nuovi token globali.

**Colori a otto cifre:** nel design `#RRGGBBAA`; nelle proprietà Qt/QML `#AARRGGBB`. Per i materiali ereditati utilizzare **le conversioni QML-Safe della Board 02**, senza leggere i colori dai pixel della tavola.

**Ambito:** singola finestra non modale del Parametric EQ Editor del modulo Manual Mastering; Windows desktop. Sono fuori scope la Main Window, la sua barra menu, l'audition target globale, altri moduli DSP, Analyzer, spectrum, nuovi backend state, QML implementation code e redesign delle Boards 01–07.

## 2. Tre correzioni normative all'immagine Board 08

Queste correzioni hanno **precedenza obbligatoria** sull'ultima immagine, anche quando un particolare rappresentato graficamente sembri diverso:

| ID | Incongruenza illustrativa | Contratto corretto |
|---|---|---|
| **B08-CORR-A — Routing minimo** | Nella preview 900 × 580 è stato omesso `LEFT`. | Le opzioni visibili sono **esattamente cinque, sempre nello stesso ordine: STEREO · MID · SIDE · LEFT · RIGHT**. Con `mixedRouting = true` compare anche **un solo** badge `MIXED ROUTING ACTIVE`, dopo i cinque segmenti, all'interno della Routing subrow. La compatibilità effettiva richiede verifica Qt/QML; non occultare LEFT per simulare il fit. |
| **B08-CORR-B — Remove Band** | La nota dell'immagine collega impropriamente la rimozione all'esistenza di almeno due bande *Enabled*. | **Remove Band è disponibile quando esistono almeno due bande**, indipendentemente dal loro stato `Enabled`. È disabilitato con **una sola banda esistente**. **Add Band è disabilitato con sei bande esistenti**. |
| **B08-CORR-C — Mixed Routing** | Una nota suggerisce che siano sufficienti due bande abilitate. | `mixedRouting` è una proprietà **derivata** dal ViewModel ed è `true` solo quando **almeno due bande abilitate, con parametri confermati, utilizzano modalità Routing differenti**. Il badge è **unico, non interattivo**, collocato nella Routing subrow dell'Inspector; non si trova nella Status Strip. |

Nessuna delle tre correzioni autorizza un nuovo layout, un nuovo controllo o una modifica ai sette manifesti precedenti. **L'immagine minima con LEFT mancante non è il riferimento funzionale per l'implementazione.**

## 3. Macro-geometria frozen e verifica aritmetica

| Proprietà | Default | Minimum | Autorità |
|---|---:|---:|---|
| Finestra esterna (tool window) | **1040 × 660 lp** | **900 × 580 lp** | Board 01 |
| Inset effettivo per lato | **24 lp** | **24 lp** | Board 01: 8 lp Window → Editor + 16 lp Editor → Content |
| Content rectangle interno | **992 × 612 lp** | **852 × 532 lp** | Dimensioni finestra meno 48 lp per asse |
| Header | 48 lp | 48 lp | Board 01 |
| Band Selector Strip | 40 lp | 40 lp | Board 01 |
| Response Graph | **324 lp** | **244 lp** | Board 01; sola sezione flessibile |
| Selected-Band Inspector | 128 lp | 128 lp | Board 01 |
| Status / Validation Strip | 24 lp | 24 lp | Board 01 |
| Gap tra sezioni adiacenti | 4 × 12 = **48 lp** | 4 × 12 = **48 lp** | Board 01 |
| **Somma sezioni + gap** | **612 lp** | **532 lp** | Verifica sotto |
| **Somma + top/bottom inset** | **660 lp** | **580 lp** | Verifica sotto |

**Default:** `48 + 12 + 40 + 12 + 324 + 12 + 128 + 12 + 24 = 612 lp`; `612 + 2 × 24 = 660 lp`. Larghezza: `1040 − 2 × 24 = 992 lp`.

**Minimum:** `48 + 12 + 40 + 12 + 244 + 12 + 128 + 12 + 24 = 532 lp`; `532 + 2 × 24 = 580 lp`. Larghezza: `900 − 2 × 24 = 852 lp`.

Nessun bordo, separatore già incluso o spazio decorativo viene sommato nuovamente a questi budget. Il graph deve occupare **tutta l'altezza flessibile assegnata**: `graphHeight = innerContentHeight − (48 + 40 + 128 + 24 + 4 × 12) = innerContentHeight − 288 lp`. Con la finestra alla misura minima assegnata, **non scende sotto 244 lp**. Non introdurre un Inspector laterale, stacking responsivo alternativo né uno scroll orizzontale.

## 4. Composizione integrata e vincoli di contenimento

Ordine verticale **unico**, a piena larghezza del content rectangle:

1. **HEADER**, 48 lp.
2. Gap vuoto, 12 lp.
3. **BAND SELECTOR STRIP**, 40 lp.
4. Gap vuoto, 12 lp.
5. **RESPONSE GRAPH**, altezza flessibile; working surface dominante.
6. Gap vuoto, 12 lp.
7. **SELECTED-BAND INSPECTOR**, 128 lp, **sotto il graph**, con due tier.
8. Gap vuoto, 12 lp.
9. **STATUS / VALIDATION STRIP**, 24 lp, **esterna** all'Inspector.

Le cinque regioni coincidono orizzontalmente con il content rectangle della finestra (992 lp default, 852 lp minimum). Il loro material/layer treatment è quello ereditato, senza introdurre superfici supplementari o reinterpretare la finestra come Main Window. Il Graph Well resta il centro operativo, seguito per importanza dai controlli decisionali; cornice e barra inferiore rimangono subordinate.

La Board 08 illustra una sola configurazione EQ alle due dimensioni. Le variazioni responsive autorizzate qui riguardano **l'altezza del graph** e **la larghezza/label dei pulsanti Add/Remove**; non cambiano ordine, significato, tipografia di base o numero dei controlli reali.

## 5. Header — 48 lp

| Collocazione | Elemento | Semantica/autorità |
|---|---|---|
| Sinistra, prima linea | `Parametric EQ` | Titolo Segoe UI, **20 lp / 600 / line-height 24 lp** (Board 03) |
| Sinistra, seconda linea | `Manual Mastering` | Sottotitolo Segoe UI, **12 lp / 400 / line-height 16 lp** (Board 03) |
| Destra, immediatamente prima di A/B | **Preview Status** | Badge informativo della Board 05; nessun controllo di preview aggiuntivo |
| Destra | **A — EQ Active** | Stato di modulo `setBypass(false)` |
| Destra | **B — EQ Module Bypass** | Stato di modulo `setBypass(true)` |

I quattro stati backend previsti dal relativo contratto sono `NO_PREPARED_REALIZATION`, `RENDERING`, `READY`, `ERROR`, con etichette visibili rispettivamente **NO PREVIEW**, **RENDERING**, **READY**, **ERROR**. Se il contesto applicativo possiede un valore iniziale interno `IDLE`, esso **si presenta come NO PREVIEW**: ciò non introduce una quinta etichetta o un nuovo stato visuale della Board 05.

**Specimen integrato:** Preview `READY`, **A selezionato** (trattamento cyan), **B non selezionato** (trattamento neutro). A e B sono mutuamente esclusivi, rappresentano gli stessi parametri EQ e non sono preset/snapshot indipendenti. Il bypass riguarda il modulo EQ, non GOLD e non l'intera applicazione; non rende automaticamente immodificabili i parametri. Preview Status e A/B restano informazioni indipendenti; il cambio A/B può richiedere un nuovo render della preview secondo la logica esistente, non un nuovo stato inventato.

Il gruppo titolo/sottotitolo deve rimanere leggibile anche con 852 lp di larghezza interna. Il badge preview precede **immediatamente** A/B e non compare in altre regioni. Nessun logo RGS duplicato, menu File/Edit/View/Transport/Help, app chrome fittizio o PREPARED/PROCESSED/GOLD selector nella tool window: la gestione nativa del titlebar/window controls spetta all'host Windows.

## 6. Band Selector Strip — 40 lp; densità e disponibilità

La strip contiene **solo** i selettori delle bande realmente esistenti (**da 1 a 6**), un separatore puramente grafico all'interno dello spazio contabilizzato, **Add Band** e **Remove Band**. Non comprende l'etichetta `BANDS`, altri comandi, band reorder o schede fittizie per bande mancanti.

**Specimen con sei bande esistenti:** `1 BELL`, `2 NOTCH`, `3 LS`, `4 HS`, `5 HP`, `6 LP`. Sono associazioni **illustrative**, non un filtro fissato per ciascun indice. `Band 1` è selezionata; il selettore mostra il numero ordinale attuale, abbreviazione del filtro e stati di selection/processing. Tooltip e `Accessible.name` contengono il nome completo del filtro. Una banda `processing disabled` **rimane selezionabile**, accessibile ed editabile nell'Inspector.

| Token/elemento Board 05 | Valore |
|---|---:|
| Selettore di banda | **90 × 32 lp**, radius **8 lp** |
| Interbutton gap | **8 lp** |
| Post-band gap | **12 lp** |
| Segmento separator-to-Add, **separatore incluso** | **24 lp** |
| Add-to-Remove gap | **12 lp** |
| Margine destro | **20 lp** |
| Action button standard | **128 × 32 lp** |
| Action button compatto | **96 × 32 lp** |
| Action button radius | **8 lp** |
| Allineamento nella strip | Centro verticale; 4 lp liberi sopra e sotto i pulsanti da 32 lp |

**Regola di disponibilità, indipendente da `Enabled`:**

- `Add Band` disponibile se il modello consente una banda aggiuntiva; **disabled quando esistono sei bande**.
- `Remove Band` disponibile quando **esistono almeno due bande**, anche se una o più sono processing-disabled; **disabled con una banda esistente**.
- Sono azioni momentanee con icone rispettivamente **PLUS** e **MINUS in ogni stato**; non hanno `Selected` persistente e non introducono una conferma modale non prevista.

### 6.1 Fit responsive per sei bande

| Parte del budget | Default, action width 128 | Minimum, action width 96 |
|---|---:|---:|
| Sei selettori: `6 × 90` | 540 | 540 |
| Cinque gap: `5 × 8` | 40 | 40 |
| **Gruppo sei bande** | **580** | **580** |
| Gap dopo bande | 12 | 12 |
| Separator-to-Add (separator incluso) | 24 | 24 |
| Add | 128 | 96 |
| Gap fra azioni | 12 | 12 |
| Remove | 128 | 96 |
| Margine destro | 20 | 20 |
| **TOTAL REQUIRED** | **904 lp** | **840 lp** |
| **AVAILABLE** | **992 lp** | **852 lp** |
| **RESERVE elastic sinistra** | **88 lp** | **12 lp** |

**Breakpoint nominale Board 05:** larghezza interna `≥ 916 lp` ⇒ bottoni **Add Band / Remove Band** standard `128 × 32`, etichette complete; larghezza interna `852–915 lp` ⇒ variante **EQ-local** compatta `96 × 32`, etichette **Add / Remove**. Le sei bande, quando presenti, rimangono tutte visibili. Le riserve sono budget progettuali; focus outsets, `implicitWidth` e testo Qt devono ancora essere misurati in runtime. Non cambiare globalmente `StudioButton` per ottenere il target.

## 7. Response Graph — contenuto veritiero e sistema di coordinate

Il Graph Well mostra **una sola curva**, ricavata esclusivamente da **`selectedBandResponsePoints` del ViewModel C++** per la banda attualmente selezionata. Non rappresenta la somma delle risposte delle sei bande, non ricostruisce un'altra transfer function in QML e non contiene analyzer/spectrum. Gli altri band handles rimangono visibili ma sono **indipendenti** dalla curva selezionata.

**Specimen identico a default e minimum:** `Fs = 48000 Hz`; `Band 1 / BELL / STEREO / Enabled ON / Frequency 1000 Hz / Gain +3.0 dB / Q 0.707`. La curva Bell cyan ha un massimo di circa **+3 dB a 1 kHz** e ritorna progressivamente verso **0 dB** alle frequenze basse e alte. La forma e i campioni reali derivano dal C++; le coordinate visibili nell'immagine illustrativa non sono campioni DSP né vincoli di curva.

**Dominio proiettato:** asse X logaritmico `[20 Hz, min(20000 Hz, 0.45 × Fs)]`; asse Y lineare e simmetrico `[−18, +18] dB` con zero a 0 dB. Con `Fs = 48000 Hz` l'estremo superiore è **20000 Hz**; a `Fs = 44100 Hz` sarebbe **19845 Hz**, senza etichetta finale ingannevole `20k`.

**Gain landmarks:** `+18`, `+12`, `+6`, `0`, `−6`, `−12`, `−18` dB. Il valore **+6**, non +16, è la terza guida positiva. Frequency landmarks, minor/micro grid, gerarchia, line width, color token, label/collision policy e z-order sono esattamente quelli di Board 04; il plot e tutti i layer usano **lo stesso sistema di coordinate**.

## 8. Graph: geometria interna, materiale, curva e handles

| Proprietà | Default | Minimum | Autorità |
|---|---:|---:|---|
| Graph Well | **992 × 324 lp** | **852 × 244 lp** | Board 01 |
| Plot left | 52 lp | 52 lp | Board 04: outer left 12 + gain gutter 40 |
| Plot top | 10 lp | 10 lp | Board 04 |
| Plot right inset | 12 lp | 12 lp | Board 04 |
| Frequency-label gutter / bottom inset | 22 lp | 22 lp | Board 04 |
| **`plotRect` (x, y, w, h)** | **(52, 10, 928, 292) lp** | **(52, 10, 788, 212) lp** | Board 04, derivato |
| Zero line | al centro del `plotRect` | al centro del `plotRect` | Board 04 |

**Proiezione geometrica, non nuovo DSP:** posti `fMax = min(20000, 0.45 × Fs)`, `u = ln(f / 20) / ln(fMax / 20)`, `x = 52 + u × plotWidth`, `v = (18 − gainDb) / 36`, `y = 10 + v × plotHeight`. La stessa `plotRect` vale per response, fill, grid e centri degli handles. Tick label e unità occupano i rispettivi gutter: non riducono ulteriormente il plot.

**Materiale strutturale — solo richiamo di Board 02:** `eq.graph.bg = #081824FF`, gradiente top `#0D2A3AFF` → bottom `#06141DFF`, `eq.graph.border = #1A3E55FF`, 1 lp, radius 6 lp; highlight/shadow rimangono quelli della Board 02 v1.1. I colori di progetto **non** vanno incollati in QML senza conversione.

**Curva selezionata — EQ-LOCAL, Board 04:** `#2ED3FF` (`#2ED3FFFF` design → `#FF2ED3FF` QML); stroke **2 lp**; sotto-traccia luminosa locale **6 lp / 35%** (`#2ED3FF59` → `#592ED3FF`); fill **solo fra curva selezionata e zero line**, **14%** al contorno (`#2ED3FF24` → `#242ED3FF`) → **0%** a zero (`#2ED3FF00` → `#002ED3FF`). Se la risposta attraversa 0 dB, il riempimento segue la geometria dei singoli segmenti. Nessun gradiente fino al fondo del graph e nessun effetto spectrum.

**Handles:** un handle per ogni banda esistente, numerato con il proprio **ordinale 1–6**, senza duplicati. `Band 1` selezionata usa la propria identità cyan e **24 lp** di diametro; altri cinque handles **20 lp**. Colori esatti, stroke, number badge, selected/hover/pressed/drag/conditional-disabled e layer order sono quelli della Board 04 v1.1. Gli handles non selezionati non vanno forzati sulla curva Bell; la Y di un filtro privo di Gain applicabile segue il modello e la Board 04, **non** costituisce un parametro Gain inventato per Notch/High Pass/Low Pass.

**Clipping distinto:** grid, fill e line sono ritagliati alla `plotRect`. L'overlay interattivo dei band handles è disegnato **sopra** il plot clip per preservare disc, ring e selezione agli estremi; non ridurre le dimensioni degli handles o introdurre un nuovo margine alla finestra. Per l'esempio selezionato, non interpolare i valori numerici prendendoli dai pixel della tavola.

## 9. Selected-Band Inspector — struttura 128 lp

L'Inspector rimane **sotto** il Graph e usa il materiale `eq.control.*` della Board 02, condiviso con la Band Strip; non esiste un Inspector laterale. Il contenuto esistente è organizzato su due livelli:

- **Upper Tier:** colonna Band Identity + Band Enabled che occupa entrambe le sottorighe; sottoriga Filter con **sei opzioni esplicite**; sottoriga Routing con **cinque opzioni esplicite** e, quando applicabile, un solo badge Mixed Routing.
- **Lower Tier:** solo i parametri applicabili al filtro selezionato, senza campi disabilitati usati come placeholder per parametri inesistenti.

| Budget verticale (Board 06) | Altezza |
|---|---:|
| Top padding | 6 lp |
| Filter row | 28 lp |
| Gap fra sottorighe superiori | 4 lp |
| Routing row | 28 lp |
| Gap fra i due tier; divisore incluso se presente | 4 lp |
| Componente numerico completo | 50 lp |
| Bottom padding | 8 lp |
| **TOTAL** | **128 lp** |

La Status / Validation Strip **non** appartiene a questi 128 lp. La colonna Band + Enabled ha **160 lp** di larghezza e resta realmente selezionabile/editabile quando Band Enabled è OFF. Tutti i sei Filter e tutti i cinque Routing condividono il trattamento segmented premium esistente, non vengono sostituiti con menu generici e non si aggiunge una modalità `MIXED`.

## 10. Fit orizzontale dell'Inspector e minimum size

Alla minima larghezza: content interno **852 lp**, padding Inspector **16 lp per lato**, traccia utilizzabile **820 lp**. Le larghezze includono label, spazi e dividers dichiarati; **non** devono ricevere ulteriori margini impliciti non contabilizzati.

| Segmento | FILTER row | ROUTING row con Mixed badge |
|---|---:|---:|
| Band + Enabled column | 160 | 160 |
| Gap | 8 | 8 |
| Label column | 56 (`FILTER`) | 56 (`ROUTING`) |
| Label-to-controls gap | 8 | 8 |
| Segmenti | `6 × 96 = 576` | `5 × 80 = 400` |
| Dividers inclusi | `5 × 1 = 5` | `4 × 1 = 4` |
| **Segmented group** | **581** | **404** |
| Gap prima di Mixed | — | 8 |
| Badge Mixed | — | 164 |
| **REQUIRED** | **813 lp** | **808 lp** |
| **AVAILABLE** | **820 lp** | **820 lp** |
| **REMAINING design budget** | **7 lp** | **12 lp** |

**Regola di completezza:** `STEREO · MID · SIDE · LEFT · RIGHT` rimangono **tutti visibili** a 900 × 580, incluso **LEFT fra SIDE e RIGHT**. Quando `mixedRouting` è true, il badge è visibile nello spazio già contabilizzato. Se le metriche QML reali non permettono questi obiettivi, la preview grafica non può giustificare omissioni, overlap, riduzione arbitraria del font o scrolling: si applica il gate della §16.

**Mono:** secondo la Board 06, resta disponibile STEREO; MID, SIDE, LEFT e RIGHT risultano realmente unavailable, senza essere rimossi dalla struttura dei cinque segmenti. Il badge rimane condizionato **solo** al dato derivato del ViewModel.

## 11. Applicabilità dei parametri e numeric fields

| Filter selezionato | Lower Tier: soli controlli visibili | Tipo di slope |
|---|---|---|
| **Bell** | Frequency · Gain · Q | Nessuno |
| **Notch** | Frequency · Q | Nessuno |
| **Low Shelf / High Shelf** | Frequency · Gain · Shelf Slope | Shelf Slope **numerico diretto, unitless** |
| **High Pass / Low Pass** | Frequency · HP/LP Slope | **Sei pulsanti discreti**, non dropdown |

**Limiti reali:** Frequency `20 Hz ≤ f ≤ min(20000 Hz, 0.45 × Fs)`; Gain `−18 ≤ G ≤ +18 dB`; Q `0.10 ≤ Q ≤ 12.0`; Shelf Slope `0.10 ≤ S ≤ 1.0`; HP/LP Slope **6, 12, 18, 24, 36, 48 dB/oct**. I sei pulsanti HP/LP della Board 06 mantengono altezza **28 lp**, larghezza candidata **80 lp** ciascuno, cinque dividers da 1 lp, totale **485 lp**; fit della variante Frequency + HP/LP Slope **729/820 lp**, reserve **91 lp**. **Chiarimento Board 06 v1.1:** il subtotale 729 lp comprende la sola *input box* Frequency da 164 lp, NON comprende ancora l'unità esterna `Hz`, il gap unità da 8 lp, il suo ingombro tipografico effettivo né i focus-ring outsets: tutti devono rientrare nella riserva 91 lp e vanno misurati su Qt/QML. Nessuna nuova validazione QML.

**Specimen integrato Bell:** `Band 1`, `Enabled ON`, `Filter BELL`, `Routing STEREO`; Lower Tier mostra **solo** Frequency **1000 Hz**, Gain **+3.0 dB**, Q **0.707**. **Nessun Shelf Slope/HP-LP Slope, neppure disabled o come spazio riservato.**

**Anatomia numerica ereditata da Board 03:** Segoe UI Control Label **12 lp/600**, Consolas Numeric Value **16 lp/400**; label line-height **16 lp**, label-to-field **6 lp**, box height **28 lp**, **complete component height 50 lp** (`16 + 6 + 28`), input width **164 lp** come proposta **EQ-local Board 06** e **non** come nuovo valore globale. Valori allineati a destra *dentro* l'input; eventuali unità esterne (es. `Hz`, `dB`) sono posizionate **a destra della input box**, con testo Segoe UI **12 lp allineato a sinistra** e **8 lp di gap** fra bordo destro della box e inizio del testo. `Q` e Shelf Slope sono unitless. Questa distinzione elimina l'ambiguità fra allineamento del testo dell'unità e posizione dell'unità rispetto al campo, senza modificare Board 03. Gli input non applicabili sono **hidden**, non grigi.

**Editing:** un invalid raw draft resta visibile senza commit DSP né nuova preview causata dal draft invalido; Enter e valid focus-out confermano solo valori validi; Escape ripristina il committed value; nessun Apply/Cancel e nessun silent clamping. Il Bypass non disabilita automaticamente l'editing.

## 12. Mixed Routing — condizione derivata, posizione e pigmenti

La Board 08 eredita la semantica della Board 07: `mixedRouting` è **una proprietà derivata del ViewModel**, `true` soltanto quando **almeno due bande abilitate e con parametri confermati impiegano routing differenti**. Non basta avere due bande abilitate; non esiste un Mixed Routing switch, una sesta opzione Routing, un badge per banda né una curva EQ combinata.

**Specimen coerente:** la banda selezionata `Band 1` ha routing **STEREO**, è abilitata e ha parametri confermati; almeno un'altra banda abilitata con parametri confermati usa per esempio **MID**. Il ViewModel riporta `mixedRouting = true`, quindi compare **un solo** `MIXED ROUTING ACTIVE` nella **Routing subrow** dell'Inspector. Se tutte le bande abilitate con parametri confermati usano lo stesso routing, il badge è **completamente nascosto**. Una banda disabilitata non contribuisce da sola all'attivazione. La risposta grafica rimane esclusivamente quella di Band 1.

| Token EQ-LOCAL — PROPOSED, Board 07 | Design `#RRGGBBAA` | QML `#AARRGGBB` |
|---|---|---|
| `eq.mixed.background` | **`#6C4EA633`** | **`#336C4EA6`** |
| `eq.mixed.border` | **`#A989F2B3`** | **`#B3A989F2`** |
| `eq.mixed.text` | **`#E9DCFFEE`** | **`#EEE9DCFF`** |

**Conversioni verificate byte per byte:** `6C 4E A6 33 → 33 6C 4E A6`; `A9 89 F2 B3 → B3 A9 89 F2`; `E9 DC FF EE → EE E9 DC FF`.

Badge **164 × 28 lp**, raggio **8 lp**, bordo **1 lp interno**, Segoe UI **12 lp/600**; alpha incorporata nei token, compositing **Source-over**. Nessun secondo layer viola, focus/hover/pressed o animazione interattiva. Questi pigmenti locali non sostituiscono `rgs.processed.purple`, non rappresentano lo stato globale PROCESSED e non sono promossi automaticamente al design system condiviso. Il badge non compare nella Status Strip.

## 13. Stato principale dei controlli, materiali e motion ereditati

Il reference state integrato mostra **Preview READY + A selezionato + B inattivo + Band 1 selezionata/Enabled ON + sei bande esistenti + Add disabled + Remove enabled + Bell/Stereo selezionati + Mixed badge visibile + nessun validation/preview error**. Non simulare simultaneamente hover, pressed e keyboard focus su tutti i controlli; lo stato di keyboard focus, quando presente durante la vera interazione, deve rimanere distinguibile dal Selected.

**Materiali:** usare esattamente `eq.window.*`, `eq.panel.*`, `eq.control.*`, `eq.graph.*` e gli overlay applicabili della Board 02 v1.1; non ridefinire gradienti, bordi strutturali, highlight, shadow, corner radius o palette globale. Il Graph Well resta visivamente incassato e dominante; Band Strip e Inspector condividono la medesima famiglia di Control Surfaces.

**Tipografia:** Segoe UI per UI/etichette, Consolas per valori numerici, con fallback della Board 03. Nessun Inter obbligatorio, font rimpicciolito arbitrariamente o modifica implicita della tipografia GUI-01.

**Motion:** esclusivamente le microtransizioni EQ-local proposte nella Board 07: Hover **80 ms**, Pressed **60 ms**, Keyboard Focus **0 ms per visibilità iniziale**, Selected **120 ms**, Toggle **100 ms**, Status Transition **150 ms** per il solo trattamento decorativo dopo il contenuto immediato. I valori, easing e max effect definiti dalla Board 07 non sono sostituiti qui. Gli stati funzionali importanti, compresi focus e INVALID DRAFT, si presentano **immediatamente**; nessuna animazione ritarda un errore, interpola parametri numerici, rallenta il pointer drag o altera l'allocazione geometrica. Reduced Motion elimina/riduce effetti decorativi ove il supporto Windows lo consenta, preservando significato, focus ed errori.

## 14. Status / Validation Strip — 24 lp, vuota nello specimen

La quinta sezione è **esterna** all'Inspector, larga quanto il content rectangle e separata da esso da un gap **12 lp**. L'esempio integrato non contiene errori; quindi la strip è **letteralmente vuota**: niente `Parametric EQ ready.`, `Ready for preview`, `MIXED ROUTING ACTIVE`, pallino, icona, telemetry, debug label, loghi o conferme inventate.

Negli stati reali successivi all'esempio si applica **solo** la precedenza della Board 07:

1. `validationMessage` non vuoto ⇒ mostra il messaggio reale restituito dal ViewModel, Error Coral e relativo campo `validationField` quando previsto.
2. In assenza di `validationMessage`, se Preview Status è `ERROR` ⇒ mostra il testo reale di `previewError` **quando effettivamente disponibile**.
3. Altrimenti ⇒ strip **vuota**.

La strip rimane alta **24 lp** anche con testi lunghi: ellipsis leggibile senza alterare l'altezza, tooltip e accessible full text. Nessuna notifica in coda, carosello, warning automatico, diagnosi fittizia o seconda barra. Il Preview Status rimane nell'Header e non viene replicato qui.

## 15. Minimum-window specimen — equivalenza funzionale

La variante **900 × 580 lp**, content **852 × 532 lp**, rappresenta **la stessa configurazione dati e gli stessi stati** della variante standard; non un diverso preset o una risposta graficamente reinterpretata:

- `Band 1` / Bell / Stereo / Enabled ON / **1000 Hz, +3.0 dB, Q 0.707**, Preview READY e A selezionato.
- Curva cyan **della sola Band 1**, massimo circa **+3 dB a 1 kHz**; altre cinque identità/handle indipendenti, ognuno col proprio numero 1–6 senza duplicazioni.
- Sei selettori dinamici visibili; Add **disabled** perché esistono sei bande, Remove **enabled** perché ne esistono almeno due; Add/Remove **compatti 96 × 32 lp**.
- Tutti e sei i Filter espliciti e **tutti e cinque** i Routing `STEREO, MID, SIDE, LEFT, RIGHT`; `LEFT` resta tra `SIDE` e `RIGHT`.
- Un solo Mixed badge contestuale visibile, dovuto alle modalità Routing differenti di almeno due bande abilitate con parametri confermati.
- Inspector **852 × 128 lp** a due tier, soltanto Frequency/Gain/Q nel lower tier Bell; status esterno **852 × 24 lp**, **vuoto**.
- Graph **852 × 244 lp**, plot **788 × 212 lp**; label, focus ring e handle overlay non devono essere nascosti o tagliati.

**La preview 900 × 580 della Board 08 è geometria progettuale illustrata, non screenshot Windows verificato.** L'omissione grafica di `LEFT` è esplicitamente superata dalle §§ 2 e 10: la vera implementazione deve mostrare il gruppo Routing completo e badge senza overlap o scrolling.

## 16. Mandatory Qt/QML implementation verification gate

Le misure nominali e i 7/12-lp di riserva dell'Inspector sono **target accettati**, non misure già osservate. Le 28-lp delle sottorighe Filter/Routing sono inoltre inferiori all'`implicitHeight` approssimativa **32 lp** degli attuali `StudioButton` condivisi; l'adattamento, se necessario, deve restare **EQ-local**. Il gate di accettazione dell'implementazione richiede **screenshot reali** e misure Qt alle due dimensioni **1040 × 660** e **900 × 580**, non un nuovo concept illustrativo.

| Gate | Verifica obbligatoria e criterio di accettazione |
|---|---|
| Macro geometry | Finestra, 24-lp inset, quattro gap, cinque sezioni, graph **324/244**, Inspector **128**, strip **24**; somma **612/532 lp**. |
| Header e Preview | Titolo/sottotitolo leggibili; Preview badge immediatamente prima di A/B, esercitare **NO PREVIEW / RENDERING / READY / ERROR**, A/B mutuamente esclusivi. |
| Band Strip a 1 e 6 bande | Verificare conteggio dinamico, label numero+filtro, metriche reali `implicitWidth`/`implicitHeight`/padding/focus; stati Add/Remove **indipendenti da Band Enabled**. Nessuna settima banda/zero bande. |
| Breakpoint action buttons | Full **128 lp** dove inner width `≥916 lp`, compact **96 lp** a `852–915 lp`; nessun separator/gap non contabilizzato. |
| Graph e plot | `selectedBandResponsePoints` C++; curva Bell coerente fra le due misure; 1 kHz/+3 dB nello specimen; `plotRect` condivisa da curva, fill, griglia e handles; sette gain labels corretti. |
| Handles | Esattamente 1–6 per le bande esistenti, **24/20 lp** selected/unselected; identità e coordinate fedeli al modello, overlay interattivo non ritagliato agli estremi. |
| Filter row | **Sei** opzioni leggibili; misura testo Segoe UI, padding, separatori, `implicitWidth`, focus; budget **813/820 lp**. |
| Routing row | **Cinque** opzioni sempre presenti, incluso LEFT; badge **164 × 28 lp** unico con `mixedRouting` true; budget **808/820 lp** misurato. |
| Inspector lower tier | Bell con soli Frequency/Gain/Q; anche Notch/Shelf/HP-LP reali senza placeholder; campi Board 03 alti **50 lp**, slope HP/LP a sei segmenti senza dropdown. |
| Mixed semantics e pigmenti | Due o più bande abilitate, committed, con **routing differenti** ⇒ `true` e **un badge**; routing uguali ⇒ `false`/badge nascosto; valori design/QML convertiti byte per byte. |
| Error precedence e strip neutra | Strip **totalmente vuota** senza errori; con errori `validationMessage` precede `previewError`; ellipsis + tooltip + accessible full text, altezza invariata. |
| Interaction + focus | Tab, stato Selected separato dal Keyboard Focus; focus **immediatamente visibile** e non clippato, nessun drag lag o nuovo Preview a ogni pointer move; Reduced Motion quando disponibile. |
| Material fidelity | Studio Slate e tutti i token strutturali della Board 02; nessun flat/generic Qt fallback visivo arbitrario, blur costoso o alterazione globale di `StudioButton`. |
| Runtime layout acceptance | A entrambe le dimensioni: **nessun clipping, nessun overlap, nessun controllo inaccessibile, nessuno scrolling orizzontale**; misure QML documentate con screenshot reali. |

**Stop ed escalation:** se `implicitWidth`, `implicitHeight`, font metrics, focus-ring outsets, eventuale text localization o altre misure reali invalidano i budget nominali, interrompere l'accettazione; documentare il conflitto misurato e richiedere un **narrow EQ-local Product Owner-approved layout delta**. Non nascondere `LEFT`, cambiare il font, ridimensionare l'intera UI, aumentare l'Inspector, alterare Board 01 o modificare globalmente i controlli condivisi senza approvazione esplicita.

## 17. Chiarimenti della revisione indipendente — v1.1

Questa revisione ha confrontato il manoscritto Board 08 v1.0 con i sette manifesti canonici antecedenti e con il PR #8 reale (Draft, non merged) all'HEAD `5676505f586738d29349b3a2f4907ba011575141`, verificato il 23 settembre 2026. **Il testo originale v1.0 rimane conservato come provenance**. La v1.1 corregge un'ambiguità testuale e rende esplicito un obbligo dimensionale già presente nella Board 06; non cambia layout, colori o funzioni del prodotto:

- **B08-INT-01 — Unità numeriche:** il termine «a sinistra» della v1.0 descriveva l'allineamento del testo ma poteva essere interpretato come collocazione della sigla a sinistra della casella. L'unità segue invece la casella **a destra**, con testo left-aligned e gap 8 lp secondo Board 03.
- **B08-INT-02 — HP/LP subtotal:** i 729 lp sono soltanto la somma degli elementi esplicitamente elencati. Il testo `Hz`, il suo gap 8 lp e gli eventuali focus outsets non sono contenuti nei 164 lp dell'input box e devono essere misurati entro la riserva residua di 91 lp secondo Board 06 v1.1.
- **B08-INT-03 — Design vs running code:** la QML presente nel PR #8 prima del WOW usa attualmente `StudioButton.implicitHeight = 32 lp`, `ParametricEqGraph.qml` con `clip: true` sul root, etichetta `BANDS` nella strip e mostra direttamente la stringa `previewStatus`; la Board 08 definisce il target del **successivo restyling deterministico EQ-local**, NON attesta che queste differenze siano già state corrette. In particolare la futura implementazione dovrà mostrare tutti e cinque i Routing, rimuovere l'etichetta `BANDS` dalla strip, mappare `IDLE` su NO PREVIEW senza quinto badge, confinare il clipping ai paint-layer del plot e lasciare visibili handles/focus agli estremi. Il test di misure Qt/focus a 1040 × 660 e 900 × 580 è un gate successivo e obbligatorio, non una dichiarazione di compatibilità già ottenuta.

**Esito:** la Board 08 v1.1 è un contratto integrato deterministicamente coerente con Boards 01–07, **accettato nel proprio scope progettuale**. Rimangono richiesti il consolidamento documentale delle otto boards e la convalida del Product Owner prima del freeze dell'intero WOW Design Package e del task di implementazione per Jules.

## 18. Confini della Board 08 e stato di review

**Nessuna autorizzazione** a: curva EQ combinata sintetica, analyzer/spectrum, nuovo processing mode, altre opzioni Routing, preset o A/B snapshot, Level Match, Apply/Cancel, controlli globali PREPARED/PROCESSED/GOLD nella tool window, toolbar aggiuntive, band reorder, nuovi stati backend, warning automatici, status neutro inventato, doppio Mixed badge, Inspector laterale, nuovi shortcut o logica DSP/validazione QML.

Questo manifesto documenta la composizione integrata dell'editor L1-M12B con le tre correzioni normative necessarie. **Le Boards 01–07 mantengono la propria autorità** su componenti, stati, materiali, tipografia e rendering; le misure di fit e la fedeltà grafica richiedono una successiva verifica nell'app Windows. Nessun codice QML viene consegnato in questa fase. **Il Visual WOW Design Package nel suo complesso non viene dichiarato FROZEN prima del gate di consolidamento/approvazione del Product Owner.**

**STOP — CROSS-BOARD REVIEW COMPLETED / BOARD 08 SCOPE ACCEPTED. NEXT: PACKAGE CONSOLIDATION AND PO FREEZE GATE.**
